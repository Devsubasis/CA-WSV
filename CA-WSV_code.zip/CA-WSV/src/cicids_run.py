"""
CA-WSV protocol runner for CSE-CIC-IDS2018, identical cleaning/leakage-free
protocol to the original paper (Fixes #1-#5 from cicids2018_corrected.ipynb),
reimplemented here as a standalone script producing a persisted model bundle
(for the XAI script) plus the standard metrics JSONL.

Usage: python cicids_run.py [cap] [seed]
"""
import os as _os
from pathlib import Path as _Path
ROOT = _Path(_os.environ.get("CAWSV_ROOT", _Path(__file__).resolve().parents[1]))
DATA = ROOT / "data"
DATA_NSL = DATA / "nsl-kdd"; DATA_UNSW = DATA / "unsw-nb15"; DATA_CIC = DATA / "cic-ids2018"
DATA_CIC_STAGE = DATA / "cic-ids2018-stage"; BOTIOT_CSV = DATA / "bot-iot" / "random_500k.csv"
RESULTS = ROOT / "results"; LEGACY = RESULTS / "cicids2018_legacy"; MODELS = ROOT / "models"
PAPER = ROOT / "paper_assets"; SRC = ROOT / "src"; CKPT = MODELS / "checkpoint.joblib"
LEGACY_POST = LEGACY / "posteriors.npz"; LEGACY_GAMMA = LEGACY / "gamma_sensitivity.json"
for _d in (RESULTS, LEGACY, MODELS, PAPER, PAPER / "figures", PAPER / "tables"): _d.mkdir(parents=True, exist_ok=True)
import json, sys, time, os, pickle, gc
import numpy as np, pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler, LabelEncoder
from sklearn.feature_selection import SelectKBest, f_classif
from sklearn.ensemble import RandomForestClassifier, HistGradientBoostingClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import LinearSVC
from sklearn.metrics import f1_score, accuracy_score, matthews_corrcoef

t0 = time.time()
def log(m): print(f"[{time.time()-t0:6.0f}s] {m}", flush=True)

DATA_DIR = f"{DATA_CIC}"
FILES = ["02-14-2018.csv", "02-15-2018.csv", "02-16-2018.csv", "02-21-2018.csv",
          "02-22-2018.csv", "02-23-2018.csv", "02-28-2018.csv", "03-01-2018.csv",
          "03-02-2018.csv"]
EXTRA_COLS = ["Flow ID", "Src IP", "Src Port", "Dst IP"]
K_FEAT = 20; MIN_CLASS = 100; GAMMA_GRID = [0.5, 1, 2, 3, 4, 6, 8]
OUT = f"{RESULTS}"; os.makedirs(OUT, exist_ok=True)
MODELDIR = f"{MODELS}"; os.makedirs(MODELDIR, exist_ok=True)

def ece_per_class(P, y, C, bins=10):
    out = np.zeros(C)
    for c in range(C):
        p = P[:, c]; t = (y == c).astype(float); e = 0.0
        edges = np.linspace(0, 1, bins + 1)
        for i in range(bins):
            m = (p > edges[i]) & (p <= edges[i + 1])
            if m.any(): e += m.mean() * abs(p[m].mean() - t[m].mean())
        out[c] = e
    return out

def clean_one_file(d):
    """Apply all per-row cleaning + dtype downcast to ONE day's frame, in place,
    before it is ever held alongside the other 8 days (this is the fix for the
    OOM kill: peak memory used to be ~9 raw float64 80-col frames at once)."""
    d = d.drop(columns=[c for c in EXTRA_COLS if c in d.columns])
    d = d[d["Label"] != "Label"]
    d = d.drop(columns=["Timestamp", "Dst Port"])
    d["Protocol"] = d["Protocol"].astype(str)
    d = pd.get_dummies(d, columns=["Protocol"], drop_first=False)  # drop_first=False: union columns across days, aligned later
    feature_cols = [c for c in d.columns if c != "Label"]
    d[feature_cols] = d[feature_cols].apply(pd.to_numeric, errors="coerce", downcast="float")
    d = d.replace([np.inf, -np.inf], np.nan)
    d = d.dropna(subset=feature_cols)
    for col in ["Init Fwd Win Byts", "Init Bwd Win Byts"]:
        if col in d.columns: d[col] = d[col].clip(lower=0)
    neg_mask = (d[feature_cols] < 0).any(axis=1)
    d = d[~neg_mask]
    d[feature_cols] = d[feature_cols].astype(np.float32)
    d = d.reset_index(drop=True)
    # per-file dedup (cheap hash-based, not pandas drop_duplicates - avoids the
    # OOM-causing memory spike of drop_duplicates() on a wide mixed-dtype frame).
    # CIC-IDS2018 is heavily duplicated WITHIN a single day's capture (documented
    # artifact), so this alone removes most of the redundancy before concat.
    key = pd.util.hash_pandas_object(d, index=False)
    d = d[~key.duplicated()].reset_index(drop=True)
    d["Label"] = d["Label"].astype("category")
    return d

def load_and_clean():
    parts = []
    parts_raw_label_counts = pd.Series(dtype="int64")
    for fname in FILES:
        path = os.path.join(DATA_DIR, fname)
        d = pd.read_csv(path, low_memory=False)
        n0 = len(d)
        parts_raw_label_counts = parts_raw_label_counts.add(d["Label"].value_counts(), fill_value=0)
        d = clean_one_file(d)
        parts.append(d)
        log(f"{fname:18s} raw rows: {n0:>9,d}  after per-file cleaning+dedup: {len(d):>9,d}")
        del d; gc.collect()
    raw_label_counts = parts_raw_label_counts  # captured before any cleaning, see loop above
    per_file_dedup_counts = sum([p["Label"].value_counts() for p in parts])
    df = pd.concat(parts, ignore_index=True); del parts; gc.collect()
    df["Label"] = df["Label"].astype(str).astype("category")  # re-unify categories across files
    # align Protocol_* one-hot columns that may differ slightly across days
    proto_cols = [c for c in df.columns if c.startswith("Protocol_")]
    df[proto_cols] = df[proto_cols].fillna(0).astype(np.int8)
    log(f"merged after per-file dedup: {df.shape}")

    feature_cols = [c for c in df.columns if c != "Label"]
    before = raw_label_counts
    # final cross-day dedup pass (hash-based, cheap): catches the rare case of an
    # identical flow appearing on two different days, after the much larger
    # within-day duplication has already been removed above.
    key = pd.util.hash_pandas_object(df, index=False)
    df = df[~key.duplicated()].reset_index(drop=True)
    gc.collect()
    after = df["Label"].value_counts()
    dedup_report = pd.DataFrame({"before_any_dedup": before, "after_per_file_dedup": per_file_dedup_counts,
                                  "after_cross_day_dedup": after})
    log("dedup report:\n" + dedup_report.sort_values("after_cross_day_dedup", ascending=False).to_string())

    counts = df["Label"].value_counts()
    rare = counts[counts < MIN_CLASS]
    if len(rare):
        log(f"dropping rare classes (<{MIN_CLASS} unique rows after dedup): {list(rare.index)}")
        df = df[~df["Label"].isin(rare.index)]
    return df, feature_cols, dedup_report

def run(cap, seed):
    df, feature_cols, dedup_report = load_and_clean()
    if cap:
        df = pd.concat([g.sample(min(len(g), cap), random_state=seed)
                        for _, g in df.groupby("Label")], ignore_index=True)
    log(f"final distribution (cap={cap}):\n{df['Label'].value_counts().to_string()}")

    le = LabelEncoder(); y = le.fit_transform(df["Label"]); classes = list(le.classes_)
    C = len(classes)
    X = df[feature_cols].reset_index(drop=True).to_numpy()
    feat_names = feature_cols

    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.3, random_state=seed, stratify=y)
    sc = MinMaxScaler().fit(Xtr); Xtr_s, Xte_s = sc.transform(Xtr), sc.transform(Xte)
    sel = SelectKBest(f_classif, k=min(K_FEAT, Xtr_s.shape[1])).fit(Xtr_s, ytr)
    sel_idx = sel.get_support(indices=True); sel_names = [feat_names[i] for i in sel_idx]
    Xtr_k, Xte_k = sel.transform(Xtr_s), sel.transform(Xte_s)
    Xs, Xv, ys, yv = train_test_split(Xtr_k, ytr, test_size=0.15, random_state=seed, stratify=ytr)
    log(f"selected features: {sel_names}")

    pool = [("RF", RandomForestClassifier(class_weight="balanced", n_jobs=-1, random_state=seed)),
            ("DT", DecisionTreeClassifier(class_weight="balanced", random_state=seed)),
            ("KNN", KNeighborsClassifier(n_jobs=-1)),
            ("LR", LogisticRegression(class_weight="balanced", max_iter=2000))]
    Pv, Pt, F, E = [], [], [], []
    for nm, mo in pool:
        mo.fit(Xs, ys); log(f"fitted {nm}")
        full_v = np.zeros((len(Xv), C)); full_t = np.zeros((len(Xte_k), C))
        full_v[:, mo.classes_] = mo.predict_proba(Xv)
        full_t[:, mo.classes_] = mo.predict_proba(Xte_k)
        Pv.append(full_v); Pt.append(full_t)
        F.append(f1_score(yv, np.argmax(full_v, 1), average=None, labels=np.arange(C), zero_division=0))
        E.append(ece_per_class(full_v, yv, C))
    F = np.stack(F); E = np.stack(E)
    fuse = lambda W, P: np.argmax(sum(W[i][None, :] * P[i] for i in range(len(P))), 1)
    best = (-1, None)
    for g in GAMMA_GRID:
        Fg = np.power(np.maximum(F, 1e-9), g); Wg = Fg / Fg.sum(0, keepdims=True)
        v = f1_score(yv, fuse(Wg, Pv), average="macro", zero_division=0)
        if v > best[0]: best = (v, g)
    g = best[1]
    Fg = np.power(np.maximum(F, 1e-9), g); Wca = Fg / Fg.sum(0, keepdims=True)
    Wu = np.full_like(Wca, 1 / 4)
    Fs = (F.mean(1, keepdims=True)) ** g; Ws = np.repeat(Fs / Fs.sum(0, keepdims=True), C, 1)
    log(f"gamma*={g}, val macroF1={best[0]:.4f}")

    svm = LinearSVC(class_weight="balanced", max_iter=5000, dual="auto").fit(Xs, ys)
    hgb = HistGradientBoostingClassifier(class_weight="balanced", random_state=seed).fit(Xs, ys)
    extra = {"SVM": svm.predict(Xte_k), "HistGB": hgb.predict(Xte_k)}
    log("fitted SVM, HistGB")

    res = {"seed": seed, "cap": cap, "gamma": g, "n_train": int(len(Xtr_k)), "n_test": int(len(Xte_k)),
           "classes": classes, "selected_features": sel_names,
           "F": F.round(5).tolist(), "W": Wca.round(5).tolist(),
           "test_support": {classes[c]: int((yte == c).sum()) for c in range(C)},
           "dedup_report": dedup_report.reset_index().rename(columns={"index": "label"}).to_dict("records")}
    gap = F.max(0) - F.mean(0)
    res["CHI"] = float(gap.mean()); res["CHI_per_class"] = {classes[c]: float(gap[c]) for c in range(C)}
    res["ECE_matrix"] = E.round(5).tolist()
    res["calib_heterogeneity"] = float((E.max(0) - E.min(0)).mean())
    for tag, pr in [("CA-WSV", fuse(Wca, Pt)), ("Scalar", fuse(Ws, Pt)), ("Uniform", fuse(Wu, Pt)),
                    ("RF", np.argmax(Pt[0], 1)), ("DT", np.argmax(Pt[1], 1)),
                    ("KNN", np.argmax(Pt[2], 1)), ("LR", np.argmax(Pt[3], 1)),
                    ("SVM", extra["SVM"]), ("HistGB", extra["HistGB"])]:
        f1c = f1_score(yte, pr, average=None, labels=np.arange(C), zero_division=0)
        res[tag] = {"acc": float(accuracy_score(yte, pr)),
                    "macro_f1": float(f1_score(yte, pr, average="macro", zero_division=0)),
                    "weighted_f1": float(f1_score(yte, pr, average="weighted", zero_division=0)),
                    "mcc": float(matthews_corrcoef(yte, pr)),
                    "per_class_f1": {classes[c]: round(float(f1c[c]), 4) for c in range(C)}}
        log(f"{tag:8s} acc={res[tag]['acc']:.4f} macroF1={res[tag]['macro_f1']:.4f}")

    out = f"{OUT}/cicids2018_cap{cap}.jsonl"
    open(out, "a").write(json.dumps(res) + "\n")
    log(f"saved {out}")

    # persist a model bundle for the XAI script (base models + scaler + selector + weights)
    bundle = {"pool": dict(pool), "scaler": sc, "selector": sel, "W": Wca, "gamma": g,
              "classes": classes, "sel_names": sel_names,
              "Xs": Xs, "Xv": Xv, "ys": ys, "yv": yv, "Xte_k": Xte_k, "yte": yte}
    with open(f"{MODELDIR}/bundle_cap{cap}.pkl", "wb") as f:
        pickle.dump(bundle, f)
    log(f"saved model bundle to {MODELDIR}/bundle_cap{cap}.pkl")
    return res

if __name__ == "__main__":
    cap = int(sys.argv[1]) if len(sys.argv) > 1 else 100_000
    seed = int(sys.argv[2]) if len(sys.argv) > 2 else 0
    run(cap, seed)
