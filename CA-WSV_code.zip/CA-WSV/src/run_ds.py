"""
Dataset-agnostic CA-WSV protocol runner (identical to the CSE-CIC-IDS2018 paper).

Pipeline per split:  clean -> dedup -> rare-class removal (<100) -> cap/class
  -> stratified 70/30 -> MinMax (train-fit) -> SelectKBest ANOVA k=20 (train-fit)
  -> 85/15 sub-train/validation -> RF, DT, KNN, LR (balanced)
  -> CA-WSV (gamma grid on validation) + uniform + scalar ablations
  -> metrics on untouched test set.  Also records the F matrix and the
  Competence Heterogeneity Index (CHI) for the gain-prediction study.

Usage:  python src/run_ds.py <nslkdd|unsw|botiot> <seed,seed,...|official> [cap]
"""
import os as _os
from pathlib import Path as _Path
ROOT = _Path(_os.environ.get("CAWSV_ROOT", _Path(__file__).resolve().parents[1]))
DATA = ROOT / "data"
DATA_NSL = DATA / "nsl-kdd"; DATA_UNSW = DATA / "unsw-nb15"; DATA_CIC = DATA / "cic-ids2018"
DATA_CIC_STAGE = DATA / "cic-ids2018-stage"; BOTIOT_CSV = DATA / "bot-iot" / "random_500k.csv"
RESULTS = ROOT / "results"; LEGACY = RESULTS / "cicids2018_legacy"; MODELS = ROOT / "models"
PAPER = ROOT / "paper_assets"; SRC = ROOT / "src"; CKPT = MODELS / "checkpoint.joblib"
LEGACY_POST = LEGACY / "posteriors.npz"; LEGACY_GAMMA = LEGACY / "gamma_sensitivity.json"
for _d in (RESULTS, LEGACY, MODELS, PAPER, PAPER / "figures", PAPER / "tables"): _d.mkdir(parents=True, exist_ok=True)
import json, sys, time, os
import numpy as np, pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler
from sklearn.feature_selection import SelectKBest, f_classif
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import f1_score, accuracy_score, matthews_corrcoef
from sklearn.svm import LinearSVC
from sklearn.ensemble import HistGradientBoostingClassifier

t0 = time.time()
def log(m): print(f"[{time.time()-t0:6.0f}s] {m}", flush=True)

K_FEAT = 20; MIN_CLASS = 100; GAMMA_GRID = [0.5, 1, 2, 3, 4, 6, 8]
OUT = f"{RESULTS}"; os.makedirs(OUT, exist_ok=True)

# --------------------------------------------------------------------------
# Loaders: each returns (X: DataFrame of numeric features, y: str labels)
# --------------------------------------------------------------------------
def load_nslkdd():
    cols = ["duration","protocol_type","service","flag","src_bytes","dst_bytes","land",
        "wrong_fragment","urgent","hot","num_failed_logins","logged_in","num_compromised",
        "root_shell","su_attempted","num_root","num_file_creations","num_shells",
        "num_access_files","num_outbound_cmds","is_host_login","is_guest_login","count",
        "srv_count","serror_rate","srv_serror_rate","rerror_rate","srv_rerror_rate",
        "same_srv_rate","diff_srv_rate","srv_diff_host_rate","dst_host_count",
        "dst_host_srv_count","dst_host_same_srv_rate","dst_host_diff_srv_rate",
        "dst_host_same_src_port_rate","dst_host_srv_diff_host_rate","dst_host_serror_rate",
        "dst_host_srv_serror_rate","dst_host_rerror_rate","dst_host_srv_rerror_rate",
        "label","difficulty"]
    d = f"{DATA_NSL}"
    df = pd.concat([pd.read_csv(f"{d}/KDDTrain+.txt", names=cols, header=None),
                    pd.read_csv(f"{d}/KDDTest+.txt",  names=cols, header=None)],
                   ignore_index=True)
    cat = {"DoS": "back land neptune pod smurf teardrop apache2 udpstorm processtable worm mailbomb",
           "Probe": "satan ipsweep nmap portsweep mscan saint",
           "R2L": "guess_passwd ftp_write imap phf multihop warezmaster warezclient spy xlock "
                  "xsnoop snmpguess snmpgetattack httptunnel sendmail named",
           "U2R": "buffer_overflow loadmodule rootkit perl sqlattack xterm ps"}
    m = {"normal": "Normal"}
    for k, v in cat.items():
        for a in v.split(): m[a] = k
    y = df["label"].map(m)
    assert y.notna().all(), df["label"][y.isna()].unique()
    X = df.drop(columns=["label", "difficulty"])
    X = pd.get_dummies(X, columns=["protocol_type", "service", "flag"], dtype=np.float32)
    X = X.astype(np.float32); y = y.astype(str)
    X.attrs["official_test_mask"] = np.r_[np.zeros(125973, bool), np.ones(22544, bool)]
    return X, y

def load_unsw():
    d = f"{DATA_UNSW}"
    tr = pd.read_csv(f"{d}/UNSW_NB15_training-set.csv")
    te = pd.read_csv(f"{d}/UNSW_NB15_testing-set.csv")
    df = pd.concat([tr, te], ignore_index=True)
    y = df["attack_cat"].astype(str).str.strip()
    X = df.drop(columns=["id", "attack_cat", "label"])          # label = binary leak of target
    X = pd.get_dummies(X, columns=["proto", "service", "state"], dtype=np.float32)
    X = X.astype(np.float32)
    X.attrs["official_test_mask"] = np.r_[np.zeros(len(tr), bool), np.ones(len(te), bool)]
    return X, y

# Bot-IoT (UNSW Canberra 2018). Uploaded file has anonymised headers feature_00..32;
# positions match the published Bot-IoT schema.
BOTIOT_NAMES = ["pkSeqID","stime","flgs","proto","saddr","sport","daddr","dport","pkts",
    "bytes","state","ltime","seq","dur","mean","stddev","smac","dmac","sum","min","max",
    "soui","doui","sco","dco","spkts","dpkts","sbytes","dbytes","rate","srate","drate",
    "attack_flag"]
def load_botiot():
    df = pd.read_csv(f"{BOTIOT_CSV}", low_memory=False)
    df = df[df["attack"] != "category"]                          # stray embedded header row
    df.columns = BOTIOT_NAMES + ["category", "subcategory"]
    y = df["category"].astype(str)
    # drop identifiers/timestamps/sequence (memorisation risk), empty MAC/OUI/country
    # columns, and the label-derived columns (attack_flag, subcategory)
    drop = ["pkSeqID","stime","ltime","seq","saddr","daddr","sport","dport","smac","dmac",
            "soui","doui","sco","dco","attack_flag","category","subcategory"]
    X = df.drop(columns=drop)
    X = pd.get_dummies(X, columns=["flgs","proto","state"], dtype=np.float32)
    X = X.apply(pd.to_numeric, errors="coerce").astype(np.float32)
    return X.reset_index(drop=True), y.reset_index(drop=True)

LOADERS = {"nslkdd": load_nslkdd, "unsw": load_unsw, "botiot": load_botiot}

# --------------------------------------------------------------------------
def clean_dedup_cap(X, y, cap, seed):
    X = X.replace([np.inf, -np.inf], np.nan)
    ok = X.notna().all(axis=1); X, y = X[ok], y[ok]
    n0 = len(X)
    key = pd.util.hash_pandas_object(pd.concat([X, y.rename("_y")], axis=1), index=False)
    keep = ~key.duplicated(); X, y = X[keep], y[keep]
    n1 = len(X)
    vc = y.value_counts(); rare = vc[vc < MIN_CLASS].index.tolist()
    X, y = X[~y.isin(rare)], y[~y.isin(rare)]
    if cap:
        rng = np.random.default_rng(seed); idx = []
        for c in y.unique():
            i = np.where(y.values == c)[0]
            idx.append(rng.choice(i, min(cap, len(i)), replace=False))
        idx = np.sort(np.concatenate(idx)); X, y = X.iloc[idx], y.iloc[idx]
    return X.reset_index(drop=True), y.reset_index(drop=True), \
           dict(after_clean=n0, unique=n1, rare_removed=rare,
                counts=y.value_counts().to_dict())

def ece_per_class(P, y, C, bins=10):
    """one-vs-rest ECE of class-c probability column."""
    out = np.zeros(C)
    for c in range(C):
        p = P[:, c]; t = (y == c).astype(float); e = 0.0
        edges = np.linspace(0, 1, bins + 1)
        for i in range(bins):
            m = (p > edges[i]) & (p <= edges[i + 1])
            if m.any(): e += m.mean() * abs(p[m].mean() - t[m].mean())
        out[c] = e
    return out

def run_split(X, y, seed, classes, official=False):
    C = len(classes); m2i = {c: i for i, c in enumerate(classes)}
    yi = y.map(m2i).to_numpy()
    if official:
        mk = X.attrs["official_test_mask"]
        Xtr, Xte, ytr, yte = X.to_numpy()[~mk], X.to_numpy()[mk], yi[~mk], yi[mk]
    else:
        Xtr, Xte, ytr, yte = train_test_split(X.to_numpy(), yi, test_size=0.3,
                                              random_state=seed, stratify=yi)
    sc = MinMaxScaler().fit(Xtr); Xtr, Xte = sc.transform(Xtr), sc.transform(Xte)
    sel = SelectKBest(f_classif, k=min(K_FEAT, Xtr.shape[1])).fit(Xtr, ytr)
    Xtr, Xte = sel.transform(Xtr), sel.transform(Xte)
    Xs, Xv, ys, yv = train_test_split(Xtr, ytr, test_size=0.15, random_state=seed,
                                      stratify=ytr)
    pool = [("RF", RandomForestClassifier(class_weight="balanced", n_jobs=-1, random_state=seed)),
            ("DT", DecisionTreeClassifier(class_weight="balanced", random_state=seed)),
            ("KNN", KNeighborsClassifier(n_jobs=-1)),
            ("LR", LogisticRegression(class_weight="balanced", max_iter=2000))]
    Pv, Pt, F, E = [], [], [], []
    for nm, mo in pool:
        mo.fit(Xs, ys); o = np.argsort(mo.classes_)
        pv = mo.predict_proba(Xv); pt = mo.predict_proba(Xte)
        # align to full class index (a class may be absent from sub-train only if tiny)
        full_v = np.zeros((len(Xv), C)); full_t = np.zeros((len(Xte), C))
        full_v[:, mo.classes_] = pv; full_t[:, mo.classes_] = pt
        Pv.append(full_v); Pt.append(full_t)
        F.append(f1_score(yv, np.argmax(full_v, 1), average=None, labels=np.arange(C),
                          zero_division=0))
        E.append(ece_per_class(full_v, yv, C))
    F = np.stack(F); E = np.stack(E)
    fuse = lambda W, P: np.argmax(sum(W[i][None, :] * P[i] for i in range(len(P))), 1)
    best = (-1, None)
    for g in GAMMA_GRID:
        Fg = np.power(np.maximum(F, 1e-9), g); Wg = Fg / Fg.sum(0, keepdims=True)
        v = f1_score(yv, fuse(Wg, Pv), average="macro", zero_division=0)
        if v > best[0]: best = (v, g)
    g = best[1]
    Fg = np.power(np.maximum(F, 1e-9), g); Wca = Fg / Fg.sum(0, keepdims=True)
    Wu = np.full_like(Wca, 1 / 4)
    Fs = (F.mean(1, keepdims=True)) ** g; Ws = np.repeat(Fs / Fs.sum(0, keepdims=True), C, 1)
    res = {"seed": seed, "gamma": g, "n_train": int(len(Xtr)), "n_test": int(len(Xte)),
           "F": F.round(5).tolist(), "W": Wca.round(5).tolist(),
           "test_support": {classes[c]: int((yte == c).sum()) for c in range(C)}}
    # CHI: mean over classes of (best model - mean model) competence
    gap = F.max(0) - F.mean(0)
    res["CHI"] = float(gap.mean()); res["CHI_per_class"] = {classes[c]: float(gap[c]) for c in range(C)}
    res["ECE_matrix"] = E.round(5).tolist()
    res["calib_heterogeneity"] = float((E.max(0) - E.min(0)).mean())
    # extra baselines on identical partitions
    svm = LinearSVC(class_weight="balanced", max_iter=5000, dual="auto").fit(Xs, ys)
    hgb = HistGradientBoostingClassifier(class_weight="balanced", random_state=seed).fit(Xs, ys)
    extra = {"SVM": svm.predict(Xte), "HistGB": hgb.predict(Xte)}
    for tag, pr in [("CA-WSV", fuse(Wca, Pt)), ("Scalar", fuse(Ws, Pt)), ("Uniform", fuse(Wu, Pt)),
                    ("RF", np.argmax(Pt[0], 1)), ("DT", np.argmax(Pt[1], 1)),
                    ("KNN", np.argmax(Pt[2], 1)), ("LR", np.argmax(Pt[3], 1)),
                    ("SVM", extra["SVM"]), ("HistGB", extra["HistGB"])]:
        f1c = f1_score(yte, pr, average=None, labels=np.arange(C), zero_division=0)
        res[tag] = {"acc": float(accuracy_score(yte, pr)),
                    "macro_f1": float(f1_score(yte, pr, average="macro", zero_division=0)),
                    "weighted_f1": float(f1_score(yte, pr, average="weighted", zero_division=0)),
                    "mcc": float(matthews_corrcoef(yte, pr)),
                    "per_class_f1": {classes[c]: round(float(f1c[c]), 4) for c in range(C)}}
    return res

if __name__ == "__main__":
    name = sys.argv[1]; seeds = [int(s) for s in sys.argv[2].split(",")] if sys.argv[2] != "official" else [0]
    cap = int(sys.argv[3]) if len(sys.argv) > 3 else 100_000
    X, y = LOADERS[name](); log(f"{name}: raw {X.shape}, classes {y.nunique()}")
    if sys.argv[2] == "official":
        mk = X.attrs["official_test_mask"]  # capture before .replace() drops .attrs
        X = X.replace([np.inf, -np.inf], np.nan); assert X.notna().all().all()
        X.attrs["official_test_mask"] = mk  # reattach to the new frame
        meta = dict(mode="official train/test partition", counts=y.value_counts().to_dict())
    else:
        X, y, meta = clean_dedup_cap(X, y, cap, 0)
    classes = sorted(y.unique()); log(f"after protocol: {X.shape}  {meta['counts']}")
    official = (sys.argv[2] == "official"); seeds = [0] if official else seeds
    out = f"{OUT}/{name}_{'official' if official else 'cap'+str(cap)}.jsonl"
    for s in seeds:
        r = run_split(X, y, s, classes, official=official); r["meta"] = meta
        open(out, "a").write(json.dumps(r) + "\n")
        log(f"seed {s}: g={r['gamma']} CA={r['CA-WSV']['macro_f1']:.4f} "
            f"Scalar={r['Scalar']['macro_f1']:.4f} Uni={r['Uniform']['macro_f1']:.4f} "
            f"KNN={r['KNN']['macro_f1']:.4f} RF={r['RF']['macro_f1']:.4f} CHI={r['CHI']:.4f}")
