"""
Specialisation Index (SI) vs CHI vs realised gain, and the label-conflict audit
(share of unique feature vectors that occur with more than one class label).
Usage: python src/analysis_si_label_conflict.py
"""
import json, sys, numpy as np, pandas as pd
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from run_ds import load_unsw, load_botiot, RESULTS

def SI(F):
    F = np.array(F); ms = F.mean(1).argmax(); return float((F.max(0) - F[ms]).mean())
def CHI(F):
    F = np.array(F); return float((F.max(0) - F.mean(0)).mean())

def label_conflict(name, loader):
    X, y = loader(); X = X.replace([np.inf, -np.inf], np.nan); ok = X.notna().all(1); X, y = X[ok], y[ok]
    h = pd.util.hash_pandas_object(X, index=False)
    g = pd.DataFrame({"h": h.values, "y": y.values}).drop_duplicates()
    nl = g.groupby("h")["y"].nunique(); conf = set(nl[nl > 1].index); uniq = g["h"].nunique()
    print(f"{name}: unique vectors={uniq}, with >1 label={len(conf)} ({100*len(conf)/uniq:.2f}%)")
    share = 100 * g[g.h.isin(conf)]["y"].value_counts() / g["y"].value_counts()
    print(share.fillna(0).round(1).sort_values(ascending=False).to_string())

if __name__ == "__main__":
    label_conflict("UNSW-NB15", load_unsw); label_conflict("Bot-IoT", load_botiot)
    print("\nsetting | SI | CHI | dCA-Scalar | n")
    for fn in ["nslkdd_cap100000", "unsw_cap100000", "botiot_cap100000", "cicids2018_cap100000",
               "nslkdd_official", "unsw_official"]:
        p = Path(RESULTS) / f"{fn}.jsonl"
        if not p.exists(): continue
        rows = [json.loads(l) for l in open(p)]
        d = [r["CA-WSV"]["macro_f1"] - r["Scalar"]["macro_f1"] for r in rows]
        print(f"{fn:22s} SI={np.mean([SI(r['F']) for r in rows]):.4f} CHI={np.mean([CHI(r['F']) for r in rows]):.4f} "
              f"d={np.mean(d):+.4f} n={len(rows)}")
