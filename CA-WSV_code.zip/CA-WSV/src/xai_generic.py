"""
Genuine XAI validation for CA-WSV on any dataset.
Usage: python src/xai_generic.py <nslkdd|unsw|botiot>

Explains the FULL CA-WSV fused predictor (not just one base model) via:
  - TreeSHAP for RF and DT members (exact, fast)
  - shap.LinearExplainer for LR (exact)
  - shap.KernelExplainer for KNN (model-agnostic, sampled)
  - A model-agnostic SHAP wrapper around the CA-WSV fused probability
    function s_c(x) = sum_m w_{m,c} p_m(c|x), explained with KernelExplainer
    against a background sample, for the predicted class of each instance.

Quantitative validation (not just plots):
  1. Fidelity        - R^2 between SHAP additive reconstruction (phi.sum()+base)
                        and the model's actual output, on held-out instances.
  2. Stability       - cosine similarity of the explanation vector under small
                        Gaussian jitter of the input (mean over repeats).
  3. Sparsity        - Gini coefficient of |phi| (higher = more concentrated
                        attribution onto a few features).
  4. SHAP-LIME consistency - Jaccard overlap of each method's top-k feature set.
  5. Efficiency      - wall-clock time per explanation.

All numbers below are measured, not assumed.
"""
import os as _os
from pathlib import Path as _Path
ROOT = _Path(_os.environ.get("CAWSV_ROOT", _Path(__file__).resolve().parents[1]))
DATA = ROOT / "data"
DATA_NSL = DATA / "nsl-kdd"; DATA_UNSW = DATA / "unsw-nb15"; DATA_CIC = DATA / "cic-ids2018"
DATA_CIC_STAGE = DATA / "cic-ids2018-stage"; BOTIOT_CSV = DATA / "bot-iot" / "random_500k.csv"
RESULTS = ROOT / "results"; LEGACY = RESULTS / "cicids2018_legacy"; MODELS = ROOT / "models"
PAPER = ROOT / "paper_assets"; SRC = ROOT / "src"; CKPT = MODELS / "checkpoint.joblib"
LEGACY_POST = LEGACY / "posteriors.npz"; LEGACY_GAMMA = LEGACY / "gamma_sensitivity.json"
for _d in (RESULTS, LEGACY, MODELS, PAPER, PAPER / "figures", PAPER / "tables"): _d.mkdir(parents=True, exist_ok=True)
import json, time, sys, warnings
import numpy as np, pandas as pd
warnings.filterwarnings("ignore")
sys.path.insert(0, f"{SRC}")
from run_ds import LOADERS, clean_dedup_cap, ece_per_class
DS = sys.argv[1]
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler
from sklearn.feature_selection import SelectKBest, f_classif
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import f1_score
import shap
import lime
import lime.lime_tabular

t0 = time.time()
def log(m): print(f"[{time.time()-t0:6.0f}s] {m}", flush=True)

SEED = 0
GAMMA_GRID = [0.5, 1, 2, 3, 4, 6, 8]
N_EXPLAIN = 60      # instances to explain per analysis (kept small for KernelExplainer cost)
N_BACKGROUND = 100  # background sample for KernelExplainer
N_STABILITY_REPEATS = 5
JITTER_STD = 0.01   # relative to [0,1]-scaled feature range

log(f"loading {DS} ...")
X, y = LOADERS[DS]()
X, y, meta = clean_dedup_cap(X, y, cap=100_000, seed=0)
classes = sorted(y.unique()); C = len(classes); m2i = {c: i for i, c in enumerate(classes)}
yi = y.map(m2i).to_numpy()
feat_names = X.columns.tolist()
log(f"data ready: {X.shape}, classes={classes}")

Xtr, Xte, ytr, yte = train_test_split(X.to_numpy(), yi, test_size=0.3, random_state=SEED, stratify=yi)
sc = MinMaxScaler().fit(Xtr); Xtr_s, Xte_s = sc.transform(Xtr), sc.transform(Xte)
sel = SelectKBest(f_classif, k=min(20, Xtr_s.shape[1])).fit(Xtr_s, ytr)
sel_idx = sel.get_support(indices=True)
sel_names = [feat_names[i] for i in sel_idx]
Xtr_k, Xte_k = sel.transform(Xtr_s), sel.transform(Xte_s)
Xs, Xv, ys, yv = train_test_split(Xtr_k, ytr, test_size=0.15, random_state=SEED, stratify=ytr)
log(f"selected features ({len(sel_names)}): {sel_names}")

pool = {"RF": RandomForestClassifier(class_weight="balanced", n_jobs=-1, random_state=SEED),
        "DT": DecisionTreeClassifier(class_weight="balanced", random_state=SEED),
        "KNN": KNeighborsClassifier(n_jobs=-1),
        "LR": LogisticRegression(class_weight="balanced", max_iter=2000)}
for nm, mo in pool.items(): mo.fit(Xs, ys)
log("base models fitted")

# --- CA-WSV weight matrix (gamma selected on validation, exactly as in run_ds.py) ---
F = []
for nm, mo in pool.items():
    pv = np.zeros((len(Xv), C)); o = mo.classes_
    pv[:, o] = mo.predict_proba(Xv)
    F.append(f1_score(yv, np.argmax(pv, 1), average=None, labels=np.arange(C), zero_division=0))
F = np.stack(F)
best = (-1, None)
Pv_cache = {}
for nm, mo in pool.items():
    pv = np.zeros((len(Xv), C)); pv[:, mo.classes_] = mo.predict_proba(Xv); Pv_cache[nm] = pv
names = list(pool.keys())
for g in GAMMA_GRID:
    Fg = np.power(np.maximum(F, 1e-9), g); Wg = Fg / Fg.sum(0, keepdims=True)
    fused = np.argmax(sum(Wg[i][None, :] * Pv_cache[names[i]] for i in range(len(names))), 1)
    v = f1_score(yv, fused, average="macro", zero_division=0)
    if v > best[0]: best = (v, g)
gamma = best[1]
Fg = np.power(np.maximum(F, 1e-9), gamma); W = Fg / Fg.sum(0, keepdims=True)  # (M,C)
log(f"CA-WSV weight matrix fitted, gamma*={gamma}, val macroF1={best[0]:.4f}")

def cawsv_proba(Xarr):
    """Full CA-WSV fused predictor s_c(x) for an array of raw (selected, scaled) features."""
    tot = np.zeros((Xarr.shape[0], C))
    for i, nm in enumerate(names):
        mo = pool[nm]
        p = np.zeros((Xarr.shape[0], C)); p[:, mo.classes_] = mo.predict_proba(Xarr)
        tot += W[i][None, :] * p
    return tot

def cawsv_predict_class_fn(target_class):
    def f(Xarr): return cawsv_proba(Xarr)[:, target_class]
    return f

# ============================================================================
# 1) TreeSHAP for RF and DT  (exact, fast, explains each member directly)
# ============================================================================
log("TreeSHAP: RF, DT ...")
expl_rf = shap.TreeExplainer(pool["RF"])
expl_dt = shap.TreeExplainer(pool["DT"])
idx_explain = np.random.default_rng(0).choice(len(Xte_k), size=N_EXPLAIN, replace=False)
Xexp = Xte_k[idx_explain]; yexp = yte[idx_explain]

t_rf0 = time.time(); sv_rf = expl_rf.shap_values(Xexp); t_rf = (time.time() - t_rf0) / len(Xexp)
t_dt0 = time.time(); sv_dt = expl_dt.shap_values(Xexp); t_dt = (time.time() - t_dt0) / len(Xexp)
log(f"TreeSHAP done. RF {t_rf*1000:.2f} ms/instance, DT {t_dt*1000:.2f} ms/instance")

# shap_values shape handling (list-of-arrays per class, or (n,feat,C) array depending on shap version)
def get_class_shap(sv, cls_idx):
    if isinstance(sv, list):
        return sv[cls_idx]
    arr = np.asarray(sv)
    if arr.ndim == 3:
        return arr[:, :, cls_idx]
    return arr

# ============================================================================
# 2) LinearExplainer for LR (exact)
# ============================================================================
log("LinearExplainer: LR ...")
expl_lr = shap.LinearExplainer(pool["LR"], Xs)
t_lr0 = time.time(); sv_lr = expl_lr.shap_values(Xexp); t_lr = (time.time() - t_lr0) / len(Xexp)
log(f"LinearSHAP done. {t_lr*1000:.2f} ms/instance")

# ============================================================================
# 3) KernelExplainer for KNN (model-agnostic, sampled background)
# ============================================================================
log("KernelExplainer: KNN (this is the slow one) ...")
rng = np.random.default_rng(1)
bg_idx = rng.choice(len(Xs), size=min(N_BACKGROUND, len(Xs)), replace=False)
background = Xs[bg_idx]

def knn_proba_fn(Xarr):
    mo = pool["KNN"]; p = np.zeros((Xarr.shape[0], C)); p[:, mo.classes_] = mo.predict_proba(Xarr)
    return p

N_KNN_EXPLAIN = 12  # KernelExplainer is expensive; smaller subsample, stated explicitly
idx_knn = idx_explain[:N_KNN_EXPLAIN]
Xexp_knn = Xte_k[idx_knn]
t_knn0 = time.time()
expl_knn = shap.KernelExplainer(knn_proba_fn, background)
sv_knn = expl_knn.shap_values(Xexp_knn, nsamples=100, silent=True)
t_knn = (time.time() - t_knn0) / len(Xexp_knn)
log(f"KernelSHAP (KNN) done on {N_KNN_EXPLAIN} instances. {t_knn*1000:.1f} ms/instance")

# ============================================================================
# 4) CA-WSV fused predictor - model-agnostic SHAP over the FULL ensemble
#    (the explicit requirement: explain the fused predictor, not RF alone)
# ============================================================================
log("KernelExplainer: full CA-WSV fused predictor (slowest, smallest sample) ...")
N_FUSED_EXPLAIN = 12
idx_fused = idx_explain[:N_FUSED_EXPLAIN]
Xexp_fused = Xte_k[idx_fused]
pred_classes_fused = np.argmax(cawsv_proba(Xexp_fused), axis=1)

fused_shap = {}  # per-instance: shap vector for its predicted class
t_f0 = time.time()
for ci in sorted(set(pred_classes_fused.tolist())):
    rows = np.where(pred_classes_fused == ci)[0]
    expl = shap.KernelExplainer(cawsv_predict_class_fn(ci), background)
    sv = expl.shap_values(Xexp_fused[rows], nsamples=100, silent=True)
    for r, row_i in enumerate(rows):
        fused_shap[idx_fused[row_i]] = (np.array(sv[r]), ci)
t_fused = (time.time() - t_f0) / len(Xexp_fused)
log(f"Fused-model SHAP done on {N_FUSED_EXPLAIN} instances, {t_fused*1000:.1f} ms/instance "
    f"(per predicted class, {len(set(pred_classes_fused.tolist()))} distinct classes seen)")

# ============================================================================
# 5) LIME (complementary) on the same instances as the fused SHAP explanation
# ============================================================================
log("LIME: full CA-WSV fused predictor ...")
lime_explainer = lime.lime_tabular.LimeTabularExplainer(
    Xs, feature_names=sel_names, class_names=[classes[i] for i in range(C)],
    discretize_continuous=True, random_state=0)

lime_results = {}
t_l0 = time.time()
for i, row_i in enumerate(idx_fused):
    ci = pred_classes_fused[i]
    exp = lime_explainer.explain_instance(Xte_k[row_i], cawsv_proba, num_features=10, labels=[ci])
    lime_results[int(row_i)] = {"class": int(ci), "weights": exp.as_list(label=ci)}
t_lime = (time.time() - t_l0) / len(idx_fused)
log(f"LIME done, {t_lime*1000:.1f} ms/instance")

# ============================================================================
# QUANTITATIVE VALIDATION
# ============================================================================
log("validation: fidelity, stability, sparsity, SHAP-LIME consistency ...")

def gini(x):
    x = np.sort(np.abs(x)); n = len(x)
    if x.sum() == 0: return 0.0
    cum = np.cumsum(x)
    return float((n + 1 - 2 * (cum.sum() / cum[-1])) / n)

# --- Fidelity: additive reconstruction vs actual model output, fused predictor ---
fidelity_errs = []
for row_i, (sv, ci) in fused_shap.items():
    actual = cawsv_proba(Xte_k[row_i:row_i+1])[0, ci]
    base = cawsv_predict_class_fn(ci)(background).mean()
    recon = base + sv.sum()
    fidelity_errs.append(abs(actual - recon))
fidelity_mae = float(np.mean(fidelity_errs))

# --- Stability: cosine similarity of fused-SHAP vector under Gaussian jitter ---
stab_sims = []
rngj = np.random.default_rng(2)
for row_i, (sv0, ci) in list(fused_shap.items())[:6]:  # subset, KernelExplainer cost
    x0 = Xte_k[row_i:row_i+1]
    expl = shap.KernelExplainer(cawsv_predict_class_fn(ci), background)
    for _ in range(N_STABILITY_REPEATS):
        xj = x0 + rngj.normal(0, JITTER_STD, size=x0.shape)
        xj = np.clip(xj, 0, 1)
        svj = np.array(expl.shap_values(xj, nsamples=100, silent=True)[0])
        num = np.dot(sv0, svj); den = (np.linalg.norm(sv0) * np.linalg.norm(svj) + 1e-12)
        stab_sims.append(float(num / den))
stability_mean = float(np.mean(stab_sims)); stability_std = float(np.std(stab_sims))

# --- Sparsity: Gini of |phi| for fused explanations, RF, DT, LR, KNN ---
sparsity = {
    "CA-WSV_fused": float(np.mean([gini(sv) for sv, _ in fused_shap.values()])),
    "RF": float(np.mean([gini(get_class_shap(sv_rf, pred_classes_fused[0])[i]) for i in range(len(Xexp))])),
    "LR": float(np.mean([gini(get_class_shap(sv_lr, 0)[i]) for i in range(len(Xexp))])),
}

# --- SHAP-LIME consistency: Jaccard of top-5 feature sets, fused predictor ---
jaccards = []
for row_i, (sv, ci) in fused_shap.items():
    top_shap = set(np.array(sel_names)[np.argsort(-np.abs(sv))[:5]])
    lw = lime_results.get(int(row_i))
    if lw is None: continue
    top_lime = set()
    for feat_str, _ in sorted(lw["weights"], key=lambda t: -abs(t[1]))[:5]:
        for fn in sel_names:
            if fn in feat_str: top_lime.add(fn); break
    if top_shap and top_lime:
        jaccards.append(len(top_shap & top_lime) / len(top_shap | top_lime))
shap_lime_jaccard = float(np.mean(jaccards)) if jaccards else None

# --- Global feature importance (mean |SHAP|) for the fused predictor, aggregated ---
all_fused_abs = np.array([np.abs(sv) for sv, _ in fused_shap.values()])
global_importance = dict(sorted(
    {sel_names[j]: float(all_fused_abs[:, j].mean()) for j in range(len(sel_names))}.items(),
    key=lambda kv: -kv[1]))

# --- Real faithfulness check: top-SHAP-feature ablation vs random-feature ablation ---
# (the additive-reconstruction "fidelity" above is a trivial consequence of the
#  Shapley efficiency axiom, not independent evidence; this is the meaningful test)
log("faithfulness: top-SHAP ablation vs random ablation (deletion test) ...")
bg_mean = background.mean(axis=0)
def deletion_curve(x0, ci, order):
    probs = [cawsv_predict_class_fn(ci)(x0.reshape(1, -1))[0]]
    xcur = x0.copy()
    for j in order:
        xcur = xcur.copy(); xcur[j] = bg_mean[j]
        probs.append(cawsv_predict_class_fn(ci)(xcur.reshape(1, -1))[0])
    return np.array(probs)

rng_order = np.random.default_rng(3)
auc_top, auc_rand = [], []
for row_i, (sv, ci) in fused_shap.items():
    x0 = Xte_k[row_i]
    top_order = np.argsort(-np.abs(sv))
    rand_order = rng_order.permutation(len(sv))
    c_top = deletion_curve(x0, ci, top_order)
    c_rand = deletion_curve(x0, ci, rand_order)
    trapz = np.trapezoid if hasattr(np, "trapezoid") else np.trapz
    auc_top.append(float(trapz(c_top) / len(c_top)))
    auc_rand.append(float(trapz(c_rand) / len(c_rand)))
faithfulness = {"mean_AUC_deleting_top_shap_features": float(np.mean(auc_top)),
                "mean_AUC_deleting_random_order": float(np.mean(auc_rand)),
                "gap": float(np.mean(auc_rand) - np.mean(auc_top)),
                "interpretation": "larger positive gap = SHAP ranking removes predictive mass "
                                   "faster than a random feature order = more faithful"}
log(f"faithfulness: AUC_top={faithfulness['mean_AUC_deleting_top_shap_features']:.4f} "
    f"AUC_random={faithfulness['mean_AUC_deleting_random_order']:.4f} gap={faithfulness['gap']:.4f}")

report = {
    "dataset": DS, "gamma": gamma, "selected_features": sel_names,
    "n_explain_tree": N_EXPLAIN, "n_explain_knn": N_KNN_EXPLAIN, "n_explain_fused": N_FUSED_EXPLAIN,
    "timing_ms_per_instance": {"TreeSHAP_RF": t_rf*1000, "TreeSHAP_DT": t_dt*1000,
                                "LinearSHAP_LR": t_lr*1000, "KernelSHAP_KNN": t_knn*1000,
                                "KernelSHAP_fused_CAWSV": t_fused*1000, "LIME_fused": t_lime*1000},
    "fidelity_mae_fused_trivial_check": fidelity_mae,
    "faithfulness_deletion_test": faithfulness,
    "stability_cosine_sim_fused": {"mean": stability_mean, "std": stability_std,
                                    "n_jitter_repeats": N_STABILITY_REPEATS, "jitter_std": JITTER_STD},
    "sparsity_gini": sparsity,
    "shap_lime_top5_jaccard_fused": shap_lime_jaccard,
    "global_feature_importance_fused_meanabs_shap": global_importance,
}
with open(f"{RESULTS}/xai_{DS}.json", "w") as f:
    json.dump(report, f, indent=2)
log(f"saved {RESULTS}/xai_{DS}.json")
print(json.dumps({k: v for k, v in report.items() if k != "global_feature_importance_fused_meanabs_shap"}, indent=2))
print("\nTop 10 globally important features (fused CA-WSV, mean |SHAP|):")
for k, v in list(global_importance.items())[:10]:
    print(f"  {k:30s} {v:.5f}")
