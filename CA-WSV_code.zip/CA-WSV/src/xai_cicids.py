"""
Genuine XAI validation for CA-WSV on CSE-CIC-IDS2018, mirroring xai_nslkdd.py
exactly (same metrics, same methods) so the two datasets are directly
comparable. Loads the persisted model bundle from cicids_run.py instead of
retraining, since retraining is itself expensive here.
"""
import os as _os
from pathlib import Path as _Path
ROOT = _Path(_os.environ.get("CAWSV_ROOT", _Path(__file__).resolve().parents[1]))
DATA = ROOT / "data"
DATA_NSL = DATA / "nsl-kdd"; DATA_UNSW = DATA / "unsw-nb15"; DATA_CIC = DATA / "cic-ids2018"
DATA_CIC_STAGE = DATA / "cic-ids2018-stage"; BOTIOT_CSV = DATA / "bot-iot" / "random_500k.csv"
RESULTS = ROOT / "results"; LEGACY = RESULTS / "cicids2018_legacy"; MODELS = ROOT / "models"
PAPER = ROOT / "paper_assets"; SRC = ROOT / "src"; CKPT = MODELS / "checkpoint.joblib"
LEGACY_POST = LEGACY / "posteriors.npz"; LEGACY_GAMMA = LEGACY / "gamma_sensitivity.json"
for _d in (RESULTS, LEGACY, MODELS, PAPER, PAPER / "figures", PAPER / "tables"): _d.mkdir(parents=True, exist_ok=True)
import json, time, pickle, warnings
import numpy as np
warnings.filterwarnings("ignore")
import shap, lime, lime.lime_tabular

t0 = time.time()
def log(m): print(f"[{time.time()-t0:6.0f}s] {m}", flush=True)

N_EXPLAIN = 60
N_BACKGROUND = 100
N_KNN_EXPLAIN = 15
N_FUSED_EXPLAIN = 12
N_STABILITY_REPEATS = 5
JITTER_STD = 0.01

log("loading model bundle ...")
with open(f"{MODELS}/bundle_cap100000.pkl", "rb") as f:
    B = pickle.load(f)
pool = B["pool"]; W = B["W"]; gamma = B["gamma"]; classes = B["classes"]
sel_names = B["sel_names"]; Xs = B["Xs"]; Xv = B["Xv"]; ys = B["ys"]; yv = B["yv"]
Xte_k = B["Xte_k"]; yte = B["yte"]
C = len(classes); names = list(pool.keys())
log(f"bundle loaded: classes={classes}, gamma*={gamma}, n_train={len(Xs)}, n_test={len(Xte_k)}")

def cawsv_proba(Xarr):
    tot = np.zeros((Xarr.shape[0], C))
    for i, nm in enumerate(names):
        mo = pool[nm]; p = np.zeros((Xarr.shape[0], C)); p[:, mo.classes_] = mo.predict_proba(Xarr)
        tot += W[i][None, :] * p
    return tot

def cawsv_predict_class_fn(target_class):
    def f(Xarr): return cawsv_proba(Xarr)[:, target_class]
    return f

log("TreeSHAP: RF, DT ...")
expl_rf = shap.TreeExplainer(pool["RF"]); expl_dt = shap.TreeExplainer(pool["DT"])
idx_explain = np.random.default_rng(0).choice(len(Xte_k), size=N_EXPLAIN, replace=False)
Xexp = Xte_k[idx_explain]
t_rf0 = time.time(); sv_rf = expl_rf.shap_values(Xexp); t_rf = (time.time() - t_rf0) / len(Xexp)
t_dt0 = time.time(); sv_dt = expl_dt.shap_values(Xexp); t_dt = (time.time() - t_dt0) / len(Xexp)
log(f"TreeSHAP done. RF {t_rf*1000:.2f} ms/instance, DT {t_dt*1000:.2f} ms/instance")

def get_class_shap(sv, cls_idx):
    if isinstance(sv, list): return sv[cls_idx]
    arr = np.asarray(sv)
    return arr[:, :, cls_idx] if arr.ndim == 3 else arr

log("LinearExplainer: LR ...")
expl_lr = shap.LinearExplainer(pool["LR"], Xs)
t_lr0 = time.time(); sv_lr = expl_lr.shap_values(Xexp); t_lr = (time.time() - t_lr0) / len(Xexp)
log(f"LinearSHAP done. {t_lr*1000:.3f} ms/instance")

log("KernelExplainer: KNN ...")
rng = np.random.default_rng(1)
bg_idx = rng.choice(len(Xs), size=min(N_BACKGROUND, len(Xs)), replace=False)
background = Xs[bg_idx]
def knn_proba_fn(Xarr):
    mo = pool["KNN"]; p = np.zeros((Xarr.shape[0], C)); p[:, mo.classes_] = mo.predict_proba(Xarr)
    return p
idx_knn = idx_explain[:N_KNN_EXPLAIN]; Xexp_knn = Xte_k[idx_knn]
t_knn0 = time.time()
expl_knn = shap.KernelExplainer(knn_proba_fn, background)
sv_knn = expl_knn.shap_values(Xexp_knn, nsamples=100, silent=True)
t_knn = (time.time() - t_knn0) / len(Xexp_knn)
log(f"KernelSHAP (KNN) done on {N_KNN_EXPLAIN} instances. {t_knn*1000:.1f} ms/instance")

log("KernelExplainer: full CA-WSV fused predictor ...")
idx_fused = idx_explain[:N_FUSED_EXPLAIN]; Xexp_fused = Xte_k[idx_fused]
pred_classes_fused = np.argmax(cawsv_proba(Xexp_fused), axis=1)
fused_shap = {}
t_f0 = time.time()
for ci in sorted(set(pred_classes_fused.tolist())):
    rows = np.where(pred_classes_fused == ci)[0]
    expl = shap.KernelExplainer(cawsv_predict_class_fn(ci), background)
    sv = expl.shap_values(Xexp_fused[rows], nsamples=100, silent=True)
    for r, row_i in enumerate(rows):
        fused_shap[idx_fused[row_i]] = (np.array(sv[r]), ci)
t_fused = (time.time() - t_f0) / len(Xexp_fused)
log(f"Fused-model SHAP done on {N_FUSED_EXPLAIN} instances, {t_fused*1000:.1f} ms/instance "
    f"({len(set(pred_classes_fused.tolist()))} distinct predicted classes)")

log("LIME: full CA-WSV fused predictor ...")
lime_explainer = lime.lime_tabular.LimeTabularExplainer(
    Xs, feature_names=sel_names, class_names=classes, discretize_continuous=True, random_state=0)
lime_results = {}
t_l0 = time.time()
for i, row_i in enumerate(idx_fused):
    ci = pred_classes_fused[i]
    exp = lime_explainer.explain_instance(Xte_k[row_i], cawsv_proba, num_features=10, labels=[ci])
    lime_results[int(row_i)] = {"class": int(ci), "weights": exp.as_list(label=ci)}
t_lime = (time.time() - t_l0) / len(idx_fused)
log(f"LIME done, {t_lime*1000:.1f} ms/instance")

log("validation: fidelity, faithfulness, stability, sparsity, consistency ...")
def gini(x):
    x = np.sort(np.abs(x)); n = len(x)
    if x.sum() == 0: return 0.0
    cum = np.cumsum(x)
    return float((n + 1 - 2 * (cum.sum() / cum[-1])) / n)

fidelity_errs = []
for row_i, (sv, ci) in fused_shap.items():
    actual = cawsv_proba(Xte_k[row_i:row_i+1])[0, ci]
    base = cawsv_predict_class_fn(ci)(background).mean()
    fidelity_errs.append(abs(actual - (base + sv.sum())))
fidelity_mae = float(np.mean(fidelity_errs))

bg_mean = background.mean(axis=0)
def deletion_curve(x0, ci, order):
    probs = [cawsv_predict_class_fn(ci)(x0.reshape(1, -1))[0]]
    xcur = x0.copy()
    for j in order:
        xcur = xcur.copy(); xcur[j] = bg_mean[j]
        probs.append(cawsv_predict_class_fn(ci)(xcur.reshape(1, -1))[0])
    return np.array(probs)
trapz = np.trapezoid if hasattr(np, "trapezoid") else np.trapz
rng_order = np.random.default_rng(3)
auc_top, auc_rand = [], []
for row_i, (sv, ci) in fused_shap.items():
    x0 = Xte_k[row_i]
    c_top = deletion_curve(x0, ci, np.argsort(-np.abs(sv)))
    c_rand = deletion_curve(x0, ci, rng_order.permutation(len(sv)))
    auc_top.append(float(trapz(c_top) / len(c_top))); auc_rand.append(float(trapz(c_rand) / len(c_rand)))
faithfulness = {"mean_AUC_deleting_top_shap_features": float(np.mean(auc_top)),
                "mean_AUC_deleting_random_order": float(np.mean(auc_rand)),
                "gap": float(np.mean(auc_rand) - np.mean(auc_top))}
log(f"faithfulness gap={faithfulness['gap']:.4f}")

stab_sims = []
rngj = np.random.default_rng(2)
for row_i, (sv0, ci) in list(fused_shap.items())[:6]:
    x0 = Xte_k[row_i:row_i+1]
    expl = shap.KernelExplainer(cawsv_predict_class_fn(ci), background)
    for _ in range(N_STABILITY_REPEATS):
        xj = np.clip(x0 + rngj.normal(0, JITTER_STD, size=x0.shape), 0, 1)
        svj = np.array(expl.shap_values(xj, nsamples=100, silent=True)[0])
        num = np.dot(sv0, svj); den = np.linalg.norm(sv0) * np.linalg.norm(svj) + 1e-12
        stab_sims.append(float(num / den))
stability = {"mean": float(np.mean(stab_sims)), "std": float(np.std(stab_sims))}
log(f"stability mean={stability['mean']:.4f}")

sparsity = {"CA-WSV_fused": float(np.mean([gini(sv) for sv, _ in fused_shap.values()])),
            "RF": float(np.mean([gini(get_class_shap(sv_rf, pred_classes_fused[0])[i]) for i in range(len(Xexp))])),
            "LR": float(np.mean([gini(get_class_shap(sv_lr, 0)[i]) for i in range(len(Xexp))]))}

jaccards = []
for row_i, (sv, ci) in fused_shap.items():
    top_shap = set(np.array(sel_names)[np.argsort(-np.abs(sv))[:5]])
    lw = lime_results.get(int(row_i))
    if lw is None: continue
    top_lime = set()
    for feat_str, _ in sorted(lw["weights"], key=lambda t: -abs(t[1]))[:5]:
        for fn in sel_names:
            if fn in feat_str: top_lime.add(fn); break
    if top_shap and top_lime: jaccards.append(len(top_shap & top_lime) / len(top_shap | top_lime))
shap_lime_jaccard = float(np.mean(jaccards)) if jaccards else None

all_fused_abs = np.array([np.abs(sv) for sv, _ in fused_shap.values()])
global_importance = dict(sorted(
    {sel_names[j]: float(all_fused_abs[:, j].mean()) for j in range(len(sel_names))}.items(),
    key=lambda kv: -kv[1]))

report = {
    "dataset": "CIC-IDS2018", "gamma": gamma, "selected_features": sel_names,
    "n_explain_tree": N_EXPLAIN, "n_explain_knn": N_KNN_EXPLAIN, "n_explain_fused": N_FUSED_EXPLAIN,
    "timing_ms_per_instance": {"TreeSHAP_RF": t_rf*1000, "TreeSHAP_DT": t_dt*1000,
                                "LinearSHAP_LR": t_lr*1000, "KernelSHAP_KNN": t_knn*1000,
                                "KernelSHAP_fused_CAWSV": t_fused*1000, "LIME_fused": t_lime*1000},
    "fidelity_mae_fused_trivial_check": fidelity_mae,
    "faithfulness_deletion_test": faithfulness,
    "stability_cosine_sim_fused": stability,
    "sparsity_gini": sparsity,
    "shap_lime_top5_jaccard_fused": shap_lime_jaccard,
    "global_feature_importance_fused_meanabs_shap": global_importance,
}
with open(f"{RESULTS}/xai_cicids2018.json", "w") as f:
    json.dump(report, f, indent=2)
log(f"saved {RESULTS}/xai_cicids2018.json")
print(json.dumps({k: v for k, v in report.items() if k != "global_feature_importance_fused_meanabs_shap"}, indent=2))
print("\nTop 10 globally important features (fused CA-WSV, mean |SHAP|):")
for k, v in list(global_importance.items())[:10]:
    print(f"  {k:30s} {v:.5f}")
