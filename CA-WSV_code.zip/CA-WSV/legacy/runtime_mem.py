"""Measure train time, test time, per-sample inference, and memory for
every model and the proposed CA-WSV, on identical data."""
import os as _os
from pathlib import Path as _Path
ROOT = _Path(_os.environ.get("CAWSV_ROOT", _Path(__file__).resolve().parents[1]))
DATA = ROOT / "data"
DATA_NSL = DATA / "nsl-kdd"; DATA_UNSW = DATA / "unsw-nb15"; DATA_CIC = DATA / "cic-ids2018"
DATA_CIC_STAGE = DATA / "cic-ids2018-stage"; BOTIOT_CSV = DATA / "bot-iot" / "random_500k.csv"
RESULTS = ROOT / "results"; LEGACY = RESULTS / "cicids2018_legacy"; MODELS = ROOT / "models"
PAPER = ROOT / "paper_assets"; SRC = ROOT / "src"; CKPT = MODELS / "checkpoint.joblib"
LEGACY_POST = LEGACY / "posteriors.npz"; LEGACY_GAMMA = LEGACY / "gamma_sensitivity.json"
for _d in (RESULTS, LEGACY, MODELS, PAPER, PAPER / "figures", PAPER / "tables"): _d.mkdir(parents=True, exist_ok=True)
import json, os, time, gc, sys
import numpy as np, joblib, resource
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import f1_score
SD=f'{DATA_CIC_STAGE}'; C=11; RS=42
s=np.load(f'{SD}/splits.npz'); X_tr,y_tr,X_val,y_val=s['X_tr'],s['y_tr'],s['X_val'],s['y_val']
d=np.load(f'{SD}/data.npz'); X_te=d['X_test']
NTEST=20000                      # inference-timing subset
rng=np.random.default_rng(RS); ti=rng.choice(len(X_te),NTEST,replace=False)
Xs=X_te[ti]
def rss(): return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024
SPEC=[('Random Forest',lambda:RandomForestClassifier(class_weight='balanced',n_jobs=-1,random_state=RS)),
      ('Decision Tree',lambda:DecisionTreeClassifier(class_weight='balanced',random_state=RS)),
      ('KNN',lambda:KNeighborsClassifier(n_jobs=-1)),
      ('Logistic Regression',lambda:LogisticRegression(class_weight='balanced',max_iter=2000))]
res={}; Pv={}; Ps={}; F=[]
for name,ctor in SPEC:
    gc.collect(); m=ctor()
    t=time.perf_counter(); m.fit(X_tr,y_tr); tr=time.perf_counter()-t
    o=np.argsort(m.classes_)
    t=time.perf_counter(); pv=m.predict_proba(X_val)[:,o]; tval=time.perf_counter()-t
    t=time.perf_counter(); ps=m.predict_proba(Xs)[:,o]; tinf=time.perf_counter()-t
    p=f'{SD}/tmp_{name[:3]}.joblib'; joblib.dump(m,p)
    size=os.path.getsize(p)/1e6; os.remove(p)
    Pv[name]=pv; Ps[name]=ps
    F.append(f1_score(y_val,np.argmax(pv,1),average=None,labels=np.arange(C)))
    res[name]=dict(train_s=tr,test_s=tinf,per_sample_ms=tinf/NTEST*1000,
                   model_mb=size,val_infer_s=tval)
    print(f'{name:20s} train={tr:7.2f}s  test({NTEST})={tinf:7.2f}s  '
          f'{tinf/NTEST*1000:.4f} ms/sample  model={size:.1f} MB',flush=True)
    del m; gc.collect()
F=np.stack(F); order=['Random Forest','Decision Tree','KNN','Logistic Regression']
# CA-WSV overhead: weight learning (gamma search on cached val posteriors)
t=time.perf_counter()
best=(-1,None,None)
for g in [0.5,1,2,3,4,6,8]:
    Fg=np.power(np.maximum(F,1e-9),g); Wg=Fg/Fg.sum(0,keepdims=True)
    pred=np.argmax(sum(Wg[i][None,:]*Pv[n] for i,n in enumerate(order)),1)
    v=f1_score(y_val,pred,average='macro')
    if v>best[0]: best=(v,g,Wg)
w_learn=time.perf_counter()-t
_,g,W=best
t=time.perf_counter()
fused=sum(W[i][None,:]*Ps[n] for i,n in enumerate(order)); _=np.argmax(fused,1)
fuse_t=time.perf_counter()-t
base_train=sum(res[n]['train_s'] for n in order)
base_val=sum(res[n]['val_infer_s'] for n in order)
base_test=sum(res[n]['test_s'] for n in order)
res['CA-WSV (proposed)']=dict(
    train_s=base_train+base_val+w_learn, test_s=base_test+fuse_t,
    per_sample_ms=(base_test+fuse_t)/NTEST*1000,
    model_mb=sum(res[n]['model_mb'] for n in order)+W.nbytes/1e6,
    weight_learn_s=w_learn, fusion_s=fuse_t, gamma=int(g),
    fusion_params=int(W.size))
r=res['CA-WSV (proposed)']
print(f"\nCA-WSV: train={r['train_s']:.2f}s (bases {base_train:.2f} + val "
      f"{base_val:.2f} + weights {w_learn:.3f})")
print(f"  test({NTEST})={r['test_s']:.2f}s ({r['per_sample_ms']:.4f} ms/sample); "
      f"fusion only {fuse_t*1000:.1f} ms total")
print(f"  memory={r['model_mb']:.1f} MB; fusion params={r['fusion_params']} "
      f"({W.nbytes} bytes); gamma*={g}")
print(f"peak RSS during measurement: {rss():.0f} MB")
res['_meta']=dict(n_train=int(len(X_tr)),n_val=int(len(X_val)),n_test_timed=NTEST,
                  peak_rss_mb=rss(),cpu='1 vCPU / 4 GB sandbox')
json.dump(res,open('runtime_results.json','w'),indent=1,default=float)
