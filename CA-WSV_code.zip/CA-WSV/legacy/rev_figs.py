import json
import numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.family':'serif','font.serif':['STIXGeneral','DejaVu Serif'],
                     'mathtext.fontset':'stix','svg.fonttype':'none'})
INK,AXIS='#0F172A','#94A3B8'
def style(ax):
    ax.grid(ls=':',lw=0.6,color='#CBD5E1',zorder=0)
    for s in ('top','right'): ax.spines[s].set_visible(False)
    for s in ('left','bottom'): ax.spines[s].set_color(AXIS)
    ax.tick_params(labelsize=6.5,colors=INK,length=2)

# ---------- 1. reject option ----------
R=json.load(open('rev_cheap.json'))['reject_option']
cov=[r['coverage'] for r in R]; far=[r['FAR'] for r in R]
mf=[r['macro_f1'] for r in R]; th=[r['margin_thr'] for r in R]
fig,ax=plt.subplots(figsize=(3.5,2.4))
ax.plot(cov,far,'o-',color='#B91C1C',lw=1.5,ms=4,zorder=3,label='False-alarm rate')
for c,f,t in zip(cov,far,th):
    ax.annotate(f'$\\mu\\geq${t}',(c,f),fontsize=5.2,color='#7F1D1D',
                xytext=(3,4),textcoords='offset points')
ax.set_xlabel('Coverage (fraction of flows classified)',fontsize=8,color=INK)
ax.set_ylabel('False-alarm rate',fontsize=8,color=INK,color2=None) if False else \
    ax.set_ylabel('False-alarm rate',fontsize=8,color='#B91C1C')
ax.set_ylim(0,0.26); ax.invert_xaxis(); style(ax)
ax2=ax.twinx(); ax2.plot(cov,mf,'s--',color='#1D4ED8',lw=1.3,ms=3.5,zorder=3,
                         label='Macro-F1')
ax2.set_ylabel('Macro-F1 (accepted flows)',fontsize=8,color='#1D4ED8')
ax2.set_ylim(0.93,1.0); ax2.tick_params(labelsize=6.5,colors='#1D4ED8',length=2)
for s in ('top','left'): ax2.spines[s].set_visible(False)
ax2.spines['right'].set_color(AXIS)
h1,l1=ax.get_legend_handles_labels(); h2,l2=ax2.get_legend_handles_labels()
ax.legend(h1+h2,l1+l2,frameon=False,fontsize=6.3,loc='center left')
fig.tight_layout(pad=0.4)
for e in ('pdf','png'): fig.savefig(f'reject_option.{e}',dpi=600)
plt.close(fig)

# ---------- 2. sensitivity: CA-WSV vs KNN-free ----------
K=json.load(open('rev_knnfree.json'))
full={r['sigma']:r for r in K['robustness_full']}
nk={r['sigma']:r for r in K['robustness_noKNN']}
sig=[0.0,0.01,0.02,0.05,0.10,0.20]; x=np.arange(len(sig))
fig,ax=plt.subplots(figsize=(3.5,2.3))
ax.plot(x,[full[s]['acc'] for s in sig],'o-',color='#1D4ED8',lw=1.5,ms=4,
        zorder=3,label='CA-WSV (RF, DT, KNN, LR)')
ax.plot(x,[nk[s]['acc'] for s in sig],'s--',color='#B45309',lw=1.4,ms=3.8,
        zorder=3,label='CA-WSV without KNN (RF, DT, LR)')
ax.set_xticks(x); ax.set_xticklabels(['0\n(clean)']+[str(s) for s in sig[1:]],fontsize=6.3)
ax.set_xlabel(r'Gaussian noise $\sigma$ (fraction of scaled feature range)',
              fontsize=7.5,color=INK)
ax.set_ylabel('Accuracy',fontsize=8,color=INK); ax.set_ylim(0,1.02)
style(ax); ax.legend(frameon=False,fontsize=6.3,loc='upper right')
fig.tight_layout(pad=0.4)
for e in ('pdf','png'): fig.savefig(f'sensitivity_knn.{e}',dpi=600)
plt.close(fig)

# ---------- 3. repeated splits with CIs ----------
S=json.load(open('rev_splits100k.json'))['summary']
order=['CA-WSV','KNN','Scalar','Uniform','RF']
lbl=['CA-WSV\n(proposed)','KNN','Scalar-wt\nvoting','Uniform\nvoting','RF']
m=[S[k]['macro_mean'] for k in order]; e=[S[k]['macro_ci'] for k in order]
cols=['#1D4ED8']+['#94A3B8']*4
fig,ax=plt.subplots(figsize=(3.5,2.3))
b=ax.bar(np.arange(5),m,0.6,yerr=e,capsize=3,color=cols,edgecolor='#334155',
         lw=0.6,zorder=3,error_kw=dict(ecolor='#334155',lw=1.0))
for i,(v,er) in enumerate(zip(m,e)):
    ax.text(i,v+er+0.0015,f'{v:.4f}',ha='center',va='bottom',fontsize=5.6,color=INK)
ax.set_xticks(np.arange(5)); ax.set_xticklabels(lbl,fontsize=6.0)
ax.get_xticklabels()[0].set_fontweight('bold')
ax.set_ylabel('Macro-F1',fontsize=8,color=INK); ax.set_ylim(0.925,0.965)
style(ax)
fig.tight_layout(pad=0.4)
for e_ in ('pdf','png'): fig.savefig(f'repeated_splits.{e_}',dpi=600)
plt.close(fig)

# ---------- 4. imbalance scaling (BF-Web F1 at two caps) ----------
S25=json.load(open('rev_splits.json'))['summary']
meth=['CA-WSV','KNN','Scalar','Uniform','RF']
lab2=['CA-WSV','KNN','Scalar','Uniform','RF']
a=[S[k]['bfweb_mean'] for k in meth]; bb=[S25[k]['bfweb_mean'] for k in meth]
x=np.arange(5); w=0.38
fig,ax=plt.subplots(figsize=(3.5,2.3))
ax.bar(x-w/2-0.01,a,w,color='#1D4ED8',edgecolor='#123763',lw=0.6,zorder=3,
       label='cap 100K  (Benign:BF-Web $\\approx$ 181:1)')
ax.bar(x+w/2+0.01,bb,w,color='#93C5FD',edgecolor='#3B72B0',lw=0.6,zorder=3,
       label='cap 25K  ($\\approx$ 45:1)')
for i,(u,v) in enumerate(zip(a,bb)):
    ax.text(i-w/2-0.01,u+0.012,f'{u:.2f}',ha='center',va='bottom',fontsize=5.4,color=INK)
    ax.text(i+w/2+0.01,v+0.012,f'{v:.2f}',ha='center',va='bottom',fontsize=5.4,color=INK)
ax.set_xticks(x); ax.set_xticklabels(lab2,fontsize=6.3)
ax.set_ylabel('Brute Force-Web F1',fontsize=8,color=INK); ax.set_ylim(0,1.12)
style(ax); ax.legend(frameon=False,fontsize=6.0,loc='lower center',
                     bbox_to_anchor=(0.5,0.995),ncol=1)
fig.tight_layout(pad=0.4)
for e_ in ('pdf','png'): fig.savefig(f'imbalance_scaling.{e_}',dpi=600)
plt.close(fig)

from PIL import Image
for f in ['reject_option','sensitivity_knn','repeated_splits','imbalance_scaling']:
    g=np.asarray(Image.open(f+'.png').convert('L'))
    print(f,[(g[:,:3]<200).sum(),(g[:,-3:]<200).sum(),(g[:3,:]<200).sum(),(g[-3:,:]<200).sum()])
