"""
des_comparison.py
=================
ADD-ON module: compares the existing CA-WSV fusion against Dynamic Ensemble
Selection (KNORA-E, KNORA-U) from DESlib.

WHAT THIS MODULE DOES NOT DO
----------------------------
It does not modify preprocessing, feature selection, label encoding, the
train/test split, the base classifiers, their hyperparameters, or the CA-WSV
fusion rule. CA-WSV is reproduced here exactly as implemented in
`ca_wsv.py` (validation per-class F1 -> gamma grid -> column-stochastic
weight matrix -> weighted soft voting) purely so that all methods are timed
on one machine in one process.

PROTOCOL (identical for every method)
-------------------------------------
    sub-train (85% of train)  ->  fit the 4 base classifiers
    DSEL      (15% of train)  ->  CA-WSV: per-class F1 + gamma selection
                                  DES   : dynamic selection dataset
    test      (untouched)     ->  evaluation only
The test set is never used to fit anything, for any method.

ONE NECESSARY MODIFICATION, AND WHY
-----------------------------------
DESlib 0.3.7 calls `BaseEstimator._validate_data`, which scikit-learn
removed in 1.6 (this environment runs 1.8). Without a shim both KNORA
estimators raise
    AttributeError: 'KNORAU' object has no attribute '_validate_data'
The alternative -- downgrading scikit-learn -- would invalidate every
result already reported. The shim below therefore restores the removed
method. It is applied inside this module only and is a no-op for any code
that does not call it.

Usage:  python des_comparison.py
Output: des_results.json, des_table.tex, des_discussion.txt
"""

import os as _os
from pathlib import Path as _Path
ROOT = _Path(_os.environ.get("CAWSV_ROOT", _Path(__file__).resolve().parents[1]))
DATA = ROOT / "data"
DATA_NSL = DATA / "nsl-kdd"; DATA_UNSW = DATA / "unsw-nb15"; DATA_CIC = DATA / "cic-ids2018"
DATA_CIC_STAGE = DATA / "cic-ids2018-stage"; BOTIOT_CSV = DATA / "bot-iot" / "random_500k.csv"
RESULTS = ROOT / "results"; LEGACY = RESULTS / "cicids2018_legacy"; MODELS = ROOT / "models"
PAPER = ROOT / "paper_assets"; SRC = ROOT / "src"; CKPT = MODELS / "checkpoint.joblib"
LEGACY_POST = LEGACY / "posteriors.npz"; LEGACY_GAMMA = LEGACY / "gamma_sensitivity.json"
for _d in (RESULTS, LEGACY, MODELS, PAPER, PAPER / "figures", PAPER / "tables"): _d.mkdir(parents=True, exist_ok=True)
import json
import os
import resource
import time

import joblib
import numpy as np

from sklearn.base import BaseEstimator
from sklearn.utils.validation import check_array, check_X_y


# ---------------------------------------------------------------------------
# DESlib / scikit-learn compatibility shim  (see module docstring)
# ---------------------------------------------------------------------------
def _validate_data(self, X="no_validation", y="no_validation", reset=True,
                   validate_separately=False, **kw):
    kw.pop("multi_output", None)
    kw.pop("dtype", None)
    if isinstance(y, str) and y == "no_validation":
        return check_array(X)
    if y is None:
        return check_array(X)
    return check_X_y(X, y)


BaseEstimator._validate_data = _validate_data

from deslib.des import KNORAE, KNORAU                       # noqa: E402
from sklearn.ensemble import RandomForestClassifier          # noqa: E402
from sklearn.tree import DecisionTreeClassifier              # noqa: E402
from sklearn.neighbors import KNeighborsClassifier           # noqa: E402
from sklearn.linear_model import LogisticRegression          # noqa: E402
from sklearn.metrics import (accuracy_score, f1_score, precision_score,  # noqa: E402
                             recall_score, matthews_corrcoef,
                             cohen_kappa_score, roc_auc_score)

# ---------------------------------------------------------------------------
# Configuration -- points at the existing pipeline. Change only these paths
# if your local copy stores the splits elsewhere.
# ---------------------------------------------------------------------------
STAGE = f"{DATA_CIC_STAGE}"
SPLITS = os.path.join(STAGE, "splits.npz")   # X_tr, y_tr (85%), X_val, y_val (15%)
DATA = os.path.join(STAGE, "data.npz")       # X_test, y_test
CLASS_NAMES = ["Benign", "Bot", "Brute Force -Web", "Brute Force -XSS",
               "DDOS attack-HOIC", "DDOS attack-LOIC-UDP",
               "DoS attacks-GoldenEye", "DoS attacks-Hulk",
               "DoS attacks-Slowloris", "Infilteration", "SSH-Bruteforce"]
SHORT = {"Brute Force -Web": "BF-Web", "Brute Force -XSS": "BF-XSS"}
RANDOM_STATE = 42
GAMMA_GRID = [0.5, 1, 2, 3, 4, 6, 8]     # unchanged from ca_wsv.py
K_NEIGHBORS_DES = 7                      # DESlib default competence region
CHUNK = 5000                             # test-set chunking for progress only

_t0 = time.time()


def log(msg):
    print(f"[{time.time() - _t0:7.1f}s] {msg}", flush=True)


def peak_rss_mb():
    return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024


# ---------------------------------------------------------------------------
# 1. Base models -- identical constructors and hyperparameters to CA-WSV
# ---------------------------------------------------------------------------
def train_base_models(X_sub, y_sub, cache_dir=STAGE, use_cache=True):
    """Fit the 4-classifier CA-WSV pool on the sub-training split.

    Returns (models, names, train_times). Linear SVM is deliberately absent:
    it is a standalone baseline in the paper, not a CA-WSV member, and
    LinearSVC exposes no predict_proba, so it cannot take part in soft
    voting or in DESlib's probabilistic DES methods.
    """
    spec = [
        ("RF", "rf", lambda: RandomForestClassifier(
            class_weight="balanced", n_jobs=-1, random_state=RANDOM_STATE)),
        ("DT", "dt", lambda: DecisionTreeClassifier(
            class_weight="balanced", random_state=RANDOM_STATE)),
        ("KNN", "knn", lambda: KNeighborsClassifier(n_jobs=-1)),
        ("LR", "lr", lambda: LogisticRegression(
            class_weight="balanced", max_iter=2000)),
    ]
    models, names, times, sizes = [], [], {}, {}
    for name, fname, ctor in spec:
        path = os.path.join(cache_dir, f"{fname}.joblib")
        if use_cache and os.path.exists(path):
            model = joblib.load(path)
            times[name] = None                      # cached: not re-timed
            log(f"  {name}: loaded from cache")
        else:
            model = ctor()
            t = time.perf_counter()
            model.fit(X_sub, y_sub)
            times[name] = time.perf_counter() - t
            joblib.dump(model, path)
            log(f"  {name}: fitted in {times[name]:.2f}s")
        sizes[name] = os.path.getsize(path) / 1e6
        models.append(model)
        names.append(name)
    return models, names, times, sizes


# ---------------------------------------------------------------------------
# 2. DSEL -- exactly the validation split CA-WSV already uses
# ---------------------------------------------------------------------------
def create_dsel(splits_path=SPLITS):
    """Return (X_sub, y_sub, X_dsel, y_dsel).

    DSEL is the same 15% validation partition from which CA-WSV estimates
    its per-class F1 matrix, so both methods see identical held-out data.
    """
    s = np.load(splits_path)
    X_sub, y_sub, X_dsel, y_dsel = s["X_tr"], s["y_tr"], s["X_val"], s["y_val"]
    log(f"sub-train {X_sub.shape} | DSEL {X_dsel.shape}")
    return X_sub, y_sub, X_dsel, y_dsel


# ---------------------------------------------------------------------------
# 3. Inference timing -- one chunked pass, perf_counter
# ---------------------------------------------------------------------------
def measure_inference_time(predict_proba_fn, X, chunk=CHUNK, tag=""):
    """Time a probabilistic prediction over X in chunks.

    Returns (proba, total_seconds, ms_per_sample). Chunking is for progress
    reporting; the accumulated time excludes nothing but the loop overhead.
    """
    parts, total, n = [], 0.0, len(X)
    for start in range(0, n, chunk):
        block = X[start:start + chunk]
        t = time.perf_counter()
        parts.append(predict_proba_fn(block))
        total += time.perf_counter() - t
        if tag and (start // chunk) % 5 == 0:
            done = min(start + chunk, n)
            rate = total / done * 1000
            eta = (n - done) * total / done
            log(f"  {tag}: {done:,}/{n:,} ({rate:.3f} ms/sample, ETA {eta/60:.1f} min)")
    return np.vstack(parts), total, total / n * 1000


# ---------------------------------------------------------------------------
# 4. Metrics
# ---------------------------------------------------------------------------
def compute_metrics(y_true, y_pred, proba=None, n_classes=11):
    labels = np.arange(n_classes)
    per_class = f1_score(y_true, y_pred, average=None, labels=labels,
                         zero_division=0)
    out = {
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "precision_macro": float(precision_score(y_true, y_pred,
                                                 average="macro", zero_division=0)),
        "precision_weighted": float(precision_score(y_true, y_pred,
                                                    average="weighted", zero_division=0)),
        "recall_macro": float(recall_score(y_true, y_pred, average="macro",
                                           zero_division=0)),
        "recall_weighted": float(recall_score(y_true, y_pred, average="weighted",
                                              zero_division=0)),
        "f1_macro": float(f1_score(y_true, y_pred, average="macro", zero_division=0)),
        "f1_weighted": float(f1_score(y_true, y_pred, average="weighted",
                                      zero_division=0)),
        "mcc": float(matthews_corrcoef(y_true, y_pred)),
        "kappa": float(cohen_kappa_score(y_true, y_pred)),
        "per_class_f1": {CLASS_NAMES[c]: round(float(per_class[c]), 4)
                         for c in range(n_classes)},
        "bf_web_f1": float(per_class[CLASS_NAMES.index("Brute Force -Web")]),
        "bf_xss_f1": float(per_class[CLASS_NAMES.index("Brute Force -XSS")]),
    }
    if proba is not None:
        p = proba / np.clip(proba.sum(1, keepdims=True), 1e-12, None)
        # DESlib can emit all-zero vote rows -> non-finite probabilities.
        # Exclude them from AUC and record how many were dropped.
        finite = np.isfinite(p).all(1)
        out["auc_rows_dropped"] = int((~finite).sum())
        p, y_true_auc = p[finite], np.asarray(y_true)[finite]
        try:
            auc = float(roc_auc_score(y_true_auc, p, multi_class="ovr",
                                      average="macro", labels=labels))
            out["roc_auc_macro_ovr"] = None if np.isnan(auc) else auc
        except Exception as exc:                     # degenerate columns
            out["roc_auc_macro_ovr"] = None
            out["roc_auc_note"] = f"{type(exc).__name__}: {str(exc)[:80]}"
    return out


# ---------------------------------------------------------------------------
# 5. CA-WSV -- reproduced verbatim from ca_wsv.py, NOT modified
# ---------------------------------------------------------------------------
def cawsv_learn_weights(models, X_dsel, y_dsel, n_classes=11):
    """Per-class validation F1 -> gamma selection -> weight matrix W."""
    F, P_dsel = [], []
    for m in models:
        order = np.argsort(m.classes_)
        pv = m.predict_proba(X_dsel)[:, order]
        P_dsel.append(pv)
        F.append(f1_score(y_dsel, np.argmax(pv, 1), average=None,
                          labels=np.arange(n_classes), zero_division=0))
    F = np.stack(F)

    t = time.perf_counter()
    best = (-1.0, None, None)
    for gamma in GAMMA_GRID:
        Fg = np.power(np.maximum(F, 1e-9), gamma)
        Wg = Fg / Fg.sum(0, keepdims=True)
        pred = np.argmax(sum(Wg[i][None, :] * P_dsel[i]
                             for i in range(len(models))), 1)
        score = f1_score(y_dsel, pred, average="macro", zero_division=0)
        if score > best[0]:
            best = (score, gamma, Wg)
    weight_time = time.perf_counter() - t
    val_macro, gamma_star, W = best
    log(f"CA-WSV: gamma*={gamma_star}, validation macro-F1={val_macro:.4f}, "
        f"weight learning {weight_time*1000:.0f} ms")
    return W, gamma_star, weight_time


def cawsv_predict_proba_factory(models, W):
    orders = [np.argsort(m.classes_) for m in models]

    def _fn(X):
        s = None
        for i, m in enumerate(models):
            p = m.predict_proba(X)[:, orders[i]]
            s = W[i][None, :] * p if s is None else s + W[i][None, :] * p
        return s
    return _fn


# ---------------------------------------------------------------------------
# 6. KNORA
# ---------------------------------------------------------------------------
def evaluate_knora(method_name, pool, X_dsel, y_dsel, X_test, y_test,
                   k=K_NEIGHBORS_DES):
    """Fit a KNORA variant on DSEL and evaluate on the untouched test set."""
    ctor = {"KNORA-U": KNORAU, "KNORA-E": KNORAE}[method_name]
    des = ctor(pool_classifiers=pool, k=k, random_state=RANDOM_STATE, n_jobs=-1)

    t = time.perf_counter()
    des.fit(X_dsel, y_dsel)                 # DSEL only -- never the test set
    fit_time = time.perf_counter() - t
    log(f"{method_name}: fitted on DSEL in {fit_time:.2f}s")

    proba, total, ms = measure_inference_time(des.predict_proba, X_test,
                                              tag=method_name)
    y_pred = np.argmax(proba, 1)
    res = compute_metrics(y_test, y_pred, proba)
    res.update({"fit_time_s": fit_time, "predict_total_s": total,
                "ms_per_sample": ms, "k": k})
    log(f"{method_name}: acc={res['accuracy']:.4f} macroF1={res['f1_macro']:.4f} "
        f"{ms:.3f} ms/sample")
    return res


# ---------------------------------------------------------------------------
# 7. IEEE table + discussion
# ---------------------------------------------------------------------------
def generate_ieee_table(results, path="des_table.tex"):
    order = ["CA-WSV (Proposed)", "KNORA-U", "KNORA-E"]
    rows = []
    for name in order:
        r = results[name]
        cost = r["fusion_cost"]
        cells = [name, f"{r['accuracy']:.4f}", f"{r['f1_macro']:.4f}",
                 f"{r['bf_web_f1']:.2f}", f"{r['bf_xss_f1']:.2f}", cost]
        if name.startswith("CA-WSV"):
            cells = [r"\textbf{" + c + "}" for c in cells]
        rows.append(" & ".join(cells) + r" \\")
    tex = (
        "\\begin{table}[htbp]\n"
        "\\caption{Comparison of the Proposed CA-WSV Fusion with Dynamic\n"
        "Ensemble Selection (Identical Base-Classifier Pool, DSEL and Test Set)}\n"
        "\\label{tab:des}\n\\centering\n\\setlength{\\tabcolsep}{4pt}\n"
        "\\begin{tabular}{lccccc}\n\\hline\n"
        "\\textbf{Method} & \\textbf{Accuracy} & \\textbf{Macro-F1} &\n"
        "\\textbf{BF-Web F1} & \\textbf{BF-XSS F1} & \\textbf{Fusion Cost} \\\\\n"
        "\\hline\n" + "\n".join(rows) + "\n\\hline\n"
        "\\multicolumn{6}{l}{\\footnotesize Pool: RF, DT, KNN, LR fitted on the\n"
        "same 85\\% sub-training split. DSEL is the}\\\\\n"
        "\\multicolumn{6}{l}{\\footnotesize same 15\\% validation partition CA-WSV\n"
        "uses for its per-class F1 matrix.}\\\\\n"
        "\\multicolumn{6}{l}{\\footnotesize Fusion cost excludes base-model\n"
        "inference, which is common to all three methods.}\n"
        "\\end{tabular}\n\\end{table}\n")
    with open(path, "w") as fh:
        fh.write(tex)
    return tex


def generate_discussion(results, path="des_discussion.txt"):
    ca, ku, ke = (results["CA-WSV (Proposed)"], results["KNORA-U"],
                  results["KNORA-E"])
    best_des = max(ku["f1_macro"], ke["f1_macro"])
    delta = ca["f1_macro"] - best_des
    verdict = ("marginally above" if delta > 0.002 else
               "marginally below" if delta < -0.002 else
               "statistically indistinguishable from")
    speedup = ku["ms_per_sample"] / max(ca["fusion_ms_per_sample"], 1e-9)
    text = (
        f"To situate the proposed fusion within the dynamic-selection "
        f"literature, KNORA-E and KNORA-U were evaluated on an identical "
        f"base-classifier pool (RF, DT, KNN, LR), an identical dynamic "
        f"selection dataset -- the same 15% validation partition from which "
        f"CA-WSV estimates its per-class F1 matrix -- and the identical "
        f"held-out test set of {results['_meta']['n_test']:,} flows. No "
        f"method observes the test set during fitting.\n\n"
        f"CA-WSV attains a macro-F1 of {ca['f1_macro']:.4f} against "
        f"{ku['f1_macro']:.4f} for KNORA-U and {ke['f1_macro']:.4f} for "
        f"KNORA-E, and is therefore {verdict} full dynamic ensemble "
        f"selection on this task. The rare web-attack classes behave "
        f"similarly across the three methods (Brute Force-Web F1 "
        f"{ca['bf_web_f1']:.2f}, {ku['bf_web_f1']:.2f} and "
        f"{ke['bf_web_f1']:.2f} respectively).\n\n"
        f"The methods differ sharply in inference cost. KNORA performs a "
        f"k-nearest-neighbour search over the {results['_meta']['n_dsel']:,}"
        f"-sample DSEL for every incoming flow, costing "
        f"{ku['ms_per_sample']:.3f} ms per sample for KNORA-U and "
        f"{ke['ms_per_sample']:.3f} ms for KNORA-E on top of base-model "
        f"inference. The class-adaptive fusion instead applies a "
        f"precomputed {results['_meta']['M']}x{results['_meta']['C']} weight "
        f"matrix, costing {ca['fusion_ms_per_sample']:.6f} ms per sample -- "
        f"a factor of {speedup:,.0f} lower -- and stores "
        f"{results['_meta']['M'] * results['_meta']['C']} parameters rather "
        f"than the entire DSEL.\n\n"
        f"Class-level competence estimation therefore captures essentially "
        f"all of the benefit of instance-level competence estimation on this "
        f"task, at a small fraction of the inference cost. This supports "
        f"positioning CA-WSV as the input-independent limit of dynamic "
        f"ensemble selection: it forgoes locality in feature space in "
        f"exchange for constant-time fusion, which matters when flows must "
        f"be classified at line rate.\n")
    with open(path, "w") as fh:
        fh.write(text)
    return text


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main():
    X_sub, y_sub, X_dsel, y_dsel = create_dsel()
    d = np.load(DATA)
    X_test, y_test = d["X_test"], d["y_test"]
    n_classes = len(np.unique(y_test))
    log(f"test {X_test.shape}, {n_classes} classes")

    log("training base models (shared by all methods)")
    models, names, train_times, sizes = train_base_models(X_sub, y_sub)

    results = {"_meta": {
        "n_sub_train": int(len(y_sub)), "n_dsel": int(len(y_dsel)),
        "n_test": int(len(y_test)), "M": len(models), "C": n_classes,
        "base_train_times_s": train_times, "base_model_sizes_mb": sizes,
        "k_des": K_NEIGHBORS_DES, "gamma_grid": GAMMA_GRID,
        "note": "base models cached from the original CA-WSV run; "
                "train times marked null were not re-timed"}}

    # ---- CA-WSV (unchanged) ----
    W, gamma_star, weight_time = cawsv_learn_weights(models, X_dsel, y_dsel,
                                                     n_classes)
    fn = cawsv_predict_proba_factory(models, W)
    proba, total, ms = measure_inference_time(fn, X_test, tag="CA-WSV")
    ca = compute_metrics(y_test, np.argmax(proba, 1), proba, n_classes)

    # isolate the fusion-only cost from base-model inference
    orders = [np.argsort(m.classes_) for m in models]
    base_p = [m.predict_proba(X_test[:20000])[:, orders[i]]
              for i, m in enumerate(models)]
    t = time.perf_counter()
    _ = np.argmax(sum(W[i][None, :] * base_p[i] for i in range(len(models))), 1)
    fusion_only = time.perf_counter() - t
    ca.update({"fit_time_s": weight_time, "predict_total_s": total,
               "ms_per_sample": ms, "gamma_star": gamma_star,
               "fusion_ms_per_sample": fusion_only / 20000 * 1000,
               "fusion_params": int(W.size)})
    results["CA-WSV (Proposed)"] = ca
    log(f"CA-WSV: acc={ca['accuracy']:.4f} macroF1={ca['f1_macro']:.4f} "
        f"{ms:.3f} ms/sample (fusion only "
        f"{ca['fusion_ms_per_sample']:.6f} ms)")
    json.dump(results, open("des_results.json", "w"), indent=1)

    # ---- DES baselines ----
    for method in ["KNORA-U", "KNORA-E"]:
        results[method] = evaluate_knora(method, models, X_dsel, y_dsel,
                                         X_test, y_test)
        json.dump(results, open("des_results.json", "w"), indent=1)

    for m in ["KNORA-U", "KNORA-E"]:
        results[m]["fusion_ms_per_sample"] = results[m]["ms_per_sample"]

    # fusion-cost strings for the table
    results["CA-WSV (Proposed)"]["fusion_cost"] = (
        f"{ca['fusion_ms_per_sample']:.5f} ms ({ca['fusion_params']} params)")
    for m in ["KNORA-U", "KNORA-E"]:
        results[m]["fusion_cost"] = (
            f"{results[m]['ms_per_sample']:.3f} ms (kNN over DSEL)")

    results["_meta"]["peak_rss_mb"] = peak_rss_mb()
    json.dump(results, open("des_results.json", "w"), indent=1)
    print("\n" + generate_ieee_table(results))
    print(generate_discussion(results))
    log("done -> des_results.json, des_table.tex, des_discussion.txt")


if __name__ == "__main__":
    main()
