"""KNORA-E / KNORA-U (DESlib) vs CA-WSV on identical data.
DES requires a DSEL set and per-sample neighbourhood search, so both the
DSEL and the evaluation subset are stratified subsamples (documented)."""
import os as _os
from pathlib import Path as _Path
ROOT = _Path(_os.environ.get("CAWSV_ROOT", _Path(__file__).resolve().parents[1]))
DATA = ROOT / "data"
DATA_NSL = DATA / "nsl-kdd"; DATA_UNSW = DATA / "unsw-nb15"; DATA_CIC = DATA / "cic-ids2018"
DATA_CIC_STAGE = DATA / "cic-ids2018-stage"; BOTIOT_CSV = DATA / "bot-iot" / "random_500k.csv"
RESULTS = ROOT / "results"; LEGACY = RESULTS / "cicids2018_legacy"; MODELS = ROOT / "models"
PAPER = ROOT / "paper_assets"; SRC = ROOT / "src"; CKPT = MODELS / "checkpoint.joblib"
LEGACY_POST = LEGACY / "posteriors.npz"; LEGACY_GAMMA = LEGACY / "gamma_sensitivity.json"
for _d in (RESULTS, LEGACY, MODELS, PAPER, PAPER / "figures", PAPER / "tables"): _d.mkdir(parents=True, exist_ok=True)
import json, time, warnings, numpy as np
warnings.filterwarnings('ignore')
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import f1_score, accuracy_score
# --- compatibility shim: sklearn >=1.6 removed BaseEstimator._validate_data,
# --- which DESlib 0.3.7 still calls. Restore an equivalent.
from sklearn.base import BaseEstimator
from sklearn.utils.validation import check_array, check_X_y
def _validate_data(self, X='no_validation', y='no_validation', reset=True,
                   validate_separately=False, **kw):
    kw.pop('multi_output',None); kw.pop('dtype',None)
    if isinstance(y,str) and y=='no_validation':
        return check_array(X)
    if y is None:
        return check_array(X)
    return check_X_y(X,y)
BaseEstimator._validate_data=_validate_data
from deslib.des import KNORAE, KNORAU
t0=time.time(); log=lambda m:print(f'[{time.time()-t0:5.0f}s] {m}',flush=True)
SD=f'{DATA_CIC_STAGE}'; C=11; RS=42
s=np.load(f'{SD}/splits.npz'); d=np.load(f'{SD}/data.npz')
X_s,y_s,X_v,y_v=s['X_tr'],s['y_tr'],s['X_val'],s['y_val']
X_t,y_t=d['X_test'],d['y_test']
rg=np.random.default_rng(RS)
def sub(X,y,cap):
    k=np.concatenate([rg.choice(np.where(y==c)[0],min(cap,(y==c).sum()),replace=False)
                      for c in range(C)])
    return X[k],y[k]
Xd,yd=sub(X_v,y_v,1500)          # DSEL for DES competence estimation
Xe,ye=sub(X_t,y_t,700)          # evaluation subset (all minority retained)
log(f'DSEL {Xd.shape}, eval {Xe.shape}')
import joblib   # reuse the cached pool (fitted on the same sub-train split)
pool=[joblib.load(f'{SD}/rf.joblib'),joblib.load(f'{SD}/dt.joblib'),
      joblib.load(f'{SD}/knn.joblib'),joblib.load(f'{SD}/lr.joblib')]
log('pool loaded from cache')
out={}
# --- CA-WSV on the same evaluation subset ---
F=[];Pe=[]
for m in pool:
    o=np.argsort(m.classes_)
    F.append(f1_score(y_v,np.argmax(m.predict_proba(X_v)[:,o],1),average=None,
                      labels=np.arange(C),zero_division=0))
    Pe.append(m.predict_proba(Xe)[:,o])
F=np.stack(F); Fg=np.power(np.maximum(F,1e-9),8); W=Fg/Fg.sum(0,keepdims=True)
pca=np.argmax(sum(W[i][None,:]*Pe[i] for i in range(4)),1)
t=time.perf_counter(); _=sum(W[i][None,:]*Pe[i] for i in range(4)); fuse_t=time.perf_counter()-t
f1c=f1_score(ye,pca,average=None,labels=np.arange(C),zero_division=0)
out['CA-WSV']={'acc':float(accuracy_score(ye,pca)),
  'macro_f1':float(f1_score(ye,pca,average='macro',zero_division=0)),
  'bfweb':float(f1c[2]),'bfxss':float(f1c[3]),'fusion_ms':fuse_t*1000}
log(f"CA-WSV      acc={out['CA-WSV']['acc']:.4f} macroF1={out['CA-WSV']['macro_f1']:.4f} "
    f"BFweb={f1c[2]:.2f} BFxss={f1c[3]:.2f}")
# --- DES baselines ---
for name,ctor in [('KNORA-U',KNORAU),('KNORA-E',KNORAE)]:
    try:
        des=ctor(pool_classifiers=pool,k=7,random_state=RS,n_jobs=-1)
        des.fit(Xd,yd)
        t=time.perf_counter(); p=des.predict(Xe); pt=time.perf_counter()-t
        f1c=f1_score(ye,p,average=None,labels=np.arange(C),zero_division=0)
        out[name]={'acc':float(accuracy_score(ye,p)),
          'macro_f1':float(f1_score(ye,p,average='macro',zero_division=0)),
          'bfweb':float(f1c[2]),'bfxss':float(f1c[3]),
          'predict_s':pt,'ms_per_sample':pt/len(ye)*1000}
        log(f"{name:11s} acc={out[name]['acc']:.4f} macroF1={out[name]['macro_f1']:.4f} "
            f"BFweb={f1c[2]:.2f} BFxss={f1c[3]:.2f}  {pt:.1f}s "
            f"({pt/len(ye)*1000:.3f} ms/sample)")
    except Exception as ex:
        log(f'{name} FAILED: {type(ex).__name__}: {str(ex)[:120]}')
out['_meta']={'dsel':int(len(yd)),'eval':int(len(ye)),'note':
  'DSEL and eval are stratified subsamples; all minority-class samples retained'}
json.dump(out,open('rev_des.json','w'),indent=1)
log('done')
