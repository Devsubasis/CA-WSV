"""CA-WSV framework diagram - phase-panel design, high-contrast text and
pale colour fills. Double-column (7.16 in) IEEE figure*."""
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
plt.rcParams.update({'font.family':'serif','font.serif':['STIXGeneral','DejaVu Serif'],
                     'mathtext.fontset':'stix','svg.fonttype':'none'})

W,H=100.0,69.0
FIG_W=7.16
fig=plt.figure(figsize=(FIG_W,FIG_W*H/W))
ax=fig.add_axes([0,0,1,1]); ax.set_xlim(0,W); ax.set_ylim(H,0)
ax.set_aspect('equal'); ax.axis('off')

CANVAS_F,CANVAS_B='#EDEFF2','#BFC6D0'
PANEL_F,PANEL_B='#FFFFFF','#CBD2DB'
TITLE,SUB='#0F172A','#1F2A3A'          # near-black / dark slate
ARROW='#3F4A5A'
# pale fills, dark borders - one family per phase
P1=('#DEEBF7','#5B87B4');  P2=('#DBEFE9','#4E8F82')
P3=('#E7E4F4','#6C64AC');  KEY=('#C7DFF5','#17497E')
P4=('#FBEADA','#B57C3C');  TERM=('#DEF0E1','#3F7B55')
HEAD={'1':'#2E5F8A','2':'#3B7A6C','3':'#17497E','4':'#9A6425'}

ax.add_patch(FancyBboxPatch((1.5,1.5),W-3,H-3,
    boxstyle='round,pad=0,rounding_size=2.2',fc=CANVAS_F,ec=CANVAS_B,lw=1.1,zorder=0))

def panel(x0,y0,x1,y1,num,label,accent=False):
    ax.add_patch(FancyBboxPatch((x0,y0),x1-x0,y1-y0,
        boxstyle='round,pad=0,rounding_size=1.6',fc=PANEL_F,
        ec=HEAD[num] if accent else PANEL_B,lw=1.3 if accent else 1.0,zorder=1))
    c=HEAD[num]
    ax.add_patch(FancyBboxPatch((x0+2.0,y0+1.8),1.1,2.9,
        boxstyle='round,pad=0,rounding_size=0.45',fc=c,ec='none',zorder=2))
    ax.text(x0+4.3,y0+3.25,f'{num}   {label}',ha='left',va='center',
            fontsize=6.5,fontweight='bold',color=c,zorder=3)

def box(cx,cy,w,h,title,subs=(),pal=P1,term=False,tfs=6.6,sfs=6.0,pitch=3.2):
    f,b=pal; r=h/2 if term else 1.5
    ax.add_patch(FancyBboxPatch((cx-w/2+0.35,cy-h/2+0.45),w,h,
        boxstyle=f'round,pad=0,rounding_size={r}',fc='#8E97A3',ec='none',
        alpha=0.18,zorder=2))
    ax.add_patch(FancyBboxPatch((cx-w/2,cy-h/2),w,h,
        boxstyle=f'round,pad=0,rounding_size={r}',fc=f,ec=b,lw=1.15,zorder=3))
    n=len(subs); top=cy-(n*pitch)/2
    ax.text(cx,top,title,ha='center',va='center',fontsize=tfs,fontweight='bold',
            color=TITLE,zorder=4)
    for i,s in enumerate(subs):
        it=s.startswith('~')
        ax.text(cx,top+(i+1)*pitch,s.lstrip('~'),ha='center',va='center',
                fontsize=sfs,color=SUB,style='italic' if it else 'normal',zorder=4)

def arrow(p,q,cs='arc3,rad=0',lw=1.25):
    ax.annotate('',xy=q,xytext=p,zorder=5,arrowprops=dict(arrowstyle='-|>',
        color=ARROW,lw=lw,shrinkA=0,shrinkB=0,connectionstyle=cs,mutation_scale=9))

def route(pts,label,lx,ly):
    ax.plot([p[0] for p in pts[:-1]],[p[1] for p in pts[:-1]],color=ARROW,
            lw=1.25,solid_capstyle='round',zorder=5)
    arrow(pts[-2],pts[-1])
    ax.text(lx,ly,label,ha='center',va='center',fontsize=5.8,style='italic',
            color=TITLE,zorder=6,bbox=dict(fc=CANVAS_F,ec='none',pad=1.2))

# ---------------- Phase 1 ----------------
panel(4,5,48,38,'1','DATA PREPARATION')
box(26,16,38,9.5,'CSE-CIC-IDS2018 Dataset',
    ['9 daily CSV files  \u00b7  8.28 M network flows'],pal=P1)
arrow((26,20.75),(26,23.0))
box(26,30,40,14,'Data Pre-Processing',
    ['Inf / NaN / negative removal',
     'Duplicate removal \u2192 5.19 M unique flows',
     'Rare-class removal (< 100)  \u00b7  Label encoding'],pal=P1)

# ---------------- Phase 2 ----------------
panel(52,5,96,38,'2','PARTITIONING & FEATURE ENGINEERING')
box(74,13,32,6.8,'Stratified Split  (70 : 30)',pal=P2)
arrow((70,16.4),(64,18.75),'arc3,rad=0.18')
arrow((78,16.4),(84,18.75),'arc3,rad=-0.18')
box(64,22.5,17,7.5,'Train Set',['70 %'],pal=P2)
box(84,22.5,17,7.5,'Test Set',['30 %'],pal=P2)
arrow((64,26.25),(66,27.6),'arc3,rad=-0.15')
box(68,32.5,28,9.8,'Min\u2013Max Scaling  &  ANOVA F  (k = 20)',
    ['~fitted on train, applied to test'],pal=P2,tfs=6.1)
arrow((48,21.5),(52,21.5))

# ---------------- Phase 3 (proposed) ----------------
panel(4,43,73,65,'3','PROPOSED CA-WSV FRAMEWORK',accent=True)
box(13.5,54.5,14.5,11.5,'Internal Split',['85 : 15','sub-train / validation'],pal=P3)
box(30,54.5,14.5,11.5,'Base-Model Training',
    ['RF \u00b7 DT \u00b7 KNN \u00b7 LR','~balanced weights'],pal=P3,tfs=6.1)
box(46.5,54.5,14.5,11.5,'Weight Matrix  W',
    ['per-class F1  (Eq. 1)','~\u03b3* = 8'],pal=KEY)
box(63,54.5,14.5,11.5,'CA-WSV Fusion',['soft voting','(Eq. 2)'],pal=KEY)
for a,b in [(20.75,22.75),(37.25,39.25),(53.75,55.75)]:
    arrow((a,54.5),(b,54.5))
route([(68,37.4),(68,39.5),(13.5,39.5),(13.5,48.4)],'training data',40,39.5)
route([(84,26.25),(84,41.5),(63,41.5),(63,48.4)],'test posteriors',74,41.5)

# ---------------- Phase 4 ----------------
panel(77,43,96,65,'4','EVALUATION')
box(86.5,52.5,17,10.5,'Evaluation',
    ['Accuracy \u00b7 Precision','Recall \u00b7 Macro-F1','Confusion Matrix'],pal=P4)
box(86.5,61.5,14,5.5,'Result',pal=TERM,term=True)
arrow((86.5,57.75),(86.5,58.75))
arrow((70.25,54.5),(78,52.5),'arc3,rad=-0.10')

for ext in ('pdf','svg'): fig.savefig(f'framework_v3.{ext}')
fig.savefig('framework_v3.png',dpi=600)
fig.savefig('framework_v3_preview.png',dpi=150)
print('saved')
