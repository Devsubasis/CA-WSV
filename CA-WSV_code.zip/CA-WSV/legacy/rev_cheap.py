import os as _os
from pathlib import Path as _Path
ROOT = _Path(_os.environ.get("CAWSV_ROOT", _Path(__file__).resolve().parents[1]))
DATA = ROOT / "data"
DATA_NSL = DATA / "nsl-kdd"; DATA_UNSW = DATA / "unsw-nb15"; DATA_CIC = DATA / "cic-ids2018"
DATA_CIC_STAGE = DATA / "cic-ids2018-stage"; BOTIOT_CSV = DATA / "bot-iot" / "random_500k.csv"
RESULTS = ROOT / "results"; LEGACY = RESULTS / "cicids2018_legacy"; MODELS = ROOT / "models"
PAPER = ROOT / "paper_assets"; SRC = ROOT / "src"; CKPT = MODELS / "checkpoint.joblib"
LEGACY_POST = LEGACY / "posteriors.npz"; LEGACY_GAMMA = LEGACY / "gamma_sensitivity.json"
for _d in (RESULTS, LEGACY, MODELS, PAPER, PAPER / "figures", PAPER / "tables"): _d.mkdir(parents=True, exist_ok=True)
import json, numpy as np
from sklearn.metrics import f1_score, accuracy_score
z=np.load(f'{LEGACY}/posteriors.npz'); F=z['F']; C=11
y=np.load(f'{LEGACY}/y_test.npy')
names=['RF','DT','KNN','LR']; P={n:z[f'test_{n}'] for n in names}
CN=['Benign','Bot','BF-Web','BF-XSS','DDoS-HOIC','DDoS-LOIC-UDP','DoS-GoldenEye',
    'DoS-Hulk','DoS-Slowloris','Infiltration','SSH-Bruteforce']
g=8; Fg=np.power(np.maximum(F,1e-9),g); W=Fg/Fg.sum(0,keepdims=True)
s=sum(W[i][None,:]*P[n] for i,n in enumerate(names))
Z=s.sum(1); shat=s/Z[:,None]; pred=np.argmax(s,1)
B=CN.index('Benign'); INF=CN.index('Infiltration')
out={}

# ---- M1: empirical range of Z (paper claims (0,1]) ----
out['Z']={'min':float(Z.min()),'max':float(Z.max()),'mean':float(Z.mean()),
          'frac_gt_1':float((Z>1+1e-12).mean()),'bound_min_M_C':min(4,C)}
print(f"M1  Z range observed: [{Z.min():.4f}, {Z.max():.4f}]  mean {Z.mean():.4f}; "
      f"fraction with Z>1: {(Z>1+1e-12).mean():.4f}  (paper claims Z<=1)")

# ---- F5: binary attack detection, prior-corrected precision ----
att=np.arange(C)!=B
yb=(y!=B).astype(int); pb=(pred!=B).astype(int)
TPR=float(pb[yb==1].mean()); FPR=float(pb[yb==0].mean())
print(f"F5  measured TPR(attack)={TPR:.4f}  FPR(=FAR)={FPR:.4f}")
rows=[]
for piB in [0.8456,0.90,0.99,0.999]:   # 0.8456 = paper's own test prior (attack-heavy)
    piA=1-piB
    prec=piA*TPR/(piA*TPR+piB*FPR)
    alerts=piB*1e6*FPR
    rows.append((piB,prec,alerts))
    print(f"    benign prior {piB:.4f}: attack precision {prec:.4f}, "
          f"false alerts/day @1e6 flows = {alerts:,.0f}")
out['prior_corrected']=[{'benign_prior':a,'precision':b,'false_alerts_per_1e6':c} for a,b,c in rows]
need=[]
for target in [0.9,0.95]:
    piB=0.999; piA=1-piB
    far_req=piA*TPR*(1-target)/(target*piB)
    need.append((target,far_req)); print(f"    FAR needed for precision {target} at 99.9% benign: {far_req:.5f}")
out['far_required']=[{'target_precision':a,'required_FAR':b} for a,b in need]

# ---- M8: Infiltration excluded ----
keep=y!=INF
yk=y[keep]; pk=pred[keep]
lab=[c for c in range(C) if c!=INF]
mapping={c:i for i,c in enumerate(lab)}
valid=np.isin(pk,lab)
acc_ex=accuracy_score(yk,pk)
mf_ex=f1_score(yk,pk,average='macro',labels=lab,zero_division=0)
far_ex=float((pk[yk==B]!=B).mean())
miss_ex=float((pk[(yk!=B)]==B).mean())
print(f"M8  Infiltration EXCLUDED: acc={acc_ex:.4f} macroF1={mf_ex:.4f} "
      f"FAR={far_ex:.4f} miss={miss_ex:.4f}  (N={keep.sum():,})")
out['no_infiltration']={'acc':float(acc_ex),'macro_f1':float(mf_ex),'FAR':far_ex,
                        'miss':miss_ex,'N':int(keep.sum())}

# ---- minor: ECE bin populations ----
conf=shat.max(1); corr=(pred==y).astype(float)
bins=np.linspace(0,1,16); binrep=[]
for i in range(15):
    m=(conf>bins[i])&(conf<=bins[i+1])
    if m.sum():
        binrep.append({'bin':f'({bins[i]:.2f},{bins[i+1]:.2f}]','n':int(m.sum()),
                       'conf':float(conf[m].mean()),'acc':float(corr[m].mean()),
                       'gap':float(abs(conf[m].mean()-corr[m].mean()))})
worst=max(binrep,key=lambda r:r['gap'])
print(f"minor ECE bins: {len(binrep)} populated; worst-gap bin {worst['bin']} "
      f"n={worst['n']} ({100*worst['n']/len(y):.3f}% of test) gap={worst['gap']:.4f}")
out['calibration_bins']=binrep

# ---- minor/F5: margin-based reject option (uses Eqs. 6-7) ----
marg=np.sort(shat,1)[:,-1]-np.sort(shat,1)[:,-2]
rej=[]
for t in [0.0,0.2,0.4,0.6,0.8,0.9]:
    a=marg>=t
    if a.sum()<100: continue
    cov=float(a.mean())
    far=float((pred[a&(y==B)]!=B).mean()) if (a&(y==B)).sum() else float('nan')
    miss=float((pred[a&(y!=B)]==B).mean()) if (a&(y!=B)).sum() else float('nan')
    mf=f1_score(y[a],pred[a],average='macro',labels=np.arange(C),zero_division=0)
    rej.append({'margin_thr':t,'coverage':cov,'FAR':far,'miss':miss,'macro_f1':float(mf)})
    print(f"    reject t={t:.1f}: coverage {cov:.4f}  FAR {far:.4f}  miss {miss:.4f}  macroF1 {mf:.4f}")
out['reject_option']=rej
json.dump(out,open('rev_cheap.json','w'),indent=1)
