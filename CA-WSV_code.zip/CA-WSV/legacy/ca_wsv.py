"""Class-Adaptive Weighted Soft Voting (CA-WSV).
Novel ensemble: per-class, per-model weights learned from validation F1,
instead of one scalar weight per model. Runs on the exact checkpointed
train/test split used for the paper's reported results."""
import os as _os
from pathlib import Path as _Path
ROOT = _Path(_os.environ.get("CAWSV_ROOT", _Path(__file__).resolve().parents[1]))
DATA = ROOT / "data"
DATA_NSL = DATA / "nsl-kdd"; DATA_UNSW = DATA / "unsw-nb15"; DATA_CIC = DATA / "cic-ids2018"
DATA_CIC_STAGE = DATA / "cic-ids2018-stage"; BOTIOT_CSV = DATA / "bot-iot" / "random_500k.csv"
RESULTS = ROOT / "results"; LEGACY = RESULTS / "cicids2018_legacy"; MODELS = ROOT / "models"
PAPER = ROOT / "paper_assets"; SRC = ROOT / "src"; CKPT = MODELS / "checkpoint.joblib"
LEGACY_POST = LEGACY / "posteriors.npz"; LEGACY_GAMMA = LEGACY / "gamma_sensitivity.json"
for _d in (RESULTS, LEGACY, MODELS, PAPER, PAPER / "figures", PAPER / "tables"): _d.mkdir(parents=True, exist_ok=True)
import json, time, sys
import numpy as np, joblib
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, f1_score, classification_report,
                             precision_recall_fscore_support)

t0 = time.time()
def log(m): print(f'[{time.time()-t0:6.0f}s] {m}', flush=True)

ck = joblib.load(f'{CKPT}')
X_train, y_train = ck['X_train'], ck['y_train']
X_test, y_test = ck['X_test'], ck['y_test']
class_names = ck['class_names']; C = len(class_names)
RS = 42
log(f'loaded: train {X_train.shape}, test {X_test.shape}, {C} classes')

# validation split carved from TRAINING data only (no test leakage)
X_tr, X_val, y_tr, y_val = train_test_split(
    X_train, y_train, test_size=0.15, random_state=RS, stratify=y_train)
log(f'sub-train {X_tr.shape}, val {X_val.shape}')

MODELS = {
    'RF':  RandomForestClassifier(class_weight='balanced', n_jobs=-1,
                                  random_state=RS),
    'DT':  DecisionTreeClassifier(class_weight='balanced', random_state=RS),
    'KNN': KNeighborsClassifier(n_jobs=-1),
    'LR':  LogisticRegression(class_weight='balanced', max_iter=2000),
}
P_val, P_test, F1_val = {}, {}, {}
for name, m in MODELS.items():
    log(f'{name}: fit'); m.fit(X_tr, y_tr)
    log(f'{name}: predict val'); pv = m.predict_proba(X_val)
    log(f'{name}: predict test'); pt = m.predict_proba(X_test)
    order = np.argsort(m.classes_)          # defensive class alignment
    P_val[name], P_test[name] = pv[:, order], pt[:, order]
    F1_val[name] = f1_score(y_val, np.argmax(P_val[name], 1),
                            average=None, labels=np.arange(C))
    log(f'{name}: val macro-F1 = {f1_score(y_val, np.argmax(P_val[name],1), average="macro"):.4f}')

names = list(MODELS)
F = np.stack([F1_val[n] for n in names])            # (M, C)

def cawsv_pred(P, W):
    S = sum(W[i][None, :] * P[n] for i, n in enumerate(names))
    return np.argmax(S, 1)

# gamma selected on validation only
best = (-1, None, None)
for gamma in [0.5, 1, 2, 3, 4, 6, 8]:
    Fg = np.power(np.maximum(F, 1e-9), gamma)
    W = Fg / Fg.sum(0, keepdims=True)
    mf1 = f1_score(y_val, cawsv_pred(P_val, W), average='macro')
    log(f'gamma={gamma}: val macro-F1 = {mf1:.4f}')
    if mf1 > best[0]: best = (mf1, gamma, W)
_, gamma, W = best
log(f'selected gamma = {gamma}')

# ---- final evaluation on test ----
def report(tag, y_pred):
    acc = accuracy_score(y_test, y_pred)
    mf = f1_score(y_test, y_pred, average='macro')
    wf = f1_score(y_test, y_pred, average='weighted')
    log(f'== {tag}: acc={acc:.4f} macroF1={mf:.4f} weightedF1={wf:.4f}')
    return dict(acc=acc, macro_f1=mf, weighted_f1=wf)

res = {}
res['CA-WSV'] = report('CA-WSV (class-adaptive)', cawsv_pred(P_test, W))
Wu = np.full_like(W, 1 / len(names))                 # ablation: uniform
res['UniformSoft'] = report('Uniform soft voting (ablation)',
                            cawsv_pred(P_test, Wu))
Fg1 = np.power(np.maximum(F.mean(1, keepdims=True), 1e-9), gamma)  # scalar/model
Ws = np.repeat(Fg1 / Fg1.sum(0, keepdims=True), C, 1)
res['ScalarWeighted'] = report('Scalar-weighted soft voting (ablation)',
                               cawsv_pred(P_test, Ws))
for i, n in enumerate(names):
    res[n] = report(f'base {n}', np.argmax(P_test[n], 1))

y_pred = cawsv_pred(P_test, W)
p, r, f1c, sup = precision_recall_fscore_support(y_test, y_pred,
                                                 labels=np.arange(C))
out = {'gamma': gamma, 'models': names, 'class_names': class_names,
       'W': W.tolist(), 'F1_val': F.tolist(), 'summary': res,
       'per_class': {class_names[c]: [round(p[c],4), round(r[c],4),
                     round(f1c[c],4), int(sup[c])] for c in range(C)}}
json.dump(out, open('cawsv_results.json', 'w'), indent=1)
print(classification_report(y_test, y_pred, target_names=class_names,
                            zero_division=0, digits=2))
log('DONE')
