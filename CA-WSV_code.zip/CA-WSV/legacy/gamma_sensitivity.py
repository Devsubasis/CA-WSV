"""Extended CA-WSV analysis: gamma sensitivity on validation AND test,
including the winner-take-all limit (gamma -> inf). Saves base posteriors."""
import os as _os
from pathlib import Path as _Path
ROOT = _Path(_os.environ.get("CAWSV_ROOT", _Path(__file__).resolve().parents[1]))
DATA = ROOT / "data"
DATA_NSL = DATA / "nsl-kdd"; DATA_UNSW = DATA / "unsw-nb15"; DATA_CIC = DATA / "cic-ids2018"
DATA_CIC_STAGE = DATA / "cic-ids2018-stage"; BOTIOT_CSV = DATA / "bot-iot" / "random_500k.csv"
RESULTS = ROOT / "results"; LEGACY = RESULTS / "cicids2018_legacy"; MODELS = ROOT / "models"
PAPER = ROOT / "paper_assets"; SRC = ROOT / "src"; CKPT = MODELS / "checkpoint.joblib"
LEGACY_POST = LEGACY / "posteriors.npz"; LEGACY_GAMMA = LEGACY / "gamma_sensitivity.json"
for _d in (RESULTS, LEGACY, MODELS, PAPER, PAPER / "figures", PAPER / "tables"): _d.mkdir(parents=True, exist_ok=True)
import json, time
import numpy as np, joblib
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score

t0 = time.time()
def log(m): print(f'[{time.time()-t0:6.0f}s] {m}', flush=True)

ck = joblib.load(f'{CKPT}')
X_train, y_train = ck['X_train'], ck['y_train']
X_test, y_test = ck['X_test'], ck['y_test']
C = len(ck['class_names']); RS = 42
X_tr, X_val, y_tr, y_val = train_test_split(
    X_train, y_train, test_size=0.15, random_state=RS, stratify=y_train)

MODELS = {'RF': RandomForestClassifier(class_weight='balanced', n_jobs=-1, random_state=RS),
          'DT': DecisionTreeClassifier(class_weight='balanced', random_state=RS),
          'KNN': KNeighborsClassifier(n_jobs=-1),
          'LR': LogisticRegression(class_weight='balanced', max_iter=2000)}
P_val, P_test = {}, {}
F = []
for name, m in MODELS.items():
    log(f'{name} fit'); m.fit(X_tr, y_tr)
    log(f'{name} val proba');  P_val[name] = m.predict_proba(X_val)[:, np.argsort(m.classes_)]
    log(f'{name} test proba'); P_test[name] = m.predict_proba(X_test)[:, np.argsort(m.classes_)]
    F.append(f1_score(y_val, np.argmax(P_val[name], 1), average=None, labels=np.arange(C)))
F = np.stack(F); names = list(MODELS)
np.savez_compressed(f'{LEGACY_POST}', F=F,
                    **{f'val_{n}': P_val[n].astype(np.float32) for n in names},
                    **{f'test_{n}': P_test[n].astype(np.float32) for n in names})

def fuse(P, W):
    return np.argmax(sum(W[i][None, :] * P[n] for i, n in enumerate(names)), 1)

rows = []
for gamma in [0.25, 0.5, 1, 2, 3, 4, 6, 8, 12, 16]:
    Fg = np.power(np.maximum(F, 1e-9), gamma)
    W = Fg / Fg.sum(0, keepdims=True)
    row = dict(gamma=gamma,
               val_macro=f1_score(y_val, fuse(P_val, W), average='macro'),
               test_macro=f1_score(y_test, fuse(P_test, W), average='macro'),
               test_acc=accuracy_score(y_test, fuse(P_test, W)))
    rows.append(row); log(str({k: round(v,4) if k!='gamma' else v for k,v in row.items()}))
# winner-take-all limit (gamma -> infinity): per-class argmax routing
Wwta = np.zeros_like(F); Wwta[np.argmax(F, 0), np.arange(C)] = 1.0
row = dict(gamma='inf',
           val_macro=f1_score(y_val, fuse(P_val, Wwta), average='macro'),
           test_macro=f1_score(y_test, fuse(P_test, Wwta), average='macro'),
           test_acc=accuracy_score(y_test, fuse(P_test, Wwta)))
rows.append(row); log(str({k: round(v,4) if k!='gamma' else v for k,v in row.items()}))
json.dump(rows, open(f'{LEGACY_GAMMA}', 'w'), indent=1)
log('DONE')
