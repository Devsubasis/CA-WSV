import os as _os
from pathlib import Path as _Path
ROOT = _Path(_os.environ.get("CAWSV_ROOT", _Path(__file__).resolve().parents[1]))
DATA = ROOT / "data"
DATA_NSL = DATA / "nsl-kdd"; DATA_UNSW = DATA / "unsw-nb15"; DATA_CIC = DATA / "cic-ids2018"
DATA_CIC_STAGE = DATA / "cic-ids2018-stage"; BOTIOT_CSV = DATA / "bot-iot" / "random_500k.csv"
RESULTS = ROOT / "results"; LEGACY = RESULTS / "cicids2018_legacy"; MODELS = ROOT / "models"
PAPER = ROOT / "paper_assets"; SRC = ROOT / "src"; CKPT = MODELS / "checkpoint.joblib"
LEGACY_POST = LEGACY / "posteriors.npz"; LEGACY_GAMMA = LEGACY / "gamma_sensitivity.json"
for _d in (RESULTS, LEGACY, MODELS, PAPER, PAPER / "figures", PAPER / "tables"): _d.mkdir(parents=True, exist_ok=True)
import json
import numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from sklearn.metrics import (confusion_matrix, roc_curve, auc,
                             precision_recall_curve, average_precision_score,
                             f1_score)
plt.rcParams.update({'font.family':'serif','font.serif':['STIXGeneral','DejaVu Serif'],
                     'mathtext.fontset':'stix','svg.fonttype':'none'})
INK,AXIS='#1F2937','#94A3B8'
z=np.load(f'{LEGACY}/posteriors.npz'); F=z['F']; C=11
y=np.load(f'{LEGACY}/y_test.npy')
names=['RF','DT','KNN','LR']; P={n:z[f'test_{n}'] for n in names}
g=8; Fg=np.power(np.maximum(F,1e-9),g); W=Fg/Fg.sum(0,keepdims=True)
s=sum(W[i][None,:]*P[n] for i,n in enumerate(names))
shat=s/s.sum(1,keepdims=True); pred=np.argmax(s,1)
CN=['Benign','Bot','BF-Web','BF-XSS','DDoS-HOIC','DDoS-LOIC-UDP','DoS-GoldenEye',
    'DoS-Hulk','DoS-Slowloris','Infiltration','SSH-Bruteforce']
Y=np.eye(C)[y]

# ---------- 1. confusion matrix heatmap (row-normalised, counts annotated) ----
cm=confusion_matrix(y,pred,labels=np.arange(C))
cmn=cm/cm.sum(1,keepdims=True)
fig,ax=plt.subplots(figsize=(3.5,3.1))
im=ax.imshow(cmn,cmap='Blues',vmin=0,vmax=1)
for i in range(C):
    for j in range(C):
        v=cm[i,j]
        if v:
            txt=f'{v/1000:.0f}K' if v>=10000 else (f'{v:,}' if v<1000 else f'{v/1000:.1f}K')
            ax.text(j,i,txt,ha='center',va='center',fontsize=3.9,
                    color='white' if cmn[i,j]>0.55 else INK)
ax.set_xticks(range(C)); ax.set_xticklabels(CN,rotation=45,ha='right',fontsize=5.3)
ax.set_yticks(range(C)); ax.set_yticklabels(CN,fontsize=5.3)
ax.set_xlabel('Predicted',fontsize=7.5,color=INK)
ax.set_ylabel('True',fontsize=7.5,color=INK)
cb=fig.colorbar(im,ax=ax,fraction=0.042,pad=0.03)
cb.ax.tick_params(labelsize=5.5,colors=INK); cb.set_label('row-normalised',fontsize=6,color=INK)
ax.tick_params(colors=INK,length=0)
fig.tight_layout(pad=0.4)
for e in ('pdf','png'): fig.savefig(f'cm_cawsv.{e}',dpi=600)
plt.close(fig)

# ---------- 2. ROC (per-class OvR + macro + micro) ----------
fpr,tpr,rocauc={},{},{}
for c in range(C):
    fpr[c],tpr[c],_=roc_curve(Y[:,c],shat[:,c]); rocauc[c]=auc(fpr[c],tpr[c])
grid=np.unique(np.concatenate([fpr[c] for c in range(C)]))
mean_tpr=np.mean([np.interp(grid,fpr[c],tpr[c]) for c in range(C)],axis=0)
macro_auc=auc(grid,mean_tpr)
fmi,tmi,_=roc_curve(Y.ravel(),shat.ravel()); micro_auc=auc(fmi,tmi)
fig,ax=plt.subplots(figsize=(3.5,2.6))
for c in range(C):
    ax.plot(fpr[c],tpr[c],lw=0.7,alpha=0.5,color=plt.cm.tab20(c/20))
ax.plot(grid,mean_tpr,color='#1E4F91',lw=1.8,zorder=4,
        label=f'Macro-average (AUC = {macro_auc:.4f})')
ax.plot(fmi,tmi,color='#D97706',lw=1.3,ls='--',zorder=4,
        label=f'Micro-average (AUC = {micro_auc:.4f})')
ax.plot([0,1],[0,1],color='#94A3B8',lw=0.8,ls=':',zorder=1)
ax.set_xscale('log'); ax.set_xlim(1e-5,1); ax.set_ylim(0,1.02)
ax.set_xlabel('False positive rate (log scale)',fontsize=8,color=INK)
ax.set_ylabel('True positive rate',fontsize=8,color=INK)
ax.grid(ls=':',lw=0.6,color='#CBD5E1',zorder=0)
for sp in ('top','right'): ax.spines[sp].set_visible(False)
for sp in ('left','bottom'): ax.spines[sp].set_color(AXIS)
ax.tick_params(labelsize=6.3,colors=INK,length=2)
ax.legend(frameon=False,fontsize=6.2,loc='lower right')
fig.tight_layout(pad=0.4)
for e in ('pdf','png'): fig.savefig(f'roc_cawsv.{e}',dpi=600)
plt.close(fig)

# ---------- 3. Precision-Recall ----------
ap={}; prc={}
for c in range(C):
    pr,rc,_=precision_recall_curve(Y[:,c],shat[:,c]); prc[c]=(rc,pr)
    ap[c]=average_precision_score(Y[:,c],shat[:,c])
macro_ap=np.mean(list(ap.values()))
micro_ap=average_precision_score(Y.ravel(),shat.ravel())
fig,ax=plt.subplots(figsize=(3.5,2.6))
for c in range(C):
    ax.plot(prc[c][0],prc[c][1],lw=0.8,alpha=0.55,color=plt.cm.tab20(c/20),
            label=f'{CN[c]} ({ap[c]:.2f})')
ax.axhline(np.mean(Y.mean(0)),color='#94A3B8',lw=0.8,ls=':',zorder=1)
ax.set_xlabel('Recall',fontsize=8,color=INK); ax.set_ylabel('Precision',fontsize=8,color=INK)
ax.set_xlim(0,1.02); ax.set_ylim(0,1.05)
ax.set_title(f'Macro-average AP = {macro_ap:.4f}   Micro-average AP = {micro_ap:.4f}',
             fontsize=6.6,color=INK,pad=4)
ax.grid(ls=':',lw=0.6,color='#CBD5E1',zorder=0)
for sp in ('top','right'): ax.spines[sp].set_visible(False)
for sp in ('left','bottom'): ax.spines[sp].set_color(AXIS)
ax.tick_params(labelsize=6.3,colors=INK,length=2)
ax.legend(frameon=False,fontsize=4.6,loc='lower left',ncol=2,handlelength=1.0,
          columnspacing=0.8,labelspacing=0.25)
fig.tight_layout(pad=0.4)
for e in ('pdf','png'): fig.savefig(f'pr_cawsv.{e}',dpi=600)
plt.close(fig)

# ---------- 4. class-wise F1: CA-WSV vs RF vs KNN ----------
f_ca=f1_score(y,pred,average=None,labels=np.arange(C))
f_rf=f1_score(y,np.argmax(P['RF'],1),average=None,labels=np.arange(C))
f_knn=f1_score(y,np.argmax(P['KNN'],1),average=None,labels=np.arange(C))
x=np.arange(C); w=0.27
fig,ax=plt.subplots(figsize=(3.5,2.5))
for k,(v,c,ec,l) in enumerate([(f_rf,'#9FB6D9','#5B7CA8','Random Forest'),
                               (f_knn,'#0F766E','#0B5C50','KNN'),
                               (f_ca,'#1E4F91','#123763','CA-WSV (proposed)')]):
    b=ax.bar(x+(k-1)*(w+0.012),v,w,color=c,edgecolor=ec,lw=0.5,zorder=3,label=l)
    for r,val in zip(b,v):
        ax.text(r.get_x()+r.get_width()/2,val+0.018,f'{val:.2f}',ha='center',
                va='bottom',fontsize=4.4,rotation=90,color=INK)
ax.set_ylim(0,1.16); ax.set_ylabel('F1-score',fontsize=8,color=INK)
ax.set_xticks(x); ax.set_xticklabels(CN,rotation=40,ha='right',fontsize=6.0)
ax.grid(axis='y',ls=':',lw=0.6,color='#CBD5E1',zorder=0)
for sp in ('top','right'): ax.spines[sp].set_visible(False)
for sp in ('left','bottom'): ax.spines[sp].set_color(AXIS)
ax.tick_params(labelsize=6.0,colors=INK,length=2)
ax.legend(frameon=False,fontsize=6.2,ncol=3,loc='lower center',bbox_to_anchor=(0.5,0.995))
fig.tight_layout(pad=0.4)
for e in ('pdf','png'): fig.savefig(f'classwise_f1_compare.{e}',dpi=600)
plt.close(fig)

json.dump({'macro_auc':float(macro_auc),'micro_auc':float(micro_auc),
 'per_class_auc':{CN[c]:float(rocauc[c]) for c in range(C)},
 'macro_ap':float(macro_ap),'micro_ap':float(micro_ap),
 'per_class_ap':{CN[c]:float(ap[c]) for c in range(C)},
 'f1':{'CA-WSV':{CN[c]:round(float(f_ca[c]),4) for c in range(C)},
       'RF':{CN[c]:round(float(f_rf[c]),4) for c in range(C)},
       'KNN':{CN[c]:round(float(f_knn[c]),4) for c in range(C)}},
 'confusion_matrix':cm.tolist(),'class_names':CN},
 open('diag_results.json','w'),indent=1)
print('macro AUC',round(macro_auc,4),'micro AUC',round(micro_auc,4))
print('macro AP',round(macro_ap,4),'micro AP',round(micro_ap,4))
print('per-class AUC:',{CN[c]:round(rocauc[c],4) for c in range(C)})
print('per-class AP:',{CN[c]:round(ap[c],3) for c in range(C)})
from PIL import Image
for f in ['cm_cawsv.png','roc_cawsv.png','pr_cawsv.png','classwise_f1_compare.png']:
    gI=np.asarray(Image.open(f).convert('L'))
    print(f,[(gI[:,:3]<200).sum(),(gI[:,-3:]<200).sum(),(gI[:3,:]<200).sum(),(gI[-3:,:]<200).sum()])
