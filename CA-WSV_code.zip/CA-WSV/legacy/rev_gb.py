import os as _os
from pathlib import Path as _Path
ROOT = _Path(_os.environ.get("CAWSV_ROOT", _Path(__file__).resolve().parents[1]))
DATA = ROOT / "data"
DATA_NSL = DATA / "nsl-kdd"; DATA_UNSW = DATA / "unsw-nb15"; DATA_CIC = DATA / "cic-ids2018"
DATA_CIC_STAGE = DATA / "cic-ids2018-stage"; BOTIOT_CSV = DATA / "bot-iot" / "random_500k.csv"
RESULTS = ROOT / "results"; LEGACY = RESULTS / "cicids2018_legacy"; MODELS = ROOT / "models"
PAPER = ROOT / "paper_assets"; SRC = ROOT / "src"; CKPT = MODELS / "checkpoint.joblib"
LEGACY_POST = LEGACY / "posteriors.npz"; LEGACY_GAMMA = LEGACY / "gamma_sensitivity.json"
for _d in (RESULTS, LEGACY, MODELS, PAPER, PAPER / "figures", PAPER / "tables"): _d.mkdir(parents=True, exist_ok=True)
import json, time, numpy as np
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.metrics import f1_score, accuracy_score
t0=time.time(); log=lambda m:print(f'[{time.time()-t0:5.0f}s] {m}',flush=True)
SD=f'{DATA_CIC_STAGE}'; C=11
s=np.load(f'{SD}/splits.npz'); d=np.load(f'{SD}/data.npz')
X_tr,y_tr,X_val,y_val=s['X_tr'],s['y_tr'],s['X_val'],s['y_val']
X_te,y_te=d['X_test'],d['y_test']
CN=['Benign','Bot','BF-Web','BF-XSS','DDoS-HOIC','DDoS-LOIC-UDP','DoS-GoldenEye',
    'DoS-Hulk','DoS-Slowloris','Infiltration','SSH-Bruteforce']
B=CN.index('Benign'); INF=CN.index('Infiltration'); out={}
z=np.load(f'{LEGACY}/posteriors.npz'); F=z['F']
names=['RF','DT','KNN','LR']; P={n:z[f'test_{n}'] for n in names}
g=8; Fg=np.power(np.maximum(F,1e-9),g); W=Fg/Fg.sum(0,keepdims=True)
sc=sum(W[i][None,:]*P[n] for i,n in enumerate(names))

# ---- M8 proper: 10-class evaluation (Infiltration removed from label space AND test) ----
lab=[c for c in range(C) if c!=INF]
sc10=sc.copy(); sc10[:,INF]=-np.inf
keep=y_te!=INF
p10=np.argmax(sc10,1)[keep]; y10=y_te[keep]
print(f"M8  10-class (Infiltration removed from labels+test, N={keep.sum():,}): "
      f"acc={accuracy_score(y10,p10):.4f} macroF1={f1_score(y10,p10,average='macro',labels=lab):.4f} "
      f"FAR={(p10[y10==B]!=B).mean():.4f} miss={(p10[y10!=B]==B).mean():.4f}")
out['ten_class']={'N':int(keep.sum()),'acc':float(accuracy_score(y10,p10)),
    'macro_f1':float(f1_score(y10,p10,average='macro',labels=lab)),
    'FAR':float((p10[y10==B]!=B).mean()),'miss':float((p10[y10!=B]==B).mean())}

# ---- M6: gradient boosting baseline ----
log('fitting HistGradientBoosting (LightGBM-equivalent)')
hgb=HistGradientBoostingClassifier(class_weight='balanced',max_iter=100,
    early_stopping=True,validation_fraction=0.1,random_state=42)
t=time.time(); hgb.fit(X_tr,y_tr); tr_t=time.time()-t
log(f'fit done in {tr_t:.1f}s, iters={hgb.n_iter_}')
o=np.argsort(hgb.classes_)
Pv=hgb.predict_proba(X_val)[:,o]
t=time.time(); Pt=hgb.predict_proba(X_te)[:,o]; te_t=time.time()-t
np.savez_compressed(f'{SD}/hgb.npz',val=Pv.astype(np.float32),test=Pt.astype(np.float32))
ph=np.argmax(Pt,1); f1c=f1_score(y_te,ph,average=None,labels=np.arange(C),zero_division=0)
print(f"M6  HistGB standalone: acc={accuracy_score(y_te,ph):.4f} "
      f"macroF1={f1_score(y_te,ph,average='macro'):.4f} "
      f"wtdF1={f1_score(y_te,ph,average='weighted'):.4f} "
      f"BF-Web={f1c[2]:.2f} BF-XSS={f1c[3]:.2f} FAR={(ph[y_te==B]!=B).mean():.4f}")
print(f"    train {tr_t:.1f}s, test {te_t:.2f}s ({te_t/len(y_te)*1000:.4f} ms/sample)")
out['HistGB']={'acc':float(accuracy_score(y_te,ph)),'macro_f1':float(f1_score(y_te,ph,average='macro')),
  'weighted_f1':float(f1_score(y_te,ph,average='weighted')),
  'per_class_f1':{CN[c]:round(float(f1c[c]),4) for c in range(C)},
  'FAR':float((ph[y_te==B]!=B).mean()),'train_s':tr_t,'test_s':te_t,
  'ms_per_sample':te_t/len(y_te)*1000}

# ---- CA-WSV with HistGB added as 5th member ----
Fh=f1_score(y_val,np.argmax(Pv,1),average=None,labels=np.arange(C))
F5=np.vstack([F,Fh]); P5=[P[n] for n in names]+[Pt]
Fg5=np.power(np.maximum(F5,1e-9),g); W5=Fg5/Fg5.sum(0,keepdims=True)
p5=np.argmax(sum(W5[i][None,:]*P5[i] for i in range(5)),1)
f1c5=f1_score(y_te,p5,average=None,labels=np.arange(C),zero_division=0)
print(f"    CA-WSV+HistGB (5 members): acc={accuracy_score(y_te,p5):.4f} "
      f"macroF1={f1_score(y_te,p5,average='macro'):.4f} BF-Web={f1c5[2]:.2f} BF-XSS={f1c5[3]:.2f}")
out['CA-WSV+HistGB']={'acc':float(accuracy_score(y_te,p5)),
  'macro_f1':float(f1_score(y_te,p5,average='macro')),
  'weighted_f1':float(f1_score(y_te,p5,average='weighted')),
  'per_class_f1':{CN[c]:round(float(f1c5[c]),4) for c in range(C)},
  'mean_weight_HistGB':float(W5[4].mean())}
print('    mean CA-WSV weight given to HistGB:',round(float(W5[4].mean()),3))
json.dump(out,open('rev_gb.json','w'),indent=1)
log('done')
