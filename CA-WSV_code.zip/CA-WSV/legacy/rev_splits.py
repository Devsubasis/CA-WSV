"""Repeated stratified splits with full per-split refitting of scaler,
feature selector, base models and gamma. Reduced per-class cap for
tractability; documented as a variance study."""
import os as _os
from pathlib import Path as _Path
ROOT = _Path(_os.environ.get("CAWSV_ROOT", _Path(__file__).resolve().parents[1]))
DATA = ROOT / "data"
DATA_NSL = DATA / "nsl-kdd"; DATA_UNSW = DATA / "unsw-nb15"; DATA_CIC = DATA / "cic-ids2018"
DATA_CIC_STAGE = DATA / "cic-ids2018-stage"; BOTIOT_CSV = DATA / "bot-iot" / "random_500k.csv"
RESULTS = ROOT / "results"; LEGACY = RESULTS / "cicids2018_legacy"; MODELS = ROOT / "models"
PAPER = ROOT / "paper_assets"; SRC = ROOT / "src"; CKPT = MODELS / "checkpoint.joblib"
LEGACY_POST = LEGACY / "posteriors.npz"; LEGACY_GAMMA = LEGACY / "gamma_sensitivity.json"
for _d in (RESULTS, LEGACY, MODELS, PAPER, PAPER / "figures", PAPER / "tables"): _d.mkdir(parents=True, exist_ok=True)
import json, sys, time
import numpy as np, pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler
from sklearn.feature_selection import SelectKBest, f_classif
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import f1_score, accuracy_score
t0=time.time(); log=lambda m:print(f'[{time.time()-t0:5.0f}s] {m}',flush=True)
SD=f'{DATA_CIC_STAGE}'; CAP=25000; K=20
RARE=['FTP-BruteForce','DoS attacks-SlowHTTPTest','SQL Injection']
df=pd.read_pickle(f'{SD}/df.pkl')
df=df[~df['Label'].isin(RARE)]
df=pd.concat([g.sample(min(len(g),CAP),random_state=0) for _,g in df.groupby('Label')],
             ignore_index=True)
lab=sorted(df['Label'].unique()); C=len(lab); m2i={l:i for i,l in enumerate(lab)}
Y=df['Label'].map(m2i).to_numpy()
feat=[c for c in df.columns if c!='Label']
X=df[feat].to_numpy(dtype=np.float32)
BF=lab.index('Brute Force -Web'); BEN=lab.index('Benign')
log(f'pool {X.shape}, {C} classes, cap={CAP}')

def run(seed):
    Xtr,Xte,ytr,yte=train_test_split(X,Y,test_size=0.3,random_state=seed,stratify=Y)
    sc=MinMaxScaler().fit(Xtr)                      # fitted on TRAIN only
    sel=SelectKBest(f_classif,k=K).fit(sc.transform(Xtr),ytr)   # TRAIN only
    Xtr=sel.transform(sc.transform(Xtr)); Xte=sel.transform(sc.transform(Xte))
    Xs,Xv,ys,yv=train_test_split(Xtr,ytr,test_size=0.15,random_state=seed,stratify=ytr)
    Ms=[('RF',RandomForestClassifier(class_weight='balanced',n_jobs=-1,random_state=seed)),
        ('DT',DecisionTreeClassifier(class_weight='balanced',random_state=seed)),
        ('KNN',KNeighborsClassifier(n_jobs=-1)),
        ('LR',LogisticRegression(class_weight='balanced',max_iter=2000))]
    Pv,Pt,F=[],[],[]
    for nm,mo in Ms:
        mo.fit(Xs,ys); o=np.argsort(mo.classes_)
        pv=mo.predict_proba(Xv)[:,o]; Pv.append(pv); Pt.append(mo.predict_proba(Xte)[:,o])
        F.append(f1_score(yv,np.argmax(pv,1),average=None,labels=np.arange(C),zero_division=0))
    F=np.stack(F)
    def fuse(Wm,Pl): return np.argmax(sum(Wm[i][None,:]*Pl[i] for i in range(len(Pl))),1)
    best=(-1,None)
    for g in [0.5,1,2,3,4,6,8]:
        Fg=np.power(np.maximum(F,1e-9),g); Wg=Fg/Fg.sum(0,keepdims=True)
        v=f1_score(yv,fuse(Wg,Pv),average='macro',zero_division=0)
        if v>best[0]: best=(v,g)
    g=best[1]
    Fg=np.power(np.maximum(F,1e-9),g); Wca=Fg/Fg.sum(0,keepdims=True)
    Wu=np.full_like(Wca,1/4)
    Fs=(F.mean(1,keepdims=True))**g; Ws=np.repeat(Fs/Fs.sum(0,keepdims=True),C,1)
    res={'seed':seed,'gamma':g}
    for tag,pr in [('CA-WSV',fuse(Wca,Pt)),('Scalar',fuse(Ws,Pt)),('Uniform',fuse(Wu,Pt)),
                   ('KNN',np.argmax(Pt[2],1)),('RF',np.argmax(Pt[0],1))]:
        f1c=f1_score(yte,pr,average=None,labels=np.arange(C),zero_division=0)
        res[tag]={'acc':float(accuracy_score(yte,pr)),
                  'macro_f1':float(f1_score(yte,pr,average='macro',zero_division=0)),
                  'bfweb_f1':float(f1c[BF]),
                  'FAR':float((pr[yte==BEN]!=BEN).mean())}
    return res

for seed in [int(x) for x in sys.argv[1].split(',')]:
    r=run(seed)
    open(f'{SD}/splits_rep.jsonl','a').write(json.dumps(r)+'\n')
    log(f"seed {seed}: g={r['gamma']} CA-WSV={r['CA-WSV']['macro_f1']:.4f} "
        f"KNN={r['KNN']['macro_f1']:.4f} Scalar={r['Scalar']['macro_f1']:.4f} "
        f"BFweb={r['CA-WSV']['bfweb_f1']:.3f}")
