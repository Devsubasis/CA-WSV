import os as _os
from pathlib import Path as _Path
ROOT = _Path(_os.environ.get("CAWSV_ROOT", _Path(__file__).resolve().parents[1]))
DATA = ROOT / "data"
DATA_NSL = DATA / "nsl-kdd"; DATA_UNSW = DATA / "unsw-nb15"; DATA_CIC = DATA / "cic-ids2018"
DATA_CIC_STAGE = DATA / "cic-ids2018-stage"; BOTIOT_CSV = DATA / "bot-iot" / "random_500k.csv"
RESULTS = ROOT / "results"; LEGACY = RESULTS / "cicids2018_legacy"; MODELS = ROOT / "models"
PAPER = ROOT / "paper_assets"; SRC = ROOT / "src"; CKPT = MODELS / "checkpoint.joblib"
LEGACY_POST = LEGACY / "posteriors.npz"; LEGACY_GAMMA = LEGACY / "gamma_sensitivity.json"
for _d in (RESULTS, LEGACY, MODELS, PAPER, PAPER / "figures", PAPER / "tables"): _d.mkdir(parents=True, exist_ok=True)
import json, numpy as np, joblib, pandas as pd
from sklearn.metrics import f1_score, accuracy_score
SD=f'{DATA_CIC_STAGE}'; C=11
z=np.load(f'{LEGACY}/posteriors.npz'); F=z['F']
y=np.load(f'{LEGACY}/y_test.npy')
names=['RF','DT','KNN','LR']; P={n:z[f'test_{n}'] for n in names}
CN=['Benign','Bot','BF-Web','BF-XSS','DDoS-HOIC','DDoS-LOIC-UDP','DoS-GoldenEye',
    'DoS-Hulk','DoS-Slowloris','Infiltration','SSH-Bruteforce']
B=CN.index('Benign'); INF=CN.index('Infiltration'); out={}

def fuse(Fm, Plist, g=8):
    Fg=np.power(np.maximum(Fm,1e-9),g); Wl=Fg/Fg.sum(0,keepdims=True)
    return Wl, np.argmax(sum(Wl[i][None,:]*Plist[i] for i in range(len(Plist))),1)

# ---- full CA-WSV vs KNN-free CA-WSV on test ----
Wf,pred_full=fuse(F,[P[n] for n in names])
idx3=[0,1,3]                                   # RF, DT, LR
W3,pred_nk=fuse(F[idx3],[P[names[i]] for i in idx3])
for tag,pr,Wm in [('CA-WSV (RF,DT,KNN,LR)',pred_full,Wf),('CA-WSV-noKNN (RF,DT,LR)',pred_nk,W3)]:
    f1c=f1_score(y,pr,average=None,labels=np.arange(C),zero_division=0)
    print(f"{tag:26s} acc={accuracy_score(y,pr):.4f} macroF1={f1_score(y,pr,average='macro'):.4f} "
          f"BF-Web={f1c[2]:.2f} BF-XSS={f1c[3]:.2f} FAR={(pr[y==B]!=B).mean():.4f}")
    out[tag]={'acc':float(accuracy_score(y,pr)),'macro_f1':float(f1_score(y,pr,average='macro')),
              'weighted_f1':float(f1_score(y,pr,average='weighted')),
              'per_class_f1':{CN[c]:round(float(f1c[c]),4) for c in range(C)},
              'FAR':float((pr[y==B]!=B).mean())}
print('KNN-free weights (RF,DT,LR) on BF-Web:',np.round(W3[:,2],3),
      ' avg contribution:',dict(zip(['RF','DT','LR'],np.round(W3.mean(1),3))))
out['W_noKNN_mean']={k:float(v) for k,v in zip(['RF','DT','LR'],W3.mean(1))}

# ---- FAR composition: which class absorbs the false alarms ----
fa=pred_full[y==B]; fa=fa[fa!=B]
comp={CN[c]:int((fa==c).sum()) for c in range(C) if (fa==c).sum()}
tot=len(fa)
print('FAR composition (benign misrouted to):',
      {k:f'{v} ({100*v/tot:.1f}%)' for k,v in sorted(comp.items(),key=lambda x:-x[1])})
out['FAR_composition']={k:{'n':v,'pct':round(100*v/tot,2)} for k,v in comp.items()}

# ---- robustness: full vs KNN-free, same eval subset ----
ridx=np.load(f'{SD}/rob_idx.npy'); d=np.load(f'{SD}/data.npz')
Xe,ye=d['X_test'][ridx],d['y_test'][ridx]
M={n:joblib.load(f'{SD}/{n.lower()}.joblib') for n in ['RF','DT','LR']}
order={n:np.argsort(M[n].classes_) for n in M}
def pred_nk_on(X):
    Pl=[M['RF'].predict_proba(X)[:,order['RF']],M['DT'].predict_proba(X)[:,order['DT']],
        M['LR'].predict_proba(X)[:,order['LR']]]
    return np.argmax(sum(W3[i][None,:]*Pl[i] for i in range(3)),1)
base=pred_nk_on(Xe); rob=[]
clean=dict(sigma=0.0,acc=float(accuracy_score(ye,base)),
           macro=float(f1_score(ye,base,average='macro')),stability=1.0)
rob.append(clean); print(f"noKNN clean: acc={clean['acc']:.4f} macroF1={clean['macro']:.4f}")
for sig in [0.01,0.02,0.05,0.10,0.20]:
    rng=np.random.default_rng(int(sig*10000)+7)
    p=pred_nk_on(Xe+rng.normal(0,sig,Xe.shape).astype(np.float32))
    r=dict(sigma=sig,acc=float(accuracy_score(ye,p)),
           macro=float(f1_score(ye,p,average='macro')),stability=float((p==base).mean()))
    rob.append(r); print(f"noKNN sigma={sig}: acc={r['acc']:.4f} macroF1={r['macro']:.4f} stab={r['stability']:.4f}")
out['robustness_noKNN']=rob
out['robustness_full']=[json.loads(l) for l in open(f'{SD}/rob.jsonl')]

# ---- M7: duplicate/collinear feature check ----
df=pd.read_pickle(f'{SD}/df.pkl')
pairs=[('Tot Fwd Pkts','Subflow Fwd Pkts'),('TotLen Fwd Pkts','Subflow Fwd Byts'),
       ('Tot Bwd Pkts','Subflow Bwd Pkts'),('TotLen Bwd Pkts','Subflow Bwd Byts')]
dup={}
for a,b in pairs:
    if a in df.columns and b in df.columns:
        eq=bool((df[a].values==df[b].values).all()); r=float(np.corrcoef(df[a],df[b])[0,1])
        dup[f'{a} == {b}']={'identical':eq,'pearson_r':round(r,6)}
        print(f"M7  {a:18s} vs {b:20s} identical={eq}  r={r:.6f}")
out['duplicate_features']=dup
json.dump(out,open('rev_knnfree.json','w'),indent=1)
