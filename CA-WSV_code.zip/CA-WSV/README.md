# CA-WSV: Class-Adaptive Weighted Soft Voting for Imbalanced Intrusion Detection

## Layout
```
src/      run_ds.py                      NSL-KDD / UNSW-NB15 / Bot-IoT protocol runner
          cicids_run.py                  CSE-CIC-IDS2018 runner (saves model bundle)
          xai_generic.py                 SHAP + LIME + explanation validation (nslkdd|unsw|botiot)
          xai_cicids.py                  same, CIC-IDS2018 (uses saved bundle)
          analysis_si_label_conflict.py  Specialisation Index and label-conflict audit
paper/    make_assets.py                 all LaTeX tables and figures
          make_framework.py              framework figure
legacy/   original CIC-IDS2018 study and peer-review experiments
notebooks/cicids2018_corrected.ipynb
```

## Data (`data/`, not tracked)
```
data/nsl-kdd/KDDTrain+.txt, KDDTest+.txt
data/unsw-nb15/UNSW_NB15_training-set.csv, UNSW_NB15_testing-set.csv
data/bot-iot/random_500k.csv
data/cic-ids2018/02-14-2018.csv ... 03-02-2018.csv
```
Set `CAWSV_ROOT` to override the repository root.

## Run
```bash
pip install -r requirements.txt
python src/run_ds.py nslkdd 0,1,2
python src/run_ds.py nslkdd official
python src/run_ds.py unsw 0,1,2
python src/run_ds.py unsw official
python src/run_ds.py botiot 0,1,2
python src/cicids_run.py 100000 0
python src/xai_generic.py nslkdd      # also: unsw, botiot
python src/xai_cicids.py
python src/analysis_si_label_conflict.py
python paper/make_assets.py           # needs results/ (+ results/cicids2018_legacy/ for the 3-split CIC-IDS2018 files)
python paper/make_framework.py
```
