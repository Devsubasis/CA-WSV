"""
Generates every paper table (LaTeX, booktabs) and figure (PDF+PNG) from the
saved, executed result files. No number is typed in by hand except the
UNSW/Bot-IoT label-conflict percentages, which were measured in a separate run
(values copied verbatim from that run's output, see LABEL_CONFLICT below).
"""
import os as _os
from pathlib import Path as _Path
ROOT = _Path(_os.environ.get("CAWSV_ROOT", _Path(__file__).resolve().parents[1]))
DATA = ROOT / "data"
DATA_NSL = DATA / "nsl-kdd"; DATA_UNSW = DATA / "unsw-nb15"; DATA_CIC = DATA / "cic-ids2018"
DATA_CIC_STAGE = DATA / "cic-ids2018-stage"; BOTIOT_CSV = DATA / "bot-iot" / "random_500k.csv"
RESULTS = ROOT / "results"; LEGACY = RESULTS / "cicids2018_legacy"; MODELS = ROOT / "models"
PAPER = ROOT / "paper_assets"; SRC = ROOT / "src"; CKPT = MODELS / "checkpoint.joblib"
LEGACY_POST = LEGACY / "posteriors.npz"; LEGACY_GAMMA = LEGACY / "gamma_sensitivity.json"
for _d in (RESULTS, LEGACY, MODELS, PAPER, PAPER / "figures", PAPER / "tables"): _d.mkdir(parents=True, exist_ok=True)
import json, os, numpy as np
from scipy import stats
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
from matplotlib.colors import LinearSegmentedColormap, TwoSlopeNorm

R = f"{RESULTS}"; A = f"{LEGACY}"
OUT = f"{PAPER}"; FIG = f"{OUT}/figures"; TAB = f"{OUT}/tables"
os.makedirs(FIG, exist_ok=True); os.makedirs(TAB, exist_ok=True)

# ---------------------------------------------------------------- style
BLUE, ORANGE, AQUA, YELLOW = "#2a78d6", "#eb6834", "#1baf7a", "#eda100"
INK, INK2, MUTED, GRID, SURF = "#0b0b0b", "#52514e", "#a3a29d", "#e4e3df", "#ffffff"
GRAY = "#b9b8b2"
SEQ = LinearSegmentedColormap.from_list("seq", ["#f4f8fd", "#cde2fb", "#86b6ef", "#3987e5", "#1c5cab", "#0d366b"])
DIV = LinearSegmentedColormap.from_list("div", ["#c43c3b", "#e98f8e", "#f0efec", "#86b6ef", "#1c5cab"])
plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 8, "axes.titlesize": 8.5, "axes.titleweight": "bold",
    "axes.labelsize": 8, "axes.labelcolor": INK2, "axes.edgecolor": MUTED, "axes.linewidth": 0.6,
    "xtick.color": INK2, "ytick.color": INK2, "xtick.labelsize": 7, "ytick.labelsize": 7,
    "xtick.major.width": 0.6, "ytick.major.width": 0.6, "axes.grid": False,
    "axes.spines.top": False, "axes.spines.right": False, "legend.frameon": False,
    "legend.fontsize": 7, "figure.dpi": 150, "savefig.dpi": 300, "savefig.bbox": "tight",
    "savefig.pad_inches": 0.03, "axes.titlelocation": "left", "text.color": INK,
    "pdf.fonttype": 42, "ps.fonttype": 42})
def save(fig, name):
    fig.savefig(f"{FIG}/{name}.pdf"); fig.savefig(f"{FIG}/{name}.png"); plt.close(fig)
def grid(ax, axis="x"):
    ax.grid(axis=axis, color=GRID, lw=0.5, zorder=0); ax.set_axisbelow(True)

# ---------------------------------------------------------------- data
def jl(p): return [json.loads(l) for l in open(p)]
M_ALL = ["CA-WSV", "Scalar", "Uniform", "RF", "DT", "KNN", "LR", "SVM", "HistGB"]
MNAME = {"CA-WSV": "CA-WSV (proposed)", "Scalar": "Scalar-weighted voting", "Uniform": "Uniform soft voting",
         "RF": "Random Forest", "DT": "Decision Tree", "KNN": "$k$-NN", "LR": "Logistic Regression",
         "SVM": "Linear SVM", "HistGB": "Hist. Gradient Boosting"}
runs = {"UNSW-NB15": jl(f"{R}/unsw_cap100000.jsonl"), "NSL-KDD": jl(f"{R}/nslkdd_cap100000.jsonl"),
        "Bot-IoT": jl(f"{R}/botiot_cap100000.jsonl")}
off = {"NSL-KDD": jl(f"{R}/nslkdd_official.jsonl")[0], "UNSW-NB15": jl(f"{R}/unsw_official.jsonl")[0]}
cic3 = jl(f"{A}/splits_100k.jsonl"); cic25 = jl(f"{A}/splits_25k.jsonl")
cic_orig = json.load(open(f"{A}/cawsv_results.json")); cic_gb = json.load(open(f"{A}/rev_gb.json"))
des = json.load(open(f"{A}/des_results.json")); rt = json.load(open(f"{A}/runtime_results.json"))
sig_cic = json.load(open(f"{A}/significance_table.json"))
xai = {"CIC-IDS2018": json.load(open(f"{R}/xai_cicids2018.json")), "UNSW-NB15": json.load(open(f"{R}/xai_unsw.json")),
       "NSL-KDD": json.load(open(f"{R}/xai_nslkdd.json")), "Bot-IoT": json.load(open(f"{R}/xai_botiot.json"))}
DS = ["CIC-IDS2018", "UNSW-NB15", "NSL-KDD", "Bot-IoT"]

# macro-F1 per seed:  mf1[ds][method] -> np.array (seeds)
mf1 = {}
mf1["CIC-IDS2018"] = {m: np.array([r[m]["macro_f1"] for r in cic3]) for m in ["CA-WSV", "Scalar", "Uniform", "RF", "KNN"]}
for d, rows in runs.items():
    mf1[d] = {m: np.array([r[m]["macro_f1"] for r in rows]) for m in M_ALL}
# CIC single-split extras (same protocol, original seed-42 split) -- footnoted in every table
cic_single = {"DT": cic_orig["summary"]["DT"]["macro_f1"], "LR": cic_orig["summary"]["LR"]["macro_f1"],
              "SVM": 0.6911, "HistGB": cic_gb["HistGB"]["macro_f1"]}  # SVM: Table XI of the revision pack (same split)

def F_of(d):
    if d == "CIC-IDS2018": return [np.array(cic_orig["F1_val"])]
    return [np.array(r["F"]) for r in runs[d]]
def W_of(d):
    if d == "CIC-IDS2018": return np.array(cic_orig["W"])
    return np.array(runs[d][0]["W"])
def classes_of(d):
    if d == "CIC-IDS2018": return cic_orig["class_names"]
    return list(runs[d][0]["CA-WSV"]["per_class_f1"].keys())
def SI(F):
    ms = F.mean(1).argmax(); return float((F.max(0) - F[ms]).mean())
def CHI(F): return float((F.max(0) - F.mean(0)).mean())

ABBR = {"Brute Force -Web": "BF-Web", "Brute Force -XSS": "BF-XSS", "DDOS attack-HOIC": "DDoS-HOIC",
        "DDOS attack-LOIC-UDP": "DDoS-UDP", "DoS attacks-GoldenEye": "DoS-GEye", "DoS attacks-Hulk": "DoS-Hulk",
        "DoS attacks-Slowloris": "DoS-Slowl", "Infilteration": "Infiltration", "SSH-Bruteforce": "SSH-BF",
        "Reconnaissance": "Recon."}
ab = lambda c: ABBR.get(c, c)

def f4(x): return f"{x:.4f}"
def pm(a): return f"{a.mean():.4f} $\\pm$ {a.std(ddof=1):.4f}" if len(a) > 1 else f"{a.mean():.4f}"
def pfmt(p): return "$<$0.001" if p < 0.001 else f"{p:.3f}"
import re
def wtab(name, body):
    body = re.sub(r"\\multicolumn\{\d+\}\{@\{\}l\}\{\\footnotesize (.*)\}\n\\end\{tabular\}",
                  lambda m_: "\\end{tabular}\n\n\\vspace{3pt}\\parbox{\\linewidth}{\\footnotesize " + m_.group(1) + "}", body)
    open(f"{TAB}/{name}.tex", "w").write(body); return body

# =====================================================================
# TABLES
# =====================================================================
# T1 dataset summary ---------------------------------------------------
info = {
 "CIC-IDS2018": dict(src="CIC/UNB (2018), 10 daily captures", raw="8,284,195", uniq="5,188,528", cls="11 (3 removed)",
                     feat="77 + protocol one-hot", cap="100,000", ratio=None, split="3 stratified 70/30 splits"),
 "UNSW-NB15": dict(src="UNSW Canberra (2015), official train+test", raw="257,673", uniq="162,745", cls="10",
                   feat="42 (196 after one-hot)", cap="100,000 (not reached)", ratio=None, split="3 splits + official"),
 "NSL-KDD": dict(src="UNB (2009), KDDTrain+ / KDDTest+", raw="148,517", uniq="147,888", cls="5 (super-classes)",
                 feat="41 (122 after one-hot)", cap="100,000 (not reached)", ratio=None, split="3 splits + official"),
 "Bot-IoT": dict(src="UNSW Canberra (2018), 500k random sample", raw="499,999", uniq="456,345", cls="5 (categories)",
                 feat="18 (43 after one-hot)", cap="100,000", ratio=None, split="3 stratified 70/30 splits"),
}
cnt = {"UNSW-NB15": runs["UNSW-NB15"][0]["meta"]["counts"], "NSL-KDD": runs["NSL-KDD"][0]["meta"]["counts"],
       "Bot-IoT": runs["Bot-IoT"][0]["meta"]["counts"]}
for d in cnt: info[d]["ratio"] = f"{max(cnt[d].values())/min(cnt[d].values()):,.0f}:1"
info["CIC-IDS2018"]["ratio"] = "439:1"   # 100,000 / 228 (BF-XSS) at the 100k cap
t = ["\\begin{table*}[t]", "\\centering", "\\caption{Benchmark datasets and the protocol applied to each. All four use the identical "
     "leakage-free pipeline: cleaning, exact-duplicate removal, removal of classes with $<$100 unique flows, per-class cap, "
     "stratified 70/30 split, MinMax scaling and ANOVA-$F$ selection ($k{=}20$) fitted on the training partition only.}",
     "\\label{tab:datasets}", "\\footnotesize", "\\setlength{\\tabcolsep}{3.5pt}", "\\begin{tabular}{@{}l>{\\raggedright}p{3.1cm}rr>{\\raggedright}p{1.7cm}>{\\raggedright}p{2.0cm}r>{\\raggedright\\arraybackslash}p{2.1cm}@{}}", "\\toprule",
     "Dataset & Source & Raw flows & Unique flows & Classes & Features & Imbalance$^\\ast$ & Evaluation \\\\", "\\midrule"]
for d in DS:
    i = info[d]; t.append(f"{d} & {i['src']} & {i['raw']} & {i['uniq']} & {i['cls']} & {i['feat']} & {i['ratio']} & {i['split']} \\\\")
t += ["\\bottomrule", "\\multicolumn{8}{@{}l}{\\footnotesize $^\\ast$Largest-to-smallest class ratio after deduplication and capping.}",
      "\\end{tabular}", "\\end{table*}"]
wtab("T1_datasets", "\n".join(t))

# T2 main results --------------------------------------------------------
t = ["\\begin{table*}[t]", "\\centering",
     "\\caption{Macro-F1 (mean $\\pm$ s.d.\\ over three independent stratified splits; scaler, selector, base models and "
     "$\\gamma$ refitted per split). Bold: best within the CA-WSV pool and its fusion ablations; underline: best overall.}",
     "\\label{tab:main}", "\\small", "\\begin{tabular}{@{}lcccc@{}}", "\\toprule",
     "Method & CIC-IDS2018 & UNSW-NB15 & NSL-KDD & Bot-IoT \\\\", "\\midrule"]
best_pool = {d: max(v.mean() for m, v in mf1[d].items() if m not in ("SVM", "HistGB")) for d in DS}
best_all = {d: max([v.mean() for v in mf1[d].values()] + ([cic_single["HistGB"]] if d == "CIC-IDS2018" else [])) for d in DS}
for m in M_ALL:
    row = [MNAME[m]]
    for d in DS:
        if m in mf1[d]:
            a = mf1[d][m]; s = pm(a)
            if abs(a.mean() - best_pool[d]) < 1e-12 and m not in ("SVM", "HistGB"): s = "\\textbf{" + s + "}"
            if abs(a.mean() - best_all[d]) < 1e-12: s = "\\underline{" + s + "}"
            row.append(s)
        else:
            row.append(f"{cic_single[m]:.4f}$^\\dagger$")
    t.append(" & ".join(row) + " \\\\")
    if m == "Uniform": t.append("\\midrule")
    if m == "LR": t.append("\\midrule")
t += ["\\midrule", "Selected $\\gamma^\\ast$ per split & " + " & ".join(
        ["\\{" + ",".join(str(r["gamma"]) for r in (cic3 if d == "CIC-IDS2018" else runs[d])) + "\\}" for d in DS]) + " \\\\",
      "\\bottomrule",
      "\\multicolumn{5}{@{}l}{\\footnotesize $^\\dagger$CIC-IDS2018: single stratified split under the same protocol "
      "(the three-split runs covered the five methods above). SVM and HistGB are not pool members.}",
      "\\end{tabular}", "\\end{table*}"]
wtab("T2_main_results", "\n".join(t))

# T3 significance ------------------------------------------------------------
sig = {}
t = ["\\begin{table*}[t]", "\\centering",
     "\\caption{Paired comparison of CA-WSV against each method (macro-F1, three paired splits). $\\Delta$ = CA-WSV minus "
     "competitor; $p$ = two-sided paired $t$-test; $d_z$ = Cohen's effect size. With $n{=}3$ the exact Wilcoxon signed-rank "
     "test cannot fall below $p{=}0.25$, so it is not informative here; the sign of every per-split difference is "
     "reported instead (`3/3' = CA-WSV better in all three splits).}", "\\label{tab:significance}", "\\footnotesize", "\\setlength{\\tabcolsep}{3pt}",
     "\\begin{tabular}{@{}l" + "rrc" * 4 + "@{}}", "\\toprule",
     "& \\multicolumn{3}{c}{CIC-IDS2018} & \\multicolumn{3}{c}{UNSW-NB15} & \\multicolumn{3}{c}{NSL-KDD} & \\multicolumn{3}{c}{Bot-IoT} \\\\",
     "\\cmidrule(lr){2-4}\\cmidrule(lr){5-7}\\cmidrule(lr){8-10}\\cmidrule(lr){11-13}",
     "vs. & $\\Delta$ & $p$ & wins & $\\Delta$ & $p$ & wins & $\\Delta$ & $p$ & wins & $\\Delta$ & $p$ & wins \\\\", "\\midrule"]
SHORT = {"Scalar": "Scalar", "Uniform": "Uniform", "RF": "RF", "DT": "DT", "KNN": "$k$-NN", "LR": "LR", "SVM": "SVM", "HistGB": "HistGB"}
for m in M_ALL[1:]:
    row = [SHORT[m]]
    for d in DS:
        if m not in mf1[d]: row += ["--", "--", "--"]; continue
        a, b = mf1[d]["CA-WSV"], mf1[d][m]; diff = a - b
        p = stats.ttest_rel(a, b).pvalue; dz = diff.mean() / diff.std(ddof=1) if diff.std(ddof=1) > 0 else np.nan
        sig[(d, m)] = (diff.mean(), p, dz, int((diff > 0).sum()))
        sgn = f"{diff.mean():+.4f}"
        if p < 0.05: sgn = "\\textbf{" + sgn + "}"
        row += [sgn, pfmt(p), f"{int((diff > 0).sum())}/{len(diff)}"]
    t.append(" & ".join(row) + " \\\\")
t += ["\\bottomrule", "\\multicolumn{13}{@{}l}{\\footnotesize Bold $\\Delta$: $p<0.05$. Positive $\\Delta$ favours CA-WSV.}",
      "\\end{tabular}", "\\end{table*}"]
wtab("T3_significance", "\n".join(t))

# Friedman over the five methods available for all four datasets
FM = ["CA-WSV", "Scalar", "Uniform", "RF", "KNN"]
Mtx = np.array([[mf1[d][m].mean() for m in FM] for d in DS])
ranks = np.array([stats.rankdata(-row) for row in Mtx]); avg_rank = ranks.mean(0)
fr = stats.friedmanchisquare(*[Mtx[:, j] for j in range(len(FM))])
N, k = len(DS), len(FM)
q05 = {2: 1.960, 3: 2.343, 4: 2.569, 5: 2.728, 6: 2.850}[k]
CD = q05 * np.sqrt(k * (k + 1) / (6 * N))
ff = (N - 1) * fr.statistic / (N * (k - 1) - fr.statistic)
t = ["\\begin{table}[t]", "\\centering",
     "\\caption{Friedman test over the four datasets for the five methods evaluated on all of them (mean macro-F1 per "
     "dataset). Nemenyi critical difference at $\\alpha{=}0.05$.}", "\\label{tab:friedman}", "\\small",
     "\\begin{tabular}{@{}lc@{}}", "\\toprule", "Method & Average rank \\\\", "\\midrule"]
for j in np.argsort(avg_rank): t.append(f"{MNAME[FM[j]]} & {avg_rank[j]:.2f} \\\\")
t += ["\\midrule", f"Friedman $\\chi^2_F$ (df$=${k-1}) & {fr.statistic:.2f} ($p={fr.pvalue:.3f}$) \\\\",
      f"Iman--Davenport $F_F$ & {ff:.2f} \\\\", f"Nemenyi CD ($k={k}$, $N={N}$) & {CD:.2f} \\\\",
      "\\bottomrule", "\\end{tabular}", "\\end{table}"]
wtab("T4_friedman", "\n".join(t))

# T5 distribution shift ---------------------------------------------------
t = ["\\begin{table}[t]", "\\centering",
     "\\caption{In-distribution (mean of three stratified splits) versus official train/test partitions, which "
     "introduce distribution shift. Macro-F1.}", "\\label{tab:shift}", "\\small",
     "\\begin{tabular}{@{}lcccc@{}}", "\\toprule",
     "& \\multicolumn{2}{c}{NSL-KDD} & \\multicolumn{2}{c}{UNSW-NB15} \\\\", "\\cmidrule(lr){2-3}\\cmidrule(lr){4-5}",
     "Method & Strat. & Official & Strat. & Official \\\\", "\\midrule"]
for m in M_ALL:
    vals = []
    for d in ["NSL-KDD", "UNSW-NB15"]:
        o = [off[d][mm]["macro_f1"] for mm in M_ALL]; s = off[d][m]["macro_f1"]
        so = f"{s:.4f}"; so = "\\textbf{" + so + "}" if s == max(o) else so
        vals += [f"{mf1[d][m].mean():.4f}", so]
    t.append(MNAME[m] + " & " + " & ".join(vals) + " \\\\")
t += ["\\bottomrule", "\\end{tabular}", "\\end{table}"]
wtab("T5_shift", "\n".join(t))

# T6 specialisation index ---------------------------------------------------
si_rows = []
for d in DS:
    Fs = F_of(d)
    dl = (mf1[d]["CA-WSV"] - mf1[d]["Scalar"])
    si_rows.append((d, np.mean([SI(F) for F in Fs]), np.mean([CHI(F) for F in Fs]), dl.mean(),
                    sig[(d, "Scalar")][1], np.mean([F.mean(1).max() for F in Fs])))
for d in ["NSL-KDD", "UNSW-NB15"]:
    F = np.array(off[d]["F"]); si_rows.append((d + " (official)", SI(F), CHI(F),
                    off[d]["CA-WSV"]["macro_f1"] - off[d]["Scalar"]["macro_f1"], np.nan, F.mean(1).max()))
t = ["\\begin{table}[t]", "\\centering",
     "\\caption{Validation-time diagnostics against the realised gain of class-adaptive over scalar fusion. "
     "SI: Specialisation Index (Eq.~\\ref{eq:si}); CHI: competence heterogeneity (best minus mean model, per class). "
     "Both are computed from the validation F1 matrix only, before any test data is seen.}",
     "\\label{tab:si}", "\\small", "\\begin{tabular}{@{}lccrc@{}}", "\\toprule",
     "Setting & SI & CHI & $\\Delta_{\\text{CA}-\\text{Scalar}}$ & $p$ \\\\", "\\midrule"]
for r in si_rows:
    p = "--" if np.isnan(r[4]) else pfmt(r[4])
    if r[0] == "NSL-KDD (official)": t.append("\\midrule")
    t.append(f"{r[0]} & {r[1]:.4f} & {r[2]:.4f} & {r[3]:+.4f} & {p} \\\\")
t += ["\\bottomrule", "\\multicolumn{5}{@{}l}{\\footnotesize SI was defined after these results were observed; "
      "it must be confirmed on a held-out setting.}", "\\end{tabular}", "\\end{table}"]
wtab("T6_specialisation_index", "\n".join(t))

# T7 per-class F1 (UNSW, NSL, Bot-IoT seed 0; CIC original split) -----------
def pc(d, m):
    if d == "CIC-IDS2018":
        i = cic_orig["models"].index(m) if m in cic_orig["models"] else None
        return None
    return runs[d][0][m]["per_class_f1"]
cic_pc = json.load(open(f"{A}/diag_results.json"))["f1"]   # CA-WSV, RF, KNN on original split
t = ["\\begin{table*}[t]", "\\centering",
     "\\caption{Per-class F1 of CA-WSV against the strongest alternatives (first split of each dataset; CIC-IDS2018 on "
     "the original split). $n$: test support. Shaded rows: classes where CA-WSV improves on scalar fusion by $\\geq$0.03.}",
     "\\label{tab:perclass}", "\\scriptsize", "\\begin{tabular}{@{}llrcccc@{}}", "\\toprule",
     "Dataset & Class & $n$ & CA-WSV & Scalar & RF & $k$-NN \\\\", "\\midrule"]
cic_map = {"Benign": "Benign", "Bot": "Bot", "Brute Force -Web": "BF-Web", "Brute Force -XSS": "BF-XSS",
           "DDOS attack-HOIC": "DDoS-HOIC", "DDOS attack-LOIC-UDP": "DDoS-LOIC-UDP", "DoS attacks-GoldenEye": "DoS-GoldenEye",
           "DoS attacks-Hulk": "DoS-Hulk", "DoS attacks-Slowloris": "DoS-Slowloris", "Infilteration": "Infiltration",
           "SSH-Bruteforce": "SSH-Bruteforce"}
cic_sup = {"Benign": 30000, "Bot": 30000, "BF-Web": 166, "BF-XSS": 68, "DDoS-HOIC": 30000, "DDoS-LOIC-UDP": 519,
           "DoS-GoldenEye": 12418, "DoS-Hulk": 30000, "DoS-Slowloris": 2914, "Infiltration": 30000, "SSH-Bruteforce": 28214}
cic_scalar = {c: v for c, v in zip(cic_orig["class_names"], [None] * 11)}
for d in DS:
    first = True
    if d == "CIC-IDS2018":
        for c in cic_orig["class_names"]:
            k2 = cic_map[c]
            row = [d if first else "", ab(c), f"{cic_sup[k2]:,}", f"{cic_pc['CA-WSV'][k2]:.3f}", "--",
                   f"{cic_pc['RF'][k2]:.3f}", f"{cic_pc['KNN'][k2]:.3f}"]
            t.append(" & ".join(row) + " \\\\"); first = False
    else:
        r0 = runs[d][0]
        for c in r0["CA-WSV"]["per_class_f1"]:
            ca, sc = r0["CA-WSV"]["per_class_f1"][c], r0["Scalar"]["per_class_f1"][c]
            row = [d if first else "", ab(c), f"{r0['test_support'][c]:,}", f"{ca:.3f}", f"{sc:.3f}",
                   f"{r0['RF']['per_class_f1'][c]:.3f}", f"{r0['KNN']['per_class_f1'][c]:.3f}"]
            line = " & ".join(row) + " \\\\"
            if ca - sc >= 0.03: line = "\\rowcolor{gray!15} " + line
            t.append(line); first = False
    t.append("\\midrule" if d != DS[-1] else "\\bottomrule")
t += ["\\multicolumn{7}{@{}l}{\\footnotesize Per-class scalar-fusion F1 was not stored for the original CIC-IDS2018 split.}",
      "\\end{tabular}", "\\end{table*}"]
wtab("T7_perclass", "\n".join(t))

# T8 DES + cost (CIC-IDS2018) ---------------------------------------------
c = des["CA-WSV (Proposed)"]; ku = des["KNORA-U"]; ke = des["KNORA-E"]
t = ["\\begin{table}[t]", "\\centering",
     "\\caption{CA-WSV against dynamic ensemble selection (DESlib, same four base models, CIC-IDS2018, identical split). "
     "Fusion cost excludes base-model inference, which is common to all three.}", "\\label{tab:des}", "\\small",
     "\\begin{tabular}{@{}lccccr@{}}", "\\toprule",
     "Method & Acc. & Macro-F1 & BF-Web F1 & Fusion (ms/flow) & Params \\\\", "\\midrule",
     f"CA-WSV & {c['accuracy']:.4f} & \\textbf{{{c['f1_macro']:.4f}}} & \\textbf{{{c['bf_web_f1']:.4f}}} & \\textbf{{{c['fusion_ms_per_sample']:.5f}}} & 44 \\\\",
     f"KNORA-U & \\textbf{{{ku['accuracy']:.4f}}} & {ku['f1_macro']:.4f} & {ku['bf_web_f1']:.4f} & {ku['fusion_ms_per_sample']:.3f} & DSEL \\\\",
     f"KNORA-E & {ke['accuracy']:.4f} & {ke['f1_macro']:.4f} & {ke['bf_web_f1']:.4f} & {ke['fusion_ms_per_sample']:.3f} & DSEL \\\\",
     "\\bottomrule", f"\\multicolumn{{6}}{{@{{}}l}}{{\\footnotesize DSEL: the {des['_meta']['n_dsel']:,}-flow selection set "
     "is retained and searched at inference.}", "\\end{tabular}", "\\end{table}"]
wtab("T8_des", "\n".join(t))

# T9 runtime ----------------------------------------------------------------
t = ["\\begin{table}[t]", "\\centering",
     f"\\caption{{Training and inference cost on CIC-IDS2018 ({rt['_meta']['n_train']:,} training flows; inference timed on "
     f"{rt['_meta']['n_test_timed']:,} test flows; {rt['_meta']['cpu']}).}}", "\\label{tab:runtime}", "\\small",
     "\\begin{tabular}{@{}lrrr@{}}", "\\toprule", "Component & Train (s) & Inference (ms/flow) & Size (MB) \\\\", "\\midrule"]
for k_ in ["Random Forest", "Decision Tree", "KNN", "Logistic Regression"]:
    v = rt[k_]; t.append(f"{k_.replace('KNN','$k$-NN')} & {v['train_s']:.2f} & {v['per_sample_ms']:.4f} & {v['model_mb']:.2f} \\\\")
v = rt["CA-WSV (proposed)"]
t += ["\\midrule", f"CA-WSV weight learning & {v['weight_learn_s']:.3f} & -- & -- \\\\",
      f"CA-WSV fusion step only & -- & {1000*v['fusion_s']/rt['_meta']['n_test_timed']:.5f} & $<$0.01 \\\\",
      f"CA-WSV end-to-end & {v['train_s']:.2f} & {v['per_sample_ms']:.4f} & {v['model_mb']:.2f} \\\\",
      "\\bottomrule", "\\multicolumn{4}{@{}l}{\\footnotesize End-to-end latency is dominated by $k$-NN retrieval, "
      "which scales with training-set size.}", "\\end{tabular}", "\\end{table}"]
wtab("T9_runtime", "\n".join(t))

# T10 XAI validation ----------------------------------------------------------
t = ["\\begin{table*}[t]", "\\centering",
     "\\caption{Quantitative validation of the explanations of the full fused CA-WSV predictor (KernelSHAP on "
     "$s_c(\\mathbf{x})=\\sum_m w_{m,c}\\,p_m(c\\mid\\mathbf{x})$, not on a single member). Faithfulness: area under the "
     "deletion curve when features are removed in SHAP order versus random order (lower is better; the gap is the "
     "faithfulness margin). Stability: cosine similarity of attributions under Gaussian jitter ($\\sigma{=}0.01$). "
     "Sparsity: Gini coefficient of $|\\phi|$. Agreement: Jaccard overlap of SHAP and LIME top-5 features.}",
     "\\label{tab:xai}", "\\small", "\\begin{tabular}{@{}lccccccc@{}}", "\\toprule",
     "& \\multicolumn{3}{c}{Faithfulness (deletion AUC)} & Stability & \\multicolumn{2}{c}{Sparsity (Gini)} & Agreement \\\\",
     "\\cmidrule(lr){2-4}\\cmidrule(lr){6-7}",
     "Dataset & SHAP order & Random & Margin & cosine & Fused & RF & SHAP--LIME \\\\", "\\midrule"]
for d in DS:
    x = xai[d]; f_ = x["faithfulness_deletion_test"]; s_ = x["stability_cosine_sim_fused"]; g = x["sparsity_gini"]
    t.append(f"{d} & {f_['mean_AUC_deleting_top_shap_features']:.3f} & {f_['mean_AUC_deleting_random_order']:.3f} & "
             f"\\textbf{{{f_['gap']:+.3f}}} & {s_['mean']:.3f} $\\pm$ {s_['std']:.3f} & {g['CA-WSV_fused']:.3f} & {g['RF']:.3f} & "
             f"{x['shap_lime_top5_jaccard_fused']:.3f} \\\\")
t += ["\\bottomrule", "\\multicolumn{8}{@{}l}{\\footnotesize CIC-IDS2018 explanations use a single-split retraining on 9 of "
      "the 10 daily files (02-20-2018 unavailable in the XAI environment).}", "\\end{tabular}", "\\end{table*}"]
wtab("T10_xai_validation", "\n".join(t))

# T11 explanation cost ----------------------------------------------------------
t = ["\\begin{table}[t]", "\\centering", "\\caption{Explanation cost (ms per explained flow). The fused predictor costs "
     "about the same to explain as its $k$-NN member alone.}", "\\label{tab:xaicost}", "\\small",
     "\\begin{tabular}{@{}lrrrrr@{}}", "\\toprule",
     "Dataset & TreeSHAP RF & KernelSHAP $k$-NN & KernelSHAP fused & Ratio & LIME fused \\\\", "\\midrule"]
for d in DS:
    tm = xai[d]["timing_ms_per_instance"]
    t.append(f"{d} & {tm['TreeSHAP_RF']:,.0f} & {tm['KernelSHAP_KNN']:,.0f} & {tm['KernelSHAP_fused_CAWSV']:,.0f} & "
             f"{tm['KernelSHAP_fused_CAWSV']/tm['KernelSHAP_KNN']:.2f} & {tm['LIME_fused']:,.0f} \\\\")
t += ["\\bottomrule", "\\end{tabular}", "\\end{table}"]
wtab("T11_xai_cost", "\n".join(t))

# T12 top SHAP features -----------------------------------------------------------
t = ["\\begin{table*}[t]", "\\centering", "\\caption{Five most influential features of the fused CA-WSV predictor "
     "(mean $|\\phi|$ over explained flows).}", "\\label{tab:topfeat}", "\\small", "\\begin{tabular}{@{}c" + "lr" * 4 + "@{}}",
     "\\toprule", "& " + " & ".join(f"\\multicolumn{{2}}{{c}}{{{d}}}" for d in DS) + " \\\\",
     "\\cmidrule(lr){2-3}\\cmidrule(lr){4-5}\\cmidrule(lr){6-7}\\cmidrule(lr){8-9}",
     "Rank & " + " & ".join(["Feature & $|\\phi|$"] * 4) + " \\\\", "\\midrule"]
tops = {d: list(xai[d]["global_feature_importance_fused_meanabs_shap"].items())[:5] for d in DS}
for i in range(5):
    t.append(f"{i+1} & " + " & ".join(f"\\texttt{{{tops[d][i][0].replace('_','\\_')}}} & {tops[d][i][1]:.3f}" for d in DS) + " \\\\")
t += ["\\bottomrule", "\\end{tabular}", "\\end{table*}"]
wtab("T12_top_features", "\n".join(t))

# T13 label conflicts --------------------------------------------------------------
LABEL_CONFLICT = {"UNSW-NB15": [("Backdoor", 81.4), ("Analysis", 77.9), ("DoS", 34.1), ("Reconnaissance", 15.7),
                                ("Fuzzers", 10.5), ("Exploits", 7.2), ("Worms", 7.0), ("Generic", 4.2),
                                ("Shellcode", 0.7), ("Normal", 0.5)],
                  "Bot-IoT": [("Theft", 11.5), ("Reconnaissance", 0.5), ("DDoS", 0.0), ("DoS", 0.0), ("Normal", 0.0)]}
t = ["\\begin{table}[t]", "\\centering", "\\caption{Share of each class's unique flows whose feature vector also occurs "
     "with a different label (irreducible confusion). UNSW-NB15: 2,445 of 153,684 unique vectors (1.59\\%) carry two or "
     "more labels; Bot-IoT: 120 of 456,222 (0.03\\%).}", "\\label{tab:conflict}", "\\small",
     "\\begin{tabular}{@{}lrlr@{}}", "\\toprule", "UNSW-NB15 class & \\% & Bot-IoT class & \\% \\\\", "\\midrule"]
u, b = LABEL_CONFLICT["UNSW-NB15"], LABEL_CONFLICT["Bot-IoT"]
for i in range(len(u)):
    bb = f"{ab(b[i][0])} & {b[i][1]:.1f}" if i < len(b) else " & "
    t.append(f"{u[i][0]} & {u[i][1]:.1f} & {bb} \\\\")
t += ["\\bottomrule", "\\end{tabular}", "\\end{table}"]
wtab("T13_label_conflict", "\n".join(t))

# T14 imbalance scaling (CIC) --------------------------------------------------------
def arr(rows, m, k="macro_f1"): return np.array([r[m][k] for r in rows])
t = ["\\begin{table}[t]", "\\centering", "\\caption{Effect of the per-class cap on CIC-IDS2018 (100k: 3 splits; 25k: "
     "10 splits). The class-adaptive gain is large only when imbalance is severe.}", "\\label{tab:imbalance}", "\\small",
     "\\begin{tabular}{@{}lcc@{}}", "\\toprule", "Quantity & cap 100k & cap 25k \\\\", "\\midrule"]
for m in ["CA-WSV", "Scalar", "Uniform", "RF", "KNN"]:
    t.append(f"{MNAME[m]} macro-F1 & {pm(arr(cic3, m))} & {pm(arr(cic25, m))} \\\\")
d1, d2 = arr(cic3, "CA-WSV") - arr(cic3, "Scalar"), arr(cic25, "CA-WSV") - arr(cic25, "Scalar")
t += ["\\midrule", f"$\\Delta$ CA-WSV $-$ Scalar & {d1.mean():+.4f} & {d2.mean():+.4f} \\\\",
      f"BF-Web F1, CA-WSV & {arr(cic3,'CA-WSV','bfweb_f1').mean():.3f} & {arr(cic25,'CA-WSV','bfweb_f1').mean():.3f} \\\\",
      f"BF-Web F1, Scalar & {arr(cic3,'Scalar','bfweb_f1').mean():.3f} & {arr(cic25,'Scalar','bfweb_f1').mean():.3f} \\\\",
      "\\bottomrule", "\\end{tabular}", "\\end{table}"]
wtab("T14_imbalance", "\n".join(t))

# =====================================================================
# FIGURES
# =====================================================================
# F2 cross-dataset dot plot ---------------------------------------------------
fig, axes = plt.subplots(1, 4, figsize=(7.16, 2.55), sharey=True)
order = ["CA-WSV", "Scalar", "Uniform", "RF", "DT", "KNN", "HistGB", "SVM", "LR"]
for ax, d in zip(axes, DS):
    for i, m in enumerate(order):
        y = len(order) - 1 - i
        if m in mf1[d]:
            a = mf1[d][m]; c_ = BLUE if m == "CA-WSV" else (ORANGE if m == "HistGB" else INK2)
            ax.plot([a.min(), a.max()], [y, y], color=c_, lw=1.2, alpha=0.55, solid_capstyle="round", zorder=2)
            ax.scatter(a, [y] * len(a), s=7, color=c_, alpha=0.45, lw=0, zorder=3)
            ax.scatter([a.mean()], [y], s=34 if m == "CA-WSV" else 22, color=c_, edgecolor="white", lw=1.2, zorder=4)
        else:
            ax.scatter([cic_single[m]], [y], s=22, facecolor="white", edgecolor=INK2, lw=1, zorder=4)
    ax.set_title(d); grid(ax, "x"); ax.set_xlabel("Macro-F1")
    lo = min(min(v.min() for v in mf1[d].values()), cic_single["LR"] if d == "CIC-IDS2018" else 1)
    ax.set_xlim(lo - 0.03, None)
    ref = mf1[d]["CA-WSV"].mean(); ax.axvline(ref, color=BLUE, lw=0.6, ls=(0, (2, 2)), zorder=1)
axes[0].set_yticks(range(len(order))); axes[0].set_yticklabels([MNAME[m].replace(" (proposed)", "") for m in order[::-1]])
axes[0].get_yticklabels()[-1].set_color(BLUE); axes[0].get_yticklabels()[-1].set_fontweight("bold")
fig.text(0.99, -0.04, "Filled dot: mean of 3 splits; small dots/bar: individual splits; hollow: single split (CIC-IDS2018). "
         "Dashed line: CA-WSV mean.", ha="right", fontsize=6, color=INK2)
fig.tight_layout(w_pad=0.6); save(fig, "F02_crossdataset_macroF1")

# F3 forest plot of paired differences -------------------------------------------
fig, axes = plt.subplots(1, 4, figsize=(7.16, 2.3), sharey=True)
comp = ["Scalar", "Uniform", "RF", "KNN", "DT", "HistGB"]
for ax, d in zip(axes, DS):
    for i, m in enumerate(comp):
        y = len(comp) - 1 - i
        if m not in mf1[d]: ax.text(0, y, "n/a", ha="center", va="center", fontsize=6, color=MUTED); continue
        diff = mf1[d]["CA-WSV"] - mf1[d][m]; mu = diff.mean(); se = diff.std(ddof=1) / np.sqrt(len(diff))
        h = stats.t.ppf(0.975, len(diff) - 1) * se
        p = sig[(d, m)][1]; c_ = BLUE if (mu > 0 and p < 0.05) else (ORANGE if (mu < 0 and p < 0.05) else INK2)
        ax.plot([mu - h, mu + h], [y, y], color=c_, lw=1.4, solid_capstyle="round")
        ax.scatter(diff, [y] * len(diff), s=6, color=c_, alpha=0.5, lw=0)
        ax.scatter([mu], [y], s=26, marker="D", color=c_, edgecolor="white", lw=1, zorder=4)
    ax.axvline(0, color=INK2, lw=0.7); grid(ax, "x"); ax.set_title(d)
axes[0].set_yticks(range(len(comp))); axes[0].set_yticklabels([MNAME[m] for m in comp[::-1]])
fig.supxlabel("$\\Delta$ macro-F1 (CA-WSV − competitor)", fontsize=8, color=INK2, y=0.02)
fig.text(0.99, -0.05, "Diamond: mean difference; bar: 95% t-CI over splits; blue: CA-WSV significantly better (p<0.05); "
         "orange: significantly worse; grey: n.s.", ha="right", fontsize=6, color=INK2)
fig.tight_layout(w_pad=0.6); save(fig, "F03_paired_differences_forest")

# F4 weight-matrix heatmaps --------------------------------------------------------
fig, axes = plt.subplots(2, 2, figsize=(7.16, 4.4), gridspec_kw=dict(width_ratios=[11, 10]))
for ax, d in zip(axes.flat, DS):
    W = W_of(d); cl = [ab(c) for c in classes_of(d)]
    im = ax.imshow(W, cmap=SEQ, vmin=0, vmax=1, aspect="auto")
    for i in range(W.shape[0]):
        for j in range(W.shape[1]):
            ax.text(j, i, f"{W[i,j]:.2f}".lstrip("0") if W[i, j] < 1 else "1", ha="center", va="center", fontsize=5.6,
                    color="white" if W[i, j] > 0.55 else INK)
    ax.set_yticks(range(4)); ax.set_yticklabels(["RF", "DT", "$k$-NN", "LR"])
    ax.set_xticks(range(len(cl))); ax.set_xticklabels(cl, rotation=40, ha="right", fontsize=6)
    g = cic_orig["gamma"] if d == "CIC-IDS2018" else runs[d][0]["gamma"]
    ax.set_title(f"{d}  ($\\gamma^\\ast$={g})"); ax.tick_params(length=0)
    for s in ax.spines.values(): s.set_visible(False)
    ax.set_xticks(np.arange(-.5, len(cl), 1), minor=True); ax.set_yticks(np.arange(-.5, 4, 1), minor=True)
    ax.grid(which="minor", color="white", lw=1.5); ax.tick_params(which="minor", length=0)
fig.subplots_adjust(hspace=0.62, wspace=0.18)
cb = fig.colorbar(im, ax=axes, fraction=0.02, pad=0.015); cb.set_label("Weight $w_{m,c}$ (column sums to 1)"); cb.outline.set_visible(False)
save(fig, "F04_weight_matrices")

# F5 validation competence matrices with per-class best model -------------------------
fig, axes = plt.subplots(2, 2, figsize=(7.16, 4.4), gridspec_kw=dict(width_ratios=[11, 10]))
for ax, d in zip(axes.flat, DS):
    F = F_of(d)[0]; cl = [ab(c) for c in classes_of(d)]
    im = ax.imshow(F, cmap=SEQ, vmin=0, vmax=1, aspect="auto")
    best = F.argmax(0); ms = F.mean(1).argmax()
    for i in range(4):
        for j in range(F.shape[1]):
            ax.text(j, i, f"{F[i,j]:.2f}", ha="center", va="center", fontsize=5.4, color="white" if F[i, j] > 0.55 else INK,
                    fontweight="bold" if best[j] == i else "normal")
    for j in range(F.shape[1]):
        if best[j] != ms and F[best[j], j] - F[ms, j] > 0.005:
            ax.add_patch(plt.Rectangle((j - .42, best[j] - .42), .84, .84, fill=False, ec=ORANGE, lw=1.8, zorder=10))
    ax.set_yticks(range(4)); ax.set_yticklabels(["RF", "DT", "$k$-NN", "LR"])
    ax.set_xticks(range(len(cl))); ax.set_xticklabels(cl, rotation=40, ha="right", fontsize=6)
    ax.set_title(f"{d}  (SI = {SI(F):.4f}, first split)" if d != "CIC-IDS2018" else f"{d}  (SI = {SI(F):.4f})"); ax.tick_params(length=0)
    for s in ax.spines.values(): s.set_visible(False)
    ax.set_xticks(np.arange(-.5, len(cl), 1), minor=True); ax.set_yticks(np.arange(-.5, 4, 1), minor=True)
    ax.grid(which="minor", color="white", lw=1.5); ax.tick_params(which="minor", length=0)
fig.subplots_adjust(hspace=0.62, wspace=0.18)
cb = fig.colorbar(im, ax=axes, fraction=0.02, pad=0.015); cb.set_label("Validation F1 $F_{m,c}$"); cb.outline.set_visible(False)
fig.text(0.5, 0.0, "Orange box: class whose best model differs from the overall-best model by more than 0.005 F1 "
         "(the specialisation that class-adaptive fusion can exploit).", ha="center", fontsize=6, color=INK2)
save(fig, "F05_competence_matrices_SI")

# F6 per-class gain heatmap (CA-WSV − Scalar, CA-WSV − RF) ----------------------------
fig, axes = plt.subplots(3, 1, figsize=(7.16, 3.3))
lim = 0.16; norm = TwoSlopeNorm(vcenter=0, vmin=-lim, vmax=lim)
for ax, d in zip(axes, ["UNSW-NB15", "NSL-KDD", "Bot-IoT"]):
    cl = list(runs[d][0]["CA-WSV"]["per_class_f1"].keys())
    G = np.array([[np.mean([r["CA-WSV"]["per_class_f1"][c] - r[m]["per_class_f1"][c] for r in runs[d]]) for c in cl]
                  for m in ["Scalar", "Uniform", "RF", "KNN"]])
    im = ax.imshow(G, cmap=DIV, norm=norm, aspect="auto")
    for i in range(G.shape[0]):
        for j in range(G.shape[1]):
            ax.text(j, i, ("0.000" if abs(G[i,j]) < 0.0005 else f"{G[i,j]:+.3f}"), ha="center", va="center", fontsize=5.6, color="white" if abs(G[i, j]) > 0.09 else INK)
    ax.set_yticks(range(4)); ax.set_yticklabels(["vs Scalar", "vs Uniform", "vs RF", "vs $k$-NN"], fontsize=6.3)
    ax.set_xticks(range(len(cl))); ax.set_xticklabels([ab(c) for c in cl], fontsize=6.3)
    ax.set_title(d + " — per-class $\\Delta$F1 (mean of 3 splits)", fontsize=7.5); ax.tick_params(length=0)
    for s in ax.spines.values(): s.set_visible(False)
    ax.set_xticks(np.arange(-.5, len(cl), 1), minor=True); ax.set_yticks(np.arange(-.5, 4, 1), minor=True)
    ax.grid(which="minor", color="white", lw=1.5); ax.tick_params(which="minor", length=0)
fig.subplots_adjust(hspace=0.75, right=0.88); cax = fig.add_axes([0.905, 0.15, 0.012, 0.7])
cb = fig.colorbar(im, cax=cax, extend="both")
cb.set_label("CA-WSV better  ←  0  →  worse", rotation=90); cb.outline.set_visible(False)
cb.set_label("$\\Delta$F1 (blue: CA-WSV better)")
save(fig, "F06_perclass_gain_heatmap")

# F7 SI vs CHI diagnostic ---------------------------------------------------------------
fig, axes = plt.subplots(1, 2, figsize=(7.16, 2.75), sharey=True)
pts = [(r[0], r[1], r[2], r[3]) for r in si_rows]
OFFS = {0: {"CIC-IDS2018": (6, -9), "UNSW-NB15": (6, 2), "NSL-KDD": (6, 5), "Bot-IoT": (-4, 6),
            "NSL-KDD (official)": (6, 2), "UNSW-NB15 (official)": (7, -4)},
        1: {"CIC-IDS2018": (6, 2), "UNSW-NB15": (-6, -11), "NSL-KDD": (6, -11), "Bot-IoT": (6, 4),
            "NSL-KDD (official)": (6, 2), "UNSW-NB15 (official)": (-6, 6)}}
HA = {0: {"Bot-IoT": "right"}, 1: {"UNSW-NB15": "right", "UNSW-NB15 (official)": "right"}}
for k_ax, (ax, idx, lab) in enumerate([(axes[0], 2, "CHI (best − mean model, per class)"), (axes[1], 1, "Specialisation Index SI")]):
    if k_ax == 1:
        ax.axvspan(-0.0015, 0.0012, color=GRID, alpha=0.8, lw=0, zorder=0)
        ax.text(0.0016, -0.0045, "SI ≈ 0: no gain", fontsize=6, color=INK2, va="bottom")
    for name, si_, chi_, dl in pts:
        x = chi_ if idx == 2 else si_
        shift = "official" in name
        ax.scatter(x, dl, s=40, marker="s" if shift else "o", facecolor="white" if shift else BLUE,
                   edgecolor=BLUE, lw=1.3, zorder=4)
        ax.annotate(name.replace(" (official)", " (official)"), (x, dl), xytext=OFFS[k_ax][name], textcoords="offset points",
                    fontsize=5.8, color=INK2, ha=HA[k_ax].get(name, "left"))
    ax.axhline(0, color=INK2, lw=0.6); grid(ax, "y"); ax.set_xlabel(lab)
axes[0].set_ylabel("$\\Delta$ macro-F1, CA-WSV − Scalar"); axes[0].set_ylim(-0.0065, 0.025)
axes[0].set_title("(a) CHI does not separate gain from no gain"); axes[1].set_title("(b) SI ≈ 0 coincides with no gain")
fig.text(0.99, -0.03, "Filled circle: stratified splits (in-distribution); hollow square: official split (distribution shift).",
         ha="right", fontsize=6, color=INK2)
fig.tight_layout(); save(fig, "F07_SI_vs_CHI_diagnostic")

# F8 XAI validation small multiples -----------------------------------------------------
fig, axes = plt.subplots(1, 4, figsize=(7.16, 2.35))
y = np.arange(len(DS))[::-1]
ax = axes[0]
for yi, d in zip(y, DS):
    f_ = xai[d]["faithfulness_deletion_test"]; a, b = f_["mean_AUC_deleting_top_shap_features"], f_["mean_AUC_deleting_random_order"]
    ax.plot([a, b], [yi, yi], color=GRAY, lw=2.2, solid_capstyle="round", zorder=1)
    ax.scatter(b, yi, s=26, color=INK2, zorder=3); ax.scatter(a, yi, s=30, color=BLUE, zorder=4)
    ax.text((a + b) / 2, yi + 0.22, f"{f_['gap']:+.3f}", ha="center", fontsize=6, color=INK)
ax.set_yticks(y); ax.set_yticklabels(DS); ax.set_xlabel("Deletion AUC (lower = faster drop)")
ax.set_title("(a) Faithfulness"); grid(ax); ax.set_ylim(-0.6, len(DS) - 0.4)
ax.scatter([], [], color=BLUE, s=20, label="SHAP order"); ax.scatter([], [], color=INK2, s=20, label="Random order")
ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.32), fontsize=5.8, handletextpad=0.2, ncol=2, columnspacing=0.6)
ax = axes[1]
for yi, d in zip(y, DS):
    s_ = xai[d]["stability_cosine_sim_fused"]
    ax.barh(yi, s_["mean"], height=0.5, color=BLUE, zorder=2)
    ax.errorbar(s_["mean"], yi, xerr=s_["std"], color=INK, lw=0.8, capsize=2, zorder=3)
ax.set_yticks(y); ax.set_yticklabels([]); ax.set_xlim(0, 1.05); ax.set_xlabel("Cosine similarity"); ax.set_title("(b) Stability"); grid(ax)
ax = axes[2]
for yi, d in zip(y, DS):
    g = xai[d]["sparsity_gini"]
    for off_, key, c_, lab in [(0.2, "CA-WSV_fused", BLUE, "Fused CA-WSV"), (0, "LR", AQUA, "LR"), (-0.2, "RF", ORANGE, "RF")]:
        ax.barh(yi + off_, g[key], height=0.18, color=c_, zorder=2, label=lab if d == DS[0] else None)
ax.set_yticks(y); ax.set_yticklabels([]); ax.set_xlim(0, 0.8); ax.set_xlabel("Gini of |φ|"); ax.set_title("(c) Sparsity"); grid(ax)
ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.32), fontsize=5.8, handlelength=0.8, ncol=3, columnspacing=0.6)
ax = axes[3]
for yi, d in zip(y, DS):
    ax.barh(yi, xai[d]["shap_lime_top5_jaccard_fused"], height=0.5, color=BLUE, zorder=2)
    ax.text(xai[d]["shap_lime_top5_jaccard_fused"] + 0.01, yi, f"{xai[d]['shap_lime_top5_jaccard_fused']:.2f}", va="center", fontsize=6)
ax.set_yticks(y); ax.set_yticklabels([]); ax.set_xlim(0, 0.6); ax.set_xlabel("Jaccard, top-5"); ax.set_title("(d) SHAP–LIME"); grid(ax)
fig.tight_layout(w_pad=0.4); save(fig, "F08_xai_validation")

# F9 global SHAP importance --------------------------------------------------------------
fig, axes = plt.subplots(1, 4, figsize=(7.16, 2.5))
for ax, d in zip(axes, DS):
    it = list(xai[d]["global_feature_importance_fused_meanabs_shap"].items())[:8][::-1]
    names = [n.replace("_", " ") for n, _ in it]; vals = [v for _, v in it]
    ax.barh(range(len(it)), vals, height=0.62, color=[BLUE] * (len(it) - 3) + ["#1c5cab"] * 3, zorder=2)
    ax.set_yticks(range(len(it))); ax.set_yticklabels(names, fontsize=6); ax.set_title(d); grid(ax)
    ax.set_xlabel("mean |SHAP|"); ax.tick_params(axis="y", length=0)
fig.tight_layout(w_pad=0.5); save(fig, "F09_global_shap_importance")

# F10 explanation cost ---------------------------------------------------------------------
fig, ax = plt.subplots(figsize=(3.45, 2.3))
x = np.arange(len(DS)); w = 0.26
series = [("KernelSHAP_KNN", "KernelSHAP, $k$-NN member", INK2), ("KernelSHAP_fused_CAWSV", "KernelSHAP, fused CA-WSV", BLUE),
          ("LIME_fused", "LIME, fused CA-WSV", ORANGE)]
for i, (k_, lab, c_) in enumerate(series):
    v = [xai[d]["timing_ms_per_instance"][k_] / 1000 for d in DS]
    ax.bar(x + (i - 1) * (w + 0.02), v, width=w, color=c_, label=lab, zorder=2)
for xi, d in zip(x, DS):
    tm = xai[d]["timing_ms_per_instance"]
    ax.text(xi, tm["LIME_fused"] / 1000 * 1.05, f"×{tm['KernelSHAP_fused_CAWSV']/tm['KernelSHAP_KNN']:.2f}", ha="center",
            fontsize=6, color=BLUE)
ax.set_xticks(x); ax.set_xticklabels(DS, fontsize=6.5); ax.set_ylabel("Seconds per explained flow"); grid(ax, "y")
ax.set_ylim(0, 33); ax.legend(fontsize=5.8, loc="upper right"); ax.set_title("Explanation cost (×: fused / $k$-NN)")
fig.tight_layout(); save(fig, "F10_explanation_cost")

# F11 distribution-shift slope chart ----------------------------------------------------------
def spread(vals, gap):
    idx = np.argsort(vals); out = np.array(vals, float)
    for a, b in zip(idx[:-1], idx[1:]):
        if out[b] - out[a] < gap: out[b] = out[a] + gap
    return out
fig, axes = plt.subplots(1, 2, figsize=(7.16, 2.8))
for ax, d in zip(axes, ["NSL-KDD", "UNSW-NB15"]):
    lab_m = ["CA-WSV", "Uniform", "Scalar", "RF", "HistGB", "LR"]
    for m in M_ALL:
        a, b = mf1[d][m].mean(), off[d][m]["macro_f1"]
        hi = m == "CA-WSV"; c_ = BLUE if hi else (ORANGE if m == "Uniform" else GRAY)
        ax.plot([0, 1], [a, b], color=c_, lw=2 if hi else 1, marker="o", ms=4 if hi else 3, zorder=4 if hi else 2)
    ends = [off[d][m]["macro_f1"] for m in lab_m]
    rng_ = max(mf1[d][m].mean() for m in M_ALL) - min(off[d][m]["macro_f1"] for m in M_ALL)
    ys = spread(ends, rng_ * 0.045)
    for m, yv, ye in zip(lab_m, ys, ends):
        c_ = BLUE if m == "CA-WSV" else (ORANGE if m == "Uniform" else INK2)
        nm = {"CA-WSV": "CA-WSV", "Uniform": "Uniform", "Scalar": "Scalar", "RF": "RF", "HistGB": "HistGB", "LR": "LR"}[m]
        ax.plot([1.01, 1.07], [ye, yv], color=GRID, lw=0.6)
        ax.text(1.08, yv, f"{nm} {ye:.3f}", va="center", fontsize=6, color=c_)
    ax.set_xticks([0, 1]); ax.set_xticklabels(["Stratified splits\n(in-distribution)", "Official train/test\n(shifted)"])
    ax.set_xlim(-0.15, 1.6); ax.set_title(d); ax.set_ylabel("Macro-F1"); grid(ax, "y")
fig.tight_layout(); save(fig, "F11_distribution_shift")

# F12 label conflicts -----------------------------------------------------------------------------
fig, ax = plt.subplots(figsize=(3.45, 2.3))
u = LABEL_CONFLICT["UNSW-NB15"][::-1]
ax.barh(range(len(u)), [v for _, v in u], height=0.62, color=[ORANGE if v > 30 else BLUE for _, v in u], zorder=2)
for i, (n, v) in enumerate(u): ax.text(v + 1, i, f"{v:.1f}%", va="center", fontsize=6)
ax.set_yticks(range(len(u))); ax.set_yticklabels([n for n, _ in u], fontsize=6.5); ax.set_xlim(0, 95)
ax.set_xlabel("% of unique flows with a conflicting label"); grid(ax); ax.tick_params(axis="y", length=0)
ax.set_title("UNSW-NB15: irreducible label conflict")
fig.tight_layout(); save(fig, "F12_unsw_label_conflict")

# F13 imbalance scaling ---------------------------------------------------------------------------
fig, axes = plt.subplots(1, 2, figsize=(7.16, 2.4))
ax = axes[0]
for i, (rows, lab) in enumerate([(cic3, "cap 100k\n(BF-XSS 439:1)"), (cic25, "cap 25k\n(≈110:1)")]):
    d_ = arr(rows, "CA-WSV") - arr(rows, "Scalar"); jit = np.random.default_rng(0).uniform(-0.07, 0.07, len(d_))
    ax.scatter(i + jit, d_, s=12, color=BLUE, alpha=0.6, lw=0, zorder=3)
    ax.plot([i - 0.18, i + 0.18], [d_.mean()] * 2, color=INK, lw=1.6, zorder=4)
    ax.text(i + 0.22, d_.mean(), f"{d_.mean():+.4f}", va="center", fontsize=6.5)
ax.axhline(0, color=INK2, lw=0.6); ax.set_xticks([0, 1]); ax.set_xticklabels(["cap 100k (3 splits)", "cap 25k (10 splits)"])
ax.set_ylabel("$\\Delta$ macro-F1, CA-WSV − Scalar"); ax.set_title("(a) Gain shrinks with imbalance"); grid(ax, "y"); ax.set_xlim(-0.5, 1.6)
ax = axes[1]
for m, c_ in [("CA-WSV", BLUE), ("KNN", AQUA), ("Scalar", ORANGE), ("RF", INK2)]:
    v = [arr(cic3, m, "bfweb_f1").mean(), arr(cic25, m, "bfweb_f1").mean()]
    ax.plot([0, 1], v, color=c_, marker="o", ms=4, lw=1.6 if m == "CA-WSV" else 1.1)
    ax.text(-0.05, v[0], MNAME[m].replace(" (proposed)", ""), ha="right", va="center", fontsize=6, color=c_)
ax.set_xticks([0, 1]); ax.set_xticklabels(["cap 100k", "cap 25k"]); ax.set_xlim(-0.75, 1.15)
ax.set_ylabel("Brute Force-Web F1"); ax.set_title("(b) Rarest web-attack class"); grid(ax, "y")
fig.tight_layout(); save(fig, "F13_imbalance_scaling")

# F14 critical-difference diagram ---------------------------------------------------------------
fig, ax = plt.subplots(figsize=(3.45, 1.55))
lo_r, hi_r = 1, k
ax.set_xlim(lo_r - 0.4, hi_r + 0.4); ax.set_ylim(0, 1); ax.axis("off")
ax.plot([lo_r, hi_r], [0.78, 0.78], color=INK, lw=0.8)
for r in range(lo_r, hi_r + 1):
    ax.plot([r, r], [0.78, 0.82], color=INK, lw=0.8); ax.text(r, 0.86, str(r), ha="center", fontsize=6.5)
ax.plot([lo_r, lo_r + CD], [0.97, 0.97], color=ORANGE, lw=1.6)
ax.text(lo_r + CD / 2, 1.0, f"CD = {CD:.2f}", ha="center", fontsize=6, color=ORANGE)
srt = np.argsort(avg_rank)
for n, j in enumerate(srt):
    rk = avg_rank[j]; left = n < (k + 1) // 2
    yy = 0.62 - 0.14 * (n if left else k - 1 - n)
    xx = lo_r - 0.3 if left else hi_r + 0.3
    c_ = BLUE if FM[j] == "CA-WSV" else INK2
    ax.plot([rk, rk, xx], [0.78, yy, yy], color=c_, lw=0.8)
    ax.text(xx + (-0.05 if left else 0.05), yy, f"{MNAME[FM[j]].replace(' (proposed)','')} ({rk:.2f})",
            ha="right" if left else "left", va="center", fontsize=6, color=c_)
ax.set_title(f"Average ranks over 4 datasets (Friedman p = {fr.pvalue:.2f})", fontsize=7, pad=14)
save(fig, "F14_critical_difference")

json.dump({"friedman": [fr.statistic, fr.pvalue], "iman_davenport": ff, "CD": CD,
           "avg_rank": dict(zip(FM, avg_rank.tolist())),
           "si_rows": si_rows, "sig": {f"{a}|{b}": v for (a, b), v in sig.items()}},
          open(f"{OUT}/derived_stats.json", "w"), indent=1, default=float)
print("tables:", sorted(os.listdir(TAB))); print("figures:", sorted(f for f in os.listdir(FIG) if f.endswith(".pdf")))
print("Friedman", fr, "CD", CD, "avg ranks", dict(zip(FM, avg_rank.round(2))))
for r in si_rows: print(r)
