import os as _os
from pathlib import Path as _Path
ROOT = _Path(_os.environ.get("CAWSV_ROOT", _Path(__file__).resolve().parents[1]))
DATA = ROOT / "data"
DATA_NSL = DATA / "nsl-kdd"; DATA_UNSW = DATA / "unsw-nb15"; DATA_CIC = DATA / "cic-ids2018"
DATA_CIC_STAGE = DATA / "cic-ids2018-stage"; BOTIOT_CSV = DATA / "bot-iot" / "random_500k.csv"
RESULTS = ROOT / "results"; LEGACY = RESULTS / "cicids2018_legacy"; MODELS = ROOT / "models"
PAPER = ROOT / "paper_assets"; SRC = ROOT / "src"; CKPT = MODELS / "checkpoint.joblib"
LEGACY_POST = LEGACY / "posteriors.npz"; LEGACY_GAMMA = LEGACY / "gamma_sensitivity.json"
for _d in (RESULTS, LEGACY, MODELS, PAPER, PAPER / "figures", PAPER / "tables"): _d.mkdir(parents=True, exist_ok=True)
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

BLUE, DBLUE, ORANGE = "#2a78d6", "#1c5cab", "#eb6834"
INK, INK2, LINE = "#0b0b0b", "#52514e", "#a3a29d"
BAND = ["#f4f8fd", "#f7f7f5", "#f4f8fd", "#f7f7f5", "#f4f8fd", "#f7f7f5", "#f4f8fd"]
plt.rcParams.update({"font.family": "DejaVu Sans", "pdf.fonttype": 42, "mathtext.fontset": "dejavusans"})

fig = plt.figure(figsize=(7.16, 6.3)); ax = fig.add_axes([0, 0, 1, 1]); ax.set_xlim(0, 101.5); ax.set_ylim(0, 88); ax.axis("off")

def box(x, y, w, h, t, kind="plain", fs=6.2, bold=False):
    fc, ec, tc = {"plain": ("white", LINE, INK), "key": (BLUE, BLUE, "white"), "dark": (DBLUE, DBLUE, "white"),
                  "warn": ("white", ORANGE, INK), "soft": ("#e6effb", "#86b6ef", INK)}[kind]
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0,rounding_size=0.9", fc=fc, ec=ec, lw=0.8, zorder=3))
    ax.text(x + w / 2, y + h / 2, t, ha="center", va="center", fontsize=fs, color=tc, zorder=4,
            fontweight="bold" if bold else "normal", linespacing=1.25)
def box2(x, y, w, h, title, formula, kind="plain", fs=6.2, ffs=6.6):
    box(x, y, w, h, "", kind)
    tc = "white" if kind in ("key", "dark") else INK
    ax.text(x + w / 2, y + h * 0.70, title, ha="center", va="center", fontsize=fs, color=tc, fontweight="bold", zorder=4)
    ax.text(x + w / 2, y + h * 0.33, formula, ha="center", va="center", fontsize=ffs, color=tc, zorder=4)
def arrow(x1, y1, x2, y2, c=INK2, lw=0.9, ls="-"):
    ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle="-|>", mutation_scale=7, color=c, lw=lw, ls=ls, zorder=2))
def band(y, h, i, label, sub):
    ax.add_patch(FancyBboxPatch((1, y), 96.2, h, boxstyle="round,pad=0,rounding_size=1.2", fc=BAND[i], ec="none", zorder=0))
    ax.text(2.4, y + h - 1.6, label, fontsize=6.6, fontweight="bold", color=DBLUE, va="top")
    ax.text(2.4, y + h - 3.9, sub, fontsize=5.4, color=INK2, va="top", linespacing=1.2)

# Layer geometry (top -> bottom)
L = [(78, 9), (66, 11), (55, 10), (43, 11), (30, 12), (14, 15), (1.5, 11.5)]
names = [("L1  Data", "four benchmarks,\nidentical protocol"),
         ("L2  Preprocessing", "leakage-free: every\nfit on the training\npartition only"),
         ("L3  Base pool", "M = 4 heterogeneous\nprobabilistic learners"),
         ("L4  Competence", "validation split only;\nno test data used"),
         ("L5  Adaptive fusion", "M×C weights\n(44 on CIC-IDS2018)"),
         ("L6  XAI & audit", "explain the fused\npredictor, then\nvalidate the\nexplanation"),
         ("L7  Outputs", "per-flow decision\n+ evidence")]
for i, ((y, h), (a, b)) in enumerate(zip(L, names)): band(y, h, i, a, b)
X0 = 18.5

# L1
y, h = L[0]
for j, (n, s) in enumerate([("CSE-CIC-IDS2018", "11 classes · 5.19 M unique"), ("UNSW-NB15", "10 classes · 0.16 M unique"),
                            ("NSL-KDD", "5 classes · 0.15 M unique"), ("Bot-IoT", "5 classes · 0.46 M unique")]):
    box(X0 + j * 19.87, y + 1.6, 18.0, h - 3.2, f"{n}\n{s}", "plain", 6.0)

# L2
y, h = L[1]; steps = ["Clean\ninf / NaN /\nnegatives", "Exact-row\ndeduplication", "Rare-class\nfilter\n(<100)", "Per-class\ncap", "Stratified\n70 / 30\nsplit",
                      "MinMax +\nANOVA-F\n(k = 20)", "85 / 15\nsub-train /\nvalidation"]
w = 10.0; gap = (77.6 - 7 * w) / 6
for j, t in enumerate(steps):
    xx = X0 + j * (w + gap); box(xx, y + 1.5, w, h - 3.0, t, "soft" if j in (1, 5) else "plain", 5.6)
    if j: arrow(xx - gap + 0.1, y + h / 2, xx - 0.1, y + h / 2)

# L3
y, h = L[2]
for j, (n, s) in enumerate([("Random Forest", "class-balanced"), ("Decision Tree", "class-balanced"),
                            ("k-NN", "k = 5"), ("Logistic Regression", "class-balanced")]):
    box(X0 + j * 19.87, y + 3.4, 18.0, h - 4.6, f"{n}\n{s}", "plain", 6.0)
ax.text(X0 + 38.8, y + 1.6, r"each member emits a posterior  $p_m(c\,|\,\mathbf{x})$, $m = 1..M$", ha="center", fontsize=5.8, color=INK2)

# L4
y, h = L[3]
box2(X0, y + 1.6, 23.2, h - 3.2, "Per-class validation F1", r"$F_{m,c}\in[0,1]^{M\times C}$")
box2(X0 + 27.2, y + 1.6, 23.2, h - 3.2, "Specialisation Index (SI)", r"$\mathrm{mean}_c\,[\max_m F_{m,c}-F_{m^{*}\!,c}]$", "key")
box2(X0 + 54.4, y + 1.6, 23.2, h - 3.2, "Sharpness selection", r"$\gamma^{*}$ = argmax val. macro-F1")
arrow(X0 + 23.3, y + h / 2, X0 + 27.1, y + h / 2); arrow(X0 + 50.5, y + h / 2, X0 + 54.3, y + h / 2)

# L5
y, h = L[4]
box(X0, y + 2.2, 16, h - 4.4, "Decision gate\nSI > τ ?", "warn", 6.4, True)
box2(X0 + 20, y + 6.2, 30.5, 4.9, "CA-WSV (class-adaptive)", r"$w_{m,c}\propto F_{m,c}^{\,\gamma^{*}}$,  $\sum_m w_{m,c}=1$", "key", 6.0, 6.2)
box(X0 + 20, y + 1.0, 30.5, 4.4, r"Scalar fallback:  $w_{m,c}=w_m$", "plain", 6.0)
box(X0 + 54.4, y + 1.6, 23.2, h - 3.2, "", "dark")
for k_, t_ in enumerate([r"$s_c(\mathbf{x})=\sum_m w_{m,c}\,p_m(c|\mathbf{x})$", r"$\hat{y}=\mathrm{argmax}_c\; s_c(\mathbf{x})$",
                          r"margin $\mu=s_{(1)}-s_{(2)}$"]):
    ax.text(X0 + 66, y + h - 3.6 - k_ * 2.4, t_, ha="center", va="center", fontsize=6.0, color="white", zorder=4)
arrow(X0 + 16.1, y + h / 2 + 1.2, X0 + 19.9, y + 8.6, BLUE); ax.text(X0 + 16.6, y + 9.4, "yes", fontsize=5.4, color=BLUE)
arrow(X0 + 16.1, y + h / 2 - 1.2, X0 + 19.9, y + 3.2, INK2); ax.text(X0 + 16.9, y + 1.3, "no", fontsize=5.4, color=INK2)
arrow(X0 + 50.6, y + 8.6, X0 + 54.3, y + 7.0); arrow(X0 + 50.6, y + 3.2, X0 + 54.3, y + 5.0)

# L6
y, h = L[5]
box(X0, y + 7.8, 23.2, 5.6, "KernelSHAP on the fused\npredictor " + r"$s_c(\mathbf{x})$", "key", 6.0, True)
box(X0, y + 1.4, 23.2, 5.6, "TreeSHAP (RF, DT) · LinearSHAP (LR)\nKernelSHAP (k-NN) · LIME", "plain", 5.6)
box(X0 + 27.2, y + 1.4, 23.2, h - 2.8, "Explanation validation\n\nfaithfulness (deletion AUC)\nstability under jitter\nsparsity (Gini of |φ|)\nSHAP–LIME agreement", "soft", 5.8)
box(X0 + 54.4, y + 1.4, 23.2, h - 2.8, "Data & model audit\n\nlabel-conflict rate\n(identical x, different y)\nartefact detection\n(e.g. TTL in UNSW-NB15)", "warn", 5.8)
arrow(X0 + 23.3, y + 10.6, X0 + 27.1, y + 9.0); arrow(X0 + 23.3, y + 4.2, X0 + 27.1, y + 5.5)
arrow(X0 + 50.5, y + h / 2, X0 + 54.3, y + h / 2)

# L7
y, h = L[6]
for j, t in enumerate(["Attack class\n+ fused score " + r"$s_c(\mathbf{x})$", "Reject option\nabstain if μ < θ", "Per-flow feature\nattribution", "Validated explanation\n& audit report"]):
    box(X0 + j * 19.87, y + 1.6, 18.0, h - 3.2, t, "dark" if j < 2 else "plain", 6.0)

# inter-layer arrows
for (ya, ha_), (yb, hb) in zip(L[:-1], L[1:]):
    arrow(X0 + 38.8, ya + 0.2, X0 + 38.8, yb + hb - 0.2, INK2, 1.0)
# side annotations
ax.annotate("", xy=(98.6, 30), xytext=(98.6, 87), arrowprops=dict(arrowstyle="-", color=LINE, lw=0.8))
ax.text(99.0, 58, "offline: fit once", rotation=90, fontsize=5.6, color=INK2, va="center", ha="left")
ax.annotate("", xy=(98.6, 1.5), xytext=(98.6, 29.5), arrowprops=dict(arrowstyle="-", color=BLUE, lw=0.8))
ax.text(99.0, 15, "online: per flow", rotation=90, fontsize=5.6, color=BLUE, va="center", ha="left")
# legend
lx = 2.4; ly = 0.2
fig.savefig(f"{PAPER}/figures/F01_framework.pdf", bbox_inches="tight", pad_inches=0.03)
fig.savefig(f"{PAPER}/figures/F01_framework.png", dpi=300, bbox_inches="tight", pad_inches=0.03)
print("ok")
